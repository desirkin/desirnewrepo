// LEARN-1 — the sealed prospective validation discipline and the machine-enforced promotion gate.
//
// This mirrors the referee's LAW without importing it (research/referee/ has a structural import fence): a candidate
// is FROZEN before one future observation exists — predicate, scope, primary metric/horizon, comparator, cost model,
// group law, terminal sample target, missingness rule, uncertainty method and alpha are all inside the sealed design
// whose digest is the candidate's identity. Fresh forward evidence then arrives as two append-only stages: a CAPTURE
// commits the hypothetical decision while the outcome is unknown; a later OUTCOME record supplies exactly one
// outcome per capture and can revise nothing. Formal significance is evaluated ONCE, at the pre-registered terminal
// group count. Interim views are descriptive and carry the banner. Repeated looks, modified candidates and reused
// evidence cannot bypass the endpoint: any change to the design is a NEW candidate with a new id, and the journal
// keeps every failed candidate charged against its question's trial budget.
//
// The anti-shortcut floors (learning/contracts.js DEFAULT_FLOORS) are engineering safeguards, not proof of power:
// >= 30 matured prospective dependence groups, >= 7 distinct UTC dates, >= 5 distinct eligible assets, and a
// registered terminal target no smaller than the floors. Skipped winners alone cannot pass: the paired comparison
// runs candidate-vs-baseline over the SAME opportunity stream, newly admitted losers and costs included, under the
// predeclared missingness rule (a coverage ratio below the rule's threshold is INSUFFICIENT, never repaired).
import {
  PROSPECTIVE_VERSION, DEFAULT_FLOORS, AUTHORITY, PURPOSE,
  candidateIdOf, designError, canonicalDigest, utcDateOf, isTs, isFiniteNum, round4, deepFreeze, exactKeys,
} from './contracts.js';
import { assignGroups } from './grouping.js';
import { normalShrinkageGrouped } from './estimator.js';

export const ADAPTIVE_RANKING_TRIAL_CAPTURE = 'ADAPTIVE_RANKING_TRIAL_CAPTURE';
export const ADAPTIVE_RANKING_TRIAL_OUTCOME = 'ADAPTIVE_RANKING_TRIAL_OUTCOME';
export const PROSPECTIVE_RECORD_KINDS = Object.freeze([
  'DESIGN_SEALED', 'CAPTURE', 'OUTCOME', ADAPTIVE_RANKING_TRIAL_CAPTURE,
  ADAPTIVE_RANKING_TRIAL_OUTCOME, 'TERMINAL_EVALUATED',
]);
export const TERMINAL_VERDICTS = Object.freeze(['FORWARD_SUPPORTED', 'FORWARD_NOT_SUPPORTED', 'INSUFFICIENT_COMPARISON']);
export const INTERIM_BANNER = 'INTERIM — NOT A FORMAL CONFIRMATION';
export const MIN_COMPARISON_COVERAGE = 0.8; // predeclared: below this matured-outcome coverage the comparison is INSUFFICIENT

export function sealDesign({
  patternId, predicate, scope, primaryHorizonMin = 60, primaryMetric = 'NET_LOG_RETURN_60M_PCT',
  comparator = 'BASELINE_RULE_SAME_STREAM', costModel, groupLaw = 'learning-group-law-1',
  terminalGroupTarget, floors = DEFAULT_FLOORS, missingnessRule = `MATURED_COVERAGE_AT_LEAST_${MIN_COMPARISON_COVERAGE}`,
  uncertaintyMethod = 'NORMAL_SE_OVER_GROUP_MEANS', alpha = 0.05, sealedTs, evidenceDigest, consumerBinding,
}) {
  const body = {
    prospectiveVersion: PROSPECTIVE_VERSION, candidateId: 'lcand-UNBOUND', patternId, predicate, predicateDigest: canonicalDigest(predicate),
    scope, primaryHorizonMin, primaryMetric, comparator, costModel, groupLaw, terminalGroupTarget, floors, missingnessRule,
    uncertaintyMethod, alpha, sealedTs, evidenceDigest, consumerBinding: consumerBinding ?? null,
  };
  let design;
  try { design = { ...body, candidateId: candidateIdOf(body) }; }
  catch { throw new Error('sealDesign: consumer binding malformed'); }
  const err = designError(design); if (err) throw new Error(`sealDesign: ${err}`);
  return deepFreeze(design);
}

export const CAPTURE_KEYS = Object.freeze(['kind', 'candidateId', 'opportunityId', 'canonicalCoin', 'decisionTs', 'candidateDecision', 'baselineDecision', 'recordedTs', 'labelEndTs']);
export const OUTCOME_KEYS = Object.freeze(['kind', 'candidateId', 'opportunityId', 'outcomeClass', 'metricValue', 'outcomeKnownAtTs', 'recordedTs']);
export const ADAPTIVE_RANKING_TRIAL_CAPTURE_KEYS = Object.freeze(['kind', 'candidateId', 'opportunityId', 'publicationId', 'decisionReceipt']);
export const ADAPTIVE_RANKING_TRIAL_OUTCOME_KEYS = Object.freeze(['kind', 'candidateId', 'opportunityId', 'publicationId', 'executionReceipt']);
const ADAPTIVE_CAPTURE_PROJECTION_KEYS = Object.freeze(['canonicalCoin', 'decisionTs', 'recordedTs', 'labelEndTs', 'candidateDecision', 'baselineDecision']);
const ADAPTIVE_OUTCOME_PROJECTION_KEYS = Object.freeze(['outcomeKnownAtTs', 'recordedTs', 'candidateMetricValue', 'baselineMetricValue']);

const captureOrder = (a, b) => a.recordedTs - b.recordedTs || (a.opportunityId < b.opportunityId ? -1 : 1);

function formalShockDates(commonShockDates) {
  if (!(commonShockDates instanceof Set)) throw new Error('evaluateTerminal: commonShockDates must be a Set');
  // The design currently seals only the grouping-law version, not a list of shock dates. Letting a caller supply
  // dates at the formal look would make the terminal result impossible to reproduce from the journal alone.
  if (commonShockDates.size > 0) throw new Error('evaluateTerminal: commonShockDates are not sealed in this design');
  return commonShockDates;
}

// ---- validated replay: the ONLY way to obtain trusted prospective state ------------------------------------------
export function replayProspective(records, { adaptiveRankingTrialValidator = null } = {}) {
  const designs = new Map(); const captures = new Map(); const outcomes = new Map(); const terminals = new Map(); const errors = [];
  for (let i = 0; i < records.length; i += 1) {
    const r = records[i];
    const at = (m) => { errors.push(`record ${i + 1}: ${m}`); };
    if (!r || typeof r !== 'object' || !PROSPECTIVE_RECORD_KINDS.includes(r.kind)) { at('unknown record kind'); continue; }
    if (r.kind === 'DESIGN_SEALED') {
      const err = designError(r.design ?? null); if (err) { at(err); continue; }
      if (designs.has(r.design.candidateId)) { at('duplicate design'); continue; }
      designs.set(r.design.candidateId, r.design);
      captures.set(r.design.candidateId, new Map()); outcomes.set(r.design.candidateId, new Map());
      continue;
    }
    const d = designs.get(r.candidateId);
    if (!d) { at('record precedes its sealed design'); continue; }
    if (terminals.has(r.candidateId)) { at('record after the one terminal look'); continue; }
    if (r.kind === ADAPTIVE_RANKING_TRIAL_CAPTURE) {
      const k = exactKeys(r, ADAPTIVE_RANKING_TRIAL_CAPTURE_KEYS); if (k) { at(`adaptive ranking capture ${k}`); continue; }
      if (typeof adaptiveRankingTrialValidator !== 'function') { at('adaptive ranking trial validator absent'); continue; }
      const caps = captures.get(r.candidateId);
      if ([...caps.values()].some((row) => row.comparisonKind !== ADAPTIVE_RANKING_TRIAL_CAPTURE)) { at('cannot mix adaptive and legacy captures in one candidate'); continue; }
      if (caps.has(r.opportunityId)) { at('duplicate capture'); continue; }
      let checked;
      try { checked = adaptiveRankingTrialValidator(r, { stage: 'CAPTURE', design: d, capture: null }); }
      catch (error) { at(`adaptive ranking capture invalid (${error?.message ?? 'validator threw'})`); continue; }
      if (!checked || checked.error !== null || exactKeys(checked.projection, ADAPTIVE_CAPTURE_PROJECTION_KEYS)) {
        at(`adaptive ranking capture invalid (${checked?.error ?? 'projection malformed'})`); continue;
      }
      const p = checked.projection;
      if (!isTs(p.decisionTs) || !isTs(p.recordedTs) || !isTs(p.labelEndTs)) { at('adaptive ranking capture clocks malformed'); continue; }
      if (p.decisionTs < d.sealedTs || p.recordedTs < p.decisionTs || p.recordedTs >= p.labelEndTs
          || p.labelEndTs - p.decisionTs < d.primaryHorizonMin * 60_000) { at('adaptive ranking capture chronology malformed'); continue; }
      if (!['SELECTED_FOR_SHADOW', 'SKIPPED'].includes(p.candidateDecision)
          || !['SELECTED_FOR_SHADOW', 'SKIPPED'].includes(p.baselineDecision)) { at('adaptive ranking capture decision malformed'); continue; }
      caps.set(r.opportunityId, deepFreeze({ ...r, ...p, comparisonKind: ADAPTIVE_RANKING_TRIAL_CAPTURE }));
      continue;
    }
    if (r.kind === ADAPTIVE_RANKING_TRIAL_OUTCOME) {
      const k = exactKeys(r, ADAPTIVE_RANKING_TRIAL_OUTCOME_KEYS); if (k) { at(`adaptive ranking outcome ${k}`); continue; }
      if (typeof adaptiveRankingTrialValidator !== 'function') { at('adaptive ranking trial validator absent'); continue; }
      const caps = captures.get(r.candidateId); const outs = outcomes.get(r.candidateId);
      const cap = caps.get(r.opportunityId);
      if (!cap || cap.comparisonKind !== ADAPTIVE_RANKING_TRIAL_CAPTURE) { at('adaptive ranking outcome without its typed prior capture'); continue; }
      if (outs.has(r.opportunityId)) { at('second outcome for one capture'); continue; }
      let checked;
      try { checked = adaptiveRankingTrialValidator(r, { stage: 'OUTCOME', design: d, capture: cap }); }
      catch (error) { at(`adaptive ranking outcome invalid (${error?.message ?? 'validator threw'})`); continue; }
      if (!checked || checked.error !== null || exactKeys(checked.projection, ADAPTIVE_OUTCOME_PROJECTION_KEYS)) {
        at(`adaptive ranking outcome invalid (${checked?.error ?? 'projection malformed'})`); continue;
      }
      const p = checked.projection;
      if (!isTs(p.outcomeKnownAtTs) || p.outcomeKnownAtTs < cap.labelEndTs
          || !isTs(p.recordedTs) || p.recordedTs < p.outcomeKnownAtTs
          || !isFiniteNum(p.candidateMetricValue) || !isFiniteNum(p.baselineMetricValue)) {
        at('adaptive ranking outcome chronology or arm metric malformed'); continue;
      }
      outs.set(r.opportunityId, deepFreeze({ ...r, ...p, comparisonKind: ADAPTIVE_RANKING_TRIAL_OUTCOME }));
      continue;
    }
    if (r.kind === 'CAPTURE') {
      const k = exactKeys(r, CAPTURE_KEYS); if (k) { at(`capture ${k}`); continue; }
      const caps = captures.get(r.candidateId);
      if ([...caps.values()].some((row) => row.comparisonKind === ADAPTIVE_RANKING_TRIAL_CAPTURE)) { at('cannot mix legacy and adaptive captures in one candidate'); continue; }
      if (caps.has(r.opportunityId)) { at('duplicate capture'); continue; }
      if (!isTs(r.decisionTs) || !isTs(r.recordedTs) || !isTs(r.labelEndTs)) { at('capture clocks malformed'); continue; }
      if (r.decisionTs < d.sealedTs) { at('capture decided before the design was sealed'); continue; }
      if (r.recordedTs < r.decisionTs) { at('capture recorded before its decision'); continue; }
      if (r.labelEndTs - r.decisionTs < d.primaryHorizonMin * 60_000) { at('capture label window shorter than the sealed horizon'); continue; }
      if (r.recordedTs >= r.labelEndTs) { at('capture not recorded before its label window closes — no prior-capture evidence'); continue; }
      caps.set(r.opportunityId, r);
      continue;
    }
    if (r.kind === 'OUTCOME') {
      const k = exactKeys(r, OUTCOME_KEYS); if (k) { at(`outcome ${k}`); continue; }
      const caps = captures.get(r.candidateId); const outs = outcomes.get(r.candidateId);
      const cap = caps.get(r.opportunityId);
      if (!cap) { at('outcome without a prior capture'); continue; }
      if (cap.comparisonKind === ADAPTIVE_RANKING_TRIAL_CAPTURE) { at('legacy outcome cannot settle an adaptive capture'); continue; }
      if (outs.has(r.opportunityId)) { at('second outcome for one capture'); continue; }
      if (!isTs(r.outcomeKnownAtTs) || r.outcomeKnownAtTs < cap.labelEndTs) { at('outcome known before its horizon end'); continue; }
      if (!isTs(r.recordedTs) || r.recordedTs < r.outcomeKnownAtTs) { at('outcome recorded before it was known'); continue; }
      outs.set(r.opportunityId, r);
      continue;
    }
    if (r.kind === 'TERMINAL_EVALUATED') {
      // A terminal is trusted only when it is the deterministic result of the evidence that precedes it. This also
      // refuses a hand-written verdict, an early terminal and a terminal clock backdated before existing evidence.
      try {
        const expected = terminalRecord({ designs, captures, outcomes, terminals }, r.candidateId, { nowTs: r.recordedTs, commonShockDates: new Set(), comparison: r.effect && typeof r.effect === 'object' && r.effect.comparison === TERMINAL_COMPARISON ? TERMINAL_COMPARISON : LEGACY_TERMINAL_COMPARISON });
        if (expected.reasons.includes('TERMINAL_SAMPLE_NOT_REACHED')) { at('terminal sample not reached'); continue; }
        if (canonicalDigest(r) !== canonicalDigest(expected)) { at('terminal does not match the replayed prospective evidence'); continue; }
      } catch (err) { at(`terminal invalid (${err.message})`); continue; }
      terminals.set(r.candidateId, r);
    }
  }
  return { designs, captures, outcomes, terminals, errors };
}

// ---- interim view (descriptive only) -------------------------------------------------------------------------------
export function interimView(state, candidateId, { commonShockDates = new Set() } = {}) {
  const d = state.designs.get(candidateId); if (!d) return null;
  const caps = [...state.captures.get(candidateId).values()];
  const outs = state.outcomes.get(candidateId);
  const matured = caps.filter((c) => outs.has(c.opportunityId));
  const grouping = assignGroups(matured.map((c) => ({ canonicalCoin: c.canonicalCoin, decisionTs: c.decisionTs })), { commonShockDates });
  return deepFreeze({
    banner: INTERIM_BANNER, candidateId, captured: caps.length, matured: matured.length,
    maturedGroups: grouping.groupCount, distinctAssets: grouping.distinctAssets, distinctUtcDates: grouping.distinctUtcDates,
    terminalGroupTarget: d.terminalGroupTarget, floors: d.floors,
  });
}

// ---- the ONE terminal evaluation ------------------------------------------------------------------------------------
// Counted sample = the FIRST terminalGroupTarget matured dependence groups in capture order — never the first N
// favourable ones. The paired comparison is candidate-vs-baseline mean primary metric over the same opportunities:
// the candidate takes the metric where it decided to select and 0 where it skipped, and vice versa for the baseline,
// so newly admitted losers and forgone gains both count. Floors and coverage are machine-enforced before any effect
// is read.
// the terminal law in force: SELECTED_VS_GROUP_MEAN (PUBLISH-FIX-83 item 19, the ranking law) — a terminal written under the OLD law
// (candidate minus a never-selecting baseline) carries no `effect.comparison` and is replayed under that law, so the journal's history
// stays valid (review finding: the first deploy would otherwise have refused every settle forever)
export const TERMINAL_COMPARISON = 'SELECTED_VS_GROUP_MEAN'; export const LEGACY_TERMINAL_COMPARISON = 'SELECTED_VS_BASELINE';
function terminalRecord(state, candidateId, { nowTs, commonShockDates = new Set(), comparison = TERMINAL_COMPARISON }) {
  const d = state.designs.get(candidateId); if (!d) throw new Error('evaluateTerminal: unknown candidate');
  formalShockDates(commonShockDates);
  if (!isTs(nowTs)) throw new Error('evaluateTerminal: terminal clock malformed');
  const caps = [...state.captures.get(candidateId).values()].sort(captureOrder);
  const outs = state.outcomes.get(candidateId);
  const latestEvidenceTs = Math.max(
    d.sealedTs,
    ...caps.map((c) => c.recordedTs),
    ...[...outs.values()].flatMap((o) => [o.outcomeKnownAtTs, o.recordedTs]),
  );
  if (nowTs < latestEvidenceTs) throw new Error('evaluateTerminal: terminal recorded before existing prospective evidence');
  // groups over ALL captures (the denominator); matured coverage judged against it under the sealed missingness rule
  const maturedCaps = caps.filter((c) => outs.has(c.opportunityId));
  const maturedGrouping = assignGroups(maturedCaps.map((c) => ({ canonicalCoin: c.canonicalCoin, decisionTs: c.decisionTs })), { commonShockDates });

  // Once the target is reachable, freeze exactly the first target groups in capture order. Later captures and later
  // matured groups cannot change either the formal effect or its missingness denominator.
  const targetReached = maturedGrouping.groupCount >= d.terminalGroupTarget;
  const countedGroups = targetReached ? maturedGrouping.groups.slice(0, d.terminalGroupTarget) : maturedGrouping.groups;
  const countedIndexes = new Set(countedGroups.flatMap((g) => g.members));
  const countedCaps = maturedCaps.filter((_c, i) => countedIndexes.has(i));
  const countedGrouping = assignGroups(countedCaps.map((c) => ({ canonicalCoin: c.canonicalCoin, decisionTs: c.decisionTs })), { commonShockDates });
  const lastCountedId = countedCaps.length > 0 ? countedCaps[countedCaps.length - 1].opportunityId : null;
  const captureCutoff = lastCountedId === null ? -1 : caps.findIndex((c) => c.opportunityId === lastCountedId);
  const denominatorCaps = targetReached ? caps.slice(0, captureCutoff + 1) : caps;
  const maturedDenominator = denominatorCaps.filter((c) => outs.has(c.opportunityId));
  const allGrouping = assignGroups(denominatorCaps.map((c) => ({ canonicalCoin: c.canonicalCoin, decisionTs: c.decisionTs })), { commonShockDates });
  const reasons = [];
  if (!targetReached) reasons.push('TERMINAL_SAMPLE_NOT_REACHED');
  if (countedGrouping.groupCount < d.floors.minIndependentGroups) reasons.push('FLOOR_GROUPS_NOT_MET');
  // Breadth floors describe all forward evidence available at the one terminal look; the effect estimate itself is
  // still frozen to the first target groups. This preserves the existing rule that later dates/assets may establish
  // transfer breadth without letting their returns alter the predeclared effect sample.
  if (maturedGrouping.distinctUtcDates < d.floors.minDistinctUtcDates) reasons.push('FLOOR_DATES_NOT_MET');
  if (maturedGrouping.distinctAssets < d.floors.minDistinctAssets) reasons.push('FLOOR_ASSETS_NOT_MET');
  const coverage = denominatorCaps.length === 0 ? 0 : maturedDenominator.length / denominatorCaps.length;
  if (coverage < MIN_COMPARISON_COVERAGE) reasons.push('MATURED_COVERAGE_BELOW_RULE'); // dropping difficult outcomes cannot manufacture improvement
  if (reasons.length > 0) {
    return deepFreeze({ kind: 'TERMINAL_EVALUATED', candidateId, verdict: 'INSUFFICIENT_COMPARISON', reasons, effect: null, coverage: round4(coverage), maturedGroups: countedGrouping.groupCount, distinctAssets: maturedGrouping.distinctAssets, distinctUtcDates: maturedGrouping.distinctUtcDates, recordedTs: nowTs, alpha: d.alpha, authority: AUTHORITY, purpose: PURPOSE });
  }
  // per-group paired difference of the primary metric.
  // PUBLISH-FIX-83 (full review item 19): learning is RANKING-ONLY (owner law), so a candidate is judged as a ranking: the mean NET
  // metric of the opportunities it SELECTED against the mean of every matured opportunity in the same group (its cell, its
  // window). The old law scored it against a baseline that never selected (SKIPPED = 0), i.e. demanded an absolute net profit
  // after the sealed 1.8% round trip on a 5-minute horizon — a bar no cohort of looks could clear, so every forward test ended
  // FORWARD_NOT_SUPPORTED and re-proposed forever. Profitability is the gates' and the cost model's job; the ranking's job is to
  // put the better looks first, and that is what is measured here. The adaptive-ranking trial keeps its own paired metric.
  const legacy = comparison === LEGACY_TERMINAL_COMPARISON;
  const diffs = countedGrouping.groups.map((g) => {
    let adaptiveSum = 0; let adaptiveN = 0; let selectedSum = 0; let selectedN = 0; let allSum = 0; let allN = 0; let legacySum = 0; let legacyN = 0;
    for (const idx of g.members) {
      const cap = countedCaps[idx]; const out = outs.get(cap.opportunityId);
      const adaptive = cap.comparisonKind === ADAPTIVE_RANKING_TRIAL_CAPTURE
        && out.comparisonKind === ADAPTIVE_RANKING_TRIAL_OUTCOME;
      if (adaptive) { adaptiveSum += out.candidateMetricValue - out.baselineMetricValue; adaptiveN += 1; continue; }
      const metric = isFiniteNum(out.metricValue) ? out.metricValue : null; if (metric === null) continue;
      if (legacy) { const cand = cap.candidateDecision === 'SELECTED_FOR_SHADOW' ? metric : 0; const base = cap.baselineDecision === 'SELECTED_FOR_SHADOW' ? metric : 0; legacySum += cand - base; legacyN += 1; continue; }
      allSum += metric; allN += 1; if (cap.candidateDecision === 'SELECTED_FOR_SHADOW') { selectedSum += metric; selectedN += 1; }
    }
    if (legacy) { const n = adaptiveN + legacyN; return n > 0 ? (adaptiveSum + legacySum) / n : null; }
    if (adaptiveN > 0) return adaptiveSum / adaptiveN;
    if (selectedN === 0 || allN === 0 || selectedN === allN) return null; // no contrast: a group the candidate picked all or none of says nothing about its ranking (review finding)
    return selectedSum / selectedN - allSum / allN;
  }).filter((v) => v !== null);
  const est = normalShrinkageGrouped({ groupMeans: diffs, pooledMean: 0, priorStrength: 1 });
  // one-sided lower bound must clear zero at the sealed alpha (1.96 ≈ two-sided 5%; the sealed uncertainty method)
  const supported = est.lower95 !== null && est.lower95 > 0;
  return deepFreeze({
    kind: 'TERMINAL_EVALUATED', candidateId, verdict: supported ? 'FORWARD_SUPPORTED' : 'FORWARD_NOT_SUPPORTED',
    reasons: supported ? ['PAIRED_LOWER_BOUND_ABOVE_ZERO'] : ['PAIRED_LOWER_BOUND_NOT_ABOVE_ZERO'],
    effect: legacy ? { pairedMeanDiff: est.posteriorMean, lower95: est.lower95, upper95: est.upper95, groups: est.effectiveGroups, metric: d.primaryMetric } : { pairedMeanDiff: est.posteriorMean, lower95: est.lower95, upper95: est.upper95, groups: est.effectiveGroups, metric: d.primaryMetric, comparison: TERMINAL_COMPARISON },
    coverage: round4(coverage), maturedGroups: countedGrouping.groupCount, distinctAssets: maturedGrouping.distinctAssets, distinctUtcDates: maturedGrouping.distinctUtcDates,
    allGroups: allGrouping.groupCount, recordedTs: nowTs, alpha: d.alpha, authority: AUTHORITY, purpose: PURPOSE,
  });
}

export function evaluateTerminal(state, candidateId, options) {
  if (state.terminals.has(candidateId)) throw new Error('evaluateTerminal: the one terminal look is already recorded');
  return terminalRecord(state, candidateId, options);
}
