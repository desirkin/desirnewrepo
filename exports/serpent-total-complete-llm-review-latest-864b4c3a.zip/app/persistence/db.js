// PERSIST-0 — database boundary. The ONLY file that touches the pg driver
// directly. DATABASE_URL comes from the environment alone; it is never
// logged, never echoed, never reachable from browser JavaScript. The
// deployment filesystem is a cache; this is the durable authority's door.
import pg from 'pg';

const POOL_MAX = 5; // one personal app, one small pool
// PUBLISH-FIX-84 (2026-09-20): the night's "tx checkout failed after 6455ms: Error" lines. The pool let an idle connection go after
// 30 s, so every quiet minute meant the next transaction opened a FRESH connection to the managed Postgres (TLS through its proxy),
// and a fresh connection that took over 5 s was a checkout failure — which also flipped `reachable` and engaged the permission lock
// for a transient. Now: an idle connection is kept warm for 10 minutes (keep-alive is on), a fresh connection gets 15 s, and a
// checkout that times out is retried once after a short pause before it counts as a failure (nothing has begun on it yet).
const CONNECT_TIMEOUT_MS = 15_000;
const QUERY_TIMEOUT_MS = 10_000;
// reviewer finding on the 10-minute idle: a managed Postgres proxy commonly drops an idle connection at ~5 min, and pg surfaces that
// as a pool 'error' — which used to flip `reachable` and engage the permission lock on a transient. Idle is 4 minutes (under the
// usual proxy cutoff, well above the 30 s that forced a fresh TLS connection every quiet minute), and an idle client dying is
// counted and logged, never a verdict on reachability: nothing was in flight on it; the next checkout or query decides.
const IDLE_TIMEOUT_MS = 4 * 60_000;
const CHECKOUT_RETRIES = 1; const CHECKOUT_RETRY_DELAY_MS = 500;
const boundedText = (v) => String(v ?? '').replace(/[\r\n]+/g, ' ').slice(0, 120);
const STARTUP_RETRIES = 3; // bounded — no infinite reconnect storm
// every session of a Db names its owner in pg_stat_activity.application_name: production sessions are 'serpent'; a
// schema-scoped Db (the TEST seam) is 'serpent-test:<schema>' so a test that simulates session loss can terminate ONLY
// its own advisory-lock sessions — never another test file's collector running in parallel on the same database
export const applicationNameOf = (schema) => (schema ? `serpent-test:${schema}` : 'serpent');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// PUBLISH-FIX-50 (2026-09-17): the DATABASE CLOCKS. Production's journal commit measured p50 2.2 s / p95 3.5 s (fix47) and
// that clock starts when the commit is CALLED, so it cannot say whether the seconds are spent waiting for the dispatcher's
// serial chain, waiting for a free pooled connection (POOL_MAX 5, shared with the tape and every collector), or inside the
// transaction itself (BEGIN, SET LOCAL x2, SELECT ... FOR UPDATE of the whole account state, INSERT per event, UPDATE the
// whole state back, COMMIT — seven round trips, and the state JSON travels twice). These clocks split it: per transaction
// the pool checkout wait, the transaction's own duration, its statement count and the bytes it carried in parameters;
// per plain query() its duration; plus the pool gauge (total / idle / waiting). Bounded ring buffers; read-only.
const CLOCK_SAMPLES = 2048;
const pushSample = (list, v) => { list.push(v); if (list.length > CLOCK_SAMPLES) list.shift(); };
const percentile = (samples, p) => { if (!samples.length) return null; const s = [...samples].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.max(0, Math.ceil(p * s.length) - 1))]; };
export const clockStats = (samples) => ({ count: samples.length, p50: percentile(samples, 0.5), p95: percentile(samples, 0.95), max: samples.length ? Math.max(...samples) : null });
const paramBytesOf = (params) => { let n = 0; for (const p of Array.isArray(params) ? params : []) { if (typeof p === 'string') n += p.length; else if (p !== null && p !== undefined) n += String(p).length; } return n; };

// PERSIST-0A — ONE shared connection-failure classifier for connect/probe,
// query() and tx(). A dead transaction must mark the database unreachable
// exactly as a dead query does, so the permission lock tells the truth.
const CONNECTION_ERROR_CODES = new Set([
  'ECONNREFUSED',
  'ECONNRESET',
  'ETIMEDOUT',
  'EPIPE',
  'ENOTFOUND',
  'EHOSTUNREACH',
  'ENETUNREACH',
  '57P01', // admin_shutdown
  '57P02', // crash_shutdown
  '57P03', // cannot_connect_now
  '08000',
  '08003',
  '08006', // connection exceptions
]);
export function isConnectionError(err) {
  if (!err) return false;
  if (CONNECTION_ERROR_CODES.has(err.code)) return true;
  const msg = String(err.message ?? '');
  return /timeout|terminated|connection (closed|ended|refused)/i.test(msg);
}

export class Db {
  #pool = null;
  #url;
  #poolFactory;
  #retries;
  #everConnected = false;
  #lockClients = new Set(); // advisory-lock sessions checked out for their lifetime
  #clocks = { checkoutWait: [], tx: [], txStatements: [], txParamBytes: [], query: [], txCount: 0, queryCount: 0, checkoutFailures: 0, checkoutRetries: 0, idleClientErrors: 0, slowestTx: null }; // PUBLISH-FIX-50
  #lastIdleErrorLogMs = 0;

  constructor({ url = process.env.DATABASE_URL, schema = null, log = () => {}, poolFactory = null, retries = STARTUP_RETRIES } = {}) {
    this.#url = url;
    this.schema = schema; // tests isolate themselves in their own schema
    this.log = log;
    this.#poolFactory = poolFactory; // test seam: adversarial pools for reconnect drills
    this.#retries = retries;
    this.connectionErrors = 0;
    this.transactionErrors = 0;
    this.lastSuccessfulReadTs = null;
    this.lastSuccessfulWriteTs = null;
    this.reachable = false;
  }

  configured() {
    return typeof this.#url === 'string' && this.#url.length > 0;
  }

  #markConnectionFailure(err) {
    if (isConnectionError(err)) {
      this.connectionErrors++;
      this.reachable = false;
      return true;
    }
    return false;
  }

  #ensurePool() {
    if (this.#pool) return;
    const opts = {
      connectionString: this.#url,
      max: POOL_MAX,
      connectionTimeoutMillis: CONNECT_TIMEOUT_MS,
      idleTimeoutMillis: IDLE_TIMEOUT_MS,
      query_timeout: QUERY_TIMEOUT_MS,
      statement_timeout: QUERY_TIMEOUT_MS,
      // PUBLISH-FIX-3: a managed PostgreSQL behind a proxy silently drops idle TCP sockets; without SO_KEEPALIVE a pooled
      // connection looks alive but the next query hangs until the OS timeout (production saw ETIMEDOUT with no prior sign).
      keepAlive: true,
      keepAliveInitialDelayMillis: 10_000,
      allowExitOnIdle: true, // persistence never keeps a dying process alive
      application_name: applicationNameOf(this.schema),
    };
    this.#pool = this.#poolFactory ? this.#poolFactory(opts) : new pg.Pool(opts);
    this.#pool.on('error', (err) => {
      // PUBLISH-FIX-84: an IDLE pooled client died (proxy idle cutoff, server restart): counted, logged once a minute at most, never a
      // reachability verdict — nothing was in flight on it; the next checkout or query decides (and marks) for real
      this.#clocks.idleClientErrors = (this.#clocks.idleClientErrors ?? 0) + 1;
      const now = Date.now(); if (now - (this.#lastIdleErrorLogMs ?? 0) > 60_000) { this.#lastIdleErrorLogMs = now; this.log(`PERSISTENCE idle pooled connection dropped (${err?.code ?? err?.constructor?.name ?? 'Error'}: ${boundedText(err?.message)}); not a reachability verdict`); }
    });
  }

  // Connect OR re-probe. The first call creates the pool and retries a
  // bounded number of times; every later call PROBES the existing pool with
  // one real round-trip, so an outage that ends is actually noticed — a pool
  // is never created per retry (no reconnect storm), and a failed pool is
  // never treated as permanently dead.
  async connect() {
    if (!this.configured()) return false;
    this.#ensurePool();
    const attempts = this.#everConnected || this.connectionErrors > 0 ? 1 : this.#retries;
    for (let attempt = 1; attempt <= attempts; attempt++) {
      const startedAt = Date.now();
      try {
        await this.#pool.query('SELECT 1');
        if (this.schema) {
          await this.#pool.query(`CREATE SCHEMA IF NOT EXISTS ${this.schema}`);
        }
        this.reachable = true;
        this.#everConnected = true;
        this.lastSuccessfulReadTs = Date.now();
        return true;
      } catch (err) {
        this.connectionErrors++;
        // PUBLISH-FIX-3: name the code AND the elapsed ms so an ETIMEDOUT (connect that hung to the timeout) is legible in
        // the production log, distinct from an instant ECONNREFUSED.
        this.log(`PERSISTENCE connect probe ${attempt}/${attempts} failed after ${Date.now() - startedAt}ms: ${err.code ?? err.constructor.name}`);
        if (attempt < attempts) await sleep(1000 * attempt);
      }
    }
    this.reachable = false;
    return false;
  }

  #qualify(text) {
    return this.schema ? text.replaceAll('serpent_', `${this.schema}.serpent_`) : text;
  }

  // Schema-qualified relation name for the rare statement that cannot carry
  // 'serpent_' in generated SQL text (e.g. dynamic constraint maintenance).
  qualifiedName(name) {
    return this.schema ? `${this.schema}.${name}` : name;
  }

  async query(text, params = [], { write = false } = {}) {
    if (!this.#pool) throw new Error('database not connected');
    const startedAt = Date.now();
    try {
      const r = await this.#pool.query(this.#qualify(text), params);
      this.reachable = true;
      if (write) this.lastSuccessfulWriteTs = Date.now();
      else this.lastSuccessfulReadTs = Date.now();
      this.#clocks.queryCount += 1; pushSample(this.#clocks.query, Date.now() - startedAt); // PUBLISH-FIX-50
      return r;
    } catch (err) {
      // PUBLISH-FIX-3: a connection-class failure (ETIMEDOUT / reset / statement timeout) is logged with its code and the
      // elapsed ms before it propagates, so a query that hung to the timeout is never silent. Ordinary query errors
      // (constraint, syntax) are the caller's to surface and are not logged here.
      if (this.#markConnectionFailure(err)) this.log(`PERSISTENCE query failed after ${Date.now() - startedAt}ms: ${err.code ?? err.constructor.name}: ${boundedText(err.message)}`);
      throw err;
    }
  }

  // One transaction, one client, rolled back on any throw. A connection
  // death inside a transaction marks the database unreachable — the error's
  // location never hides the outage from the permission lock. fn receives
  // (q, helpers): q qualifies 'serpent_' names; helpers.raw does not.
  async tx(fn) {
    if (!this.#pool) throw new Error('database not connected');
    const startedAt = Date.now();
    let client;
    for (let attempt = 1; ; attempt += 1) {
      try { client = await this.#pool.connect(); break; }
      catch (err) {
        // PUBLISH-FIX-84: one retry for a connection-class checkout failure — nothing has begun on it. Reviewer finding: only a FAST
        // failure is retried (a reset, a refused connect); a checkout that already waited the full connect timeout is a dead or
        // exhausted database and retrying would only double the time before the permission lock engages.
        if (attempt <= CHECKOUT_RETRIES && isConnectionError(err) && Date.now() - startedAt < CONNECT_TIMEOUT_MS / 2) { this.#clocks.checkoutRetries += 1; await sleep(CHECKOUT_RETRY_DELAY_MS); continue; }
        // PUBLISH-FIX-3: a checkout that hung to the connect timeout is logged with its code, its message and elapsed ms.
        this.#clocks.checkoutFailures += 1;
        if (this.#markConnectionFailure(err)) this.log(`PERSISTENCE tx checkout failed after ${Date.now() - startedAt}ms (${attempt} attempt${attempt > 1 ? 's' : ''}): ${err.code ?? err.constructor.name}: ${boundedText(err.message)}`);
        throw err;
      }
    }
    // PUBLISH-FIX-50: the checkout wait is what a pool of 5 shared with the tape costs this transaction; the transaction
    // clock starts once the client is in hand; statements and parameter bytes count what travelled
    const checkedOutAt = Date.now(); const meter = { statements: 0, paramBytes: 0, first: null };
    const metered = (text, params) => { meter.statements += 1; meter.paramBytes += paramBytesOf(params); if (meter.first === null && !/^(BEGIN|COMMIT|ROLLBACK)$/.test(String(text))) meter.first = String(text).slice(0, 48); };
    const q = (text, params = []) => { metered(text, params); return client.query(this.#qualify(text), params); };
    const helpers = { raw: (text, params = []) => { metered(text, params); return client.query(text, params); }, db: this };
    let discardError = null;
    try {
      await q('BEGIN');
      const result = await fn(q, helpers);
      await q('COMMIT');
      this.lastSuccessfulWriteTs = Date.now();
      this.reachable = true;
      return result;
    } catch (err) {
      this.transactionErrors++;
      const connectionFailed = this.#markConnectionFailure(err);
      // PUBLISH-FIX-3: a transaction that failed on a connection-class error (ETIMEDOUT / reset mid-tx) is logged with its
      // code and the elapsed ms; ordinary constraint/callback errors are the caller's to surface.
      if (connectionFailed) { discardError = err; this.log(`PERSISTENCE tx failed after ${Date.now() - startedAt}ms: ${err.code ?? err.constructor.name}`); }
      try {
        await q('ROLLBACK');
      } catch (rollbackError) {
        // A failed rollback leaves the session's protocol/transaction state
        // unproven even when the primary error was an ordinary constraint or
        // callback failure. Never return that client to the reusable pool.
        // Preserve the primary error for the caller while still applying the
        // shared reachability classifier to a distinct rollback failure.
        if (!connectionFailed) this.#markConnectionFailure(rollbackError);
        discardError = rollbackError;
      }
      throw err;
    } finally {
      if (discardError) client.release(discardError);
      else client.release();
      try { // PUBLISH-FIX-50: sample every transaction, failed ones included (a failed one still held the connection)
        const c = this.#clocks; const txMs = Date.now() - checkedOutAt; c.txCount += 1;
        pushSample(c.checkoutWait, checkedOutAt - startedAt); pushSample(c.tx, txMs); pushSample(c.txStatements, meter.statements); pushSample(c.txParamBytes, meter.paramBytes);
        if (!c.slowestTx || txMs > c.slowestTx.ms) c.slowestTx = { ms: txMs, statements: meter.statements, paramBytes: meter.paramBytes, first: meter.first, ts: Date.now() };
      } catch { /* clocks never fail a transaction */ }
    }
  }

  // PUBLISH-FIX-50: the database clocks for the log line — never the URL, never a row. Pool gauges come from pg's Pool
  // when it exposes them (totalCount / idleCount / waitingCount); a test pool without them reads null.
  clocks() {
    const c = this.#clocks; const pool = this.#pool;
    const gauge = (k) => (pool && typeof pool[k] === 'number' ? pool[k] : null);
    return {
      tx: { ...clockStats(c.tx), total: c.txCount }, checkoutWait: clockStats(c.checkoutWait), txStatements: clockStats(c.txStatements), txParamBytes: clockStats(c.txParamBytes),
      query: { ...clockStats(c.query), total: c.queryCount }, checkoutFailures: c.checkoutFailures, checkoutRetries: c.checkoutRetries, idleClientErrors: c.idleClientErrors ?? 0, slowestTx: c.slowestTx ? { ...c.slowestTx } : null,
      pool: { max: POOL_MAX, total: gauge('totalCount'), idle: gauge('idleCount'), waiting: gauge('waitingCount'), lockSessions: this.#lockClients.size },
    };
  }

  // RUMOR-2 freeze seal — one named session-scoped advisory lock. Advisory
  // locks belong to a PostgreSQL SESSION, and the pool reaps idle sessions,
  // so the winning client stays CHECKED OUT for the lock's whole lifetime
  // (one of the pool's five slots, deliberately long-lived). The server
  // releases the lock automatically when the session dies — process crash,
  // connection loss, pg_terminate_backend — which is exactly the failover
  // law the writer fence needs. Returns null when another session holds the
  // lock; otherwise a handle: held() turns false when the underlying
  // connection dies, release() unlocks and returns the client to the pool.
  async acquireSessionLock(name) {
    if (!this.#pool) throw new Error('database not connected');
    const startedAt = Date.now();
    let client;
    try {
      client = await this.#pool.connect();
    } catch (err) {
      // PUBLISH-FIX-3: a lock-session checkout that hung to the connect timeout is logged with its code and elapsed ms.
      if (this.#markConnectionFailure(err)) this.log(`PERSISTENCE lock checkout failed after ${Date.now() - startedAt}ms: ${err.code ?? err.constructor.name}: ${boundedText(err.message)}`);
      throw err;
    }
    try {
      const { rows } = await client.query('SELECT pg_try_advisory_lock(hashtext($1)) AS ok', [name]);
      if (!rows[0].ok) {
        client.release();
        return null; // another writer holds authority — fail safely, no busy loop
      }
    } catch (err) {
      client.release();
      this.#markConnectionFailure(err);
      throw err;
    }
    let lost = false;
    const onDeath = () => {
      lost = true;
    };
    client.on('error', onDeath);
    client.once('end', onDeath);
    this.#lockClients.add(client); // so end() can never hang on a held lock
    const release = async () => {
      client.removeListener('error', onDeath);
      client.removeListener('end', onDeath);
      this.#lockClients.delete(client);
      try {
        if (!lost) await client.query('SELECT pg_advisory_unlock(hashtext($1))', [name]);
      } catch {
        // a dead session already released the lock server-side
      }
      try {
        client.release();
      } catch {
        // already released/destroyed — nothing leaks either way
      }
    };
    // A query bound to THIS lock-owning session (schema-qualified like
    // db.query). It is how the writer epoch is advanced ON the very session
    // that holds the advisory lock: if that session dies, this query cannot
    // succeed, so a non-owner can never advance the epoch. A dead session
    // throws; a connection failure marks the pool unreachable exactly as
    // db.query does.
    const query = async (text, params = []) => {
      if (lost) throw Object.assign(new Error('lock session lost'), { code: 'LOCK_SESSION_LOST' });
      try {
        return await client.query(this.#qualify(text), params);
      } catch (err) {
        this.#markConnectionFailure(err);
        throw err;
      }
    };
    return { held: () => !lost, release, query };
  }

  // PUBLISH-FIX-5 — bounded acquisition wait for a BOOT-TIME owner lock. Replit keeps
  // the previous deployment container alive for a short overlap after a Republish; both
  // connect to the same PostgreSQL, so the outgoing process can still hold a boot lock
  // (the external-checkpoint owner lock, the RUMOR-2 writer lock) when the new boot tries
  // to take it. acquireSessionLock is try-once by design (a runtime writer fence must
  // fail fast on real contention); a boot lock instead waits out the overlap. This calls
  // acquireSessionLock repeatedly until it returns a handle or the budget is spent, logs
  // one line per waited attempt, and returns null on timeout — so every caller's existing
  // fail-closed behaviour and error codes on a null handle are UNCHANGED. pg_try_advisory_lock
  // semantics and the held()/release() contract are untouched; sleep is injected so tests
  // run without real delay.
  async acquireSessionLockWithWait(name, { timeoutMs = 180_000, intervalMs = 5_000, log = this.log, sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms)) } = {}) {
    const attempts = Math.max(1, Math.floor(timeoutMs / Math.max(1, intervalMs)));
    for (let n = 1; ; n += 1) {
      const lock = await this.acquireSessionLock(name);
      if (lock) return lock;
      if (n >= attempts) return null; // budget spent — fail closed, caller's null-handle path is unchanged
      log(`PERSISTENCE lock ${name} held elsewhere; waiting ${n}/${attempts}`);
      await sleep(intervalMs);
    }
  }

  async end() {
    // A held advisory-lock client is checked out for its lifetime, and
    // pool.end() waits for every client to return — so release the locks
    // FIRST or shutdown would hang (and the process would never exit).
    for (const client of this.#lockClients) {
      try {
        client.release(true); // destroy: the session (and its locks) end with it
      } catch {
        // already gone — nothing to reclaim
      }
    }
    this.#lockClients.clear();
    if (this.#pool) {
      const p = this.#pool;
      this.#pool = null;
      await p.end().catch(() => {});
    }
  }
}
