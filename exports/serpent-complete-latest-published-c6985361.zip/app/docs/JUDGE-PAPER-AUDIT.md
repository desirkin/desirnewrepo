# JUDGE — PAPER AUDIT AND FROZEN STATE

Verdict: `JUDGE_PAPER_COMPLETE`

Scope: `judge/*.js` (26 modules), `execution/*.js` (12 modules), `watch/watch.js`. Audited 2026-09-11 for the SERPENT
final paper closeout. The audit asks ONE question per law: is the PAPER path complete, truthful and closed (no stub, no
inferred authority, no lowered threshold), and is that proven by a test that fails when the law is broken?

## 1. Method

1. Static sweep of the three trees for stub markers (`TODO`, `FIXME`, `NOT_IMPLEMENTED`, `not implemented`, `placeholder`,
   `HACK`): zero hits.
2. Every module header names its ticket law; every law below cites the module and the test that proves it.
3. The PAPER vertical runs end to end over the REAL composition and PostgreSQL under the paper PROFILE
   (`test/paper-e2e-pg.test.js`, PE2E-1 / PE2E-2) — not over a mock Judge.
4. The three trees were NOT modified by the closeout (see §4: the frozen digests equal the baseline tree).

## 2. Laws and their proofs

| # | Law (PAPER) | Where | Proof |
|---|---|---|---|
| 1 | The paper profile's Judge policy IS the reviewed reference; no threshold, cap, lock, fee or evidence requirement changed | `config/judge.paper.json` byte-identical to `judge/samples/policy.paper-reference.json` | `test/paper-runtime.test.js` P-01, `test/paper-e2e-pg.test.js` (module load), `test/judge-focused-fences.test.js` C01 (reference sha pinned) |
| 2 | JUDGE_MODE is PAPER; JUDGE_ALLOW_PRIVATE / JUDGE_ALLOW_ORDERS are false and never inferred from credentials | `paper/profile.js` FORCED_ENV, `paper/launch.js` prepareLaunch, `judge/composition.js` readCredentials (LIVE only) | P-01, PE2E-2(e): a LIVE environment with key names present composes a PAPER run with `credentialsPresent=false`, transport never called; `composeJudge(LIVE_ARMED, paper policy)` refused |
| 3 | ONE shared entry-permission law (controls, restrictions, mode, authorization, clock, writer) before any reservation and again before any send | `execution/authority.js` entryPermission; `judge/judge.js` decide; `execution/dispatcher.js` pre-send | `test/judge-repair-authority.test.js` (R01), PE2E-2(b) KILL -> `ENTRY_REFUSED [KILL]`, PE2E-2(c) RECONCILIATION_REQUIRED refuses entry |
| 4 | KILL / CAGE / VETO preserved; hard restrictions clear only with owner intent | `execution/reducer.js` RESTRICTION (OWNER_CLEAR_REQUIRED), `judge/arming.js`, `judge/commands.js` | `test/judge-reducer.test.js`, `test/judge-repair-authority.test.js`, PE2E-2(c) CLEAR without ownerRef refused |
| 5 | A sealed Socrates case is READ-ONLY input, verified by bytes, refused when synthetic / from the future / stale; it never vetoes a market-driven setup by accident | `judge/case-source.js`, `judge/case-verify-worker.js`, `judge/intake.js` | `test/judge-e2e-pg.test.js` E2E-1, `test/judge-repair-evidence.test.js`, `test/judge-decisions.test.js` |
| 6 | Deterministic versioned setups over point-in-time facts; readiness is never permission; a silent socket breaks coverage and stops entries | `judge/setups.js`, `judge/readiness.js`, `judge/features.js`, `execution/feed.js` liveness | `test/judge-decisions.test.js`, `test/judge-feed-clock.test.js`, PE2E-2(a) silent market -> no entry, readiness not READY |
| 7 | Cost-aware admission with exact decimals; positive gross / negative net refuses; reward / stressed risk screen; largest legal lot inside cash, risk and cluster caps | `judge/cost.js`, `judge/risk.js`, `execution/money.js`, `execution/fees.js` | `test/judge-cost-capital.test.js` (0.8% reference refusals), `test/judge-money.test.js`, `test/judge-repair-accounting.test.js` |
| 8 | PAPER adapter: same instruments, reservations, fees, controls and lifecycle as LIVE; fills ONLY from observed book levels with depletion; never a convenient fill; pending at a crash -> EXPIRED (UNFILLED_COVERAGE_UNKNOWN) | `execution/paper-adapter.js` | `test/judge-adapters.test.js`, `test/judge-repair-restart.test.js`, PE2E-1 fill + protection |
| 9 | ONE account reducer validates every cause / reference relation and quantity sum; a FILLED status without executions is refused; late messages reconcile, never erase | `execution/reducer.js`, `execution/contract.js` | `test/judge-reducer.test.js`, `test/judge-repair-accounting.test.js` |
| 10 | PostgreSQL is the journal authority for PAPER; ONE writer per account, epoch-fenced; the chain replays and verifies; restart never mints a fresh USD 500 | `execution/journal.js`, `execution/dispatcher.js`, `judge/composition.js` start (replayVerify) | `test/judge-journal-pg.test.js`, `test/judge-repair-pg.test.js`, PE2E-1 replayVerify, PE2E-2(d) |
| 11 | Restart reconciles BEFORE any addition; uncertain orders / exposed positions reported; an incomplete reconciliation latches RECONCILIATION_REQUIRED | `execution/dispatcher.js` restart, `execution/paper-adapter.js` reconcile | `test/judge-repair-restart.test.js`, PE2E-2(c) latch survives restart |
| 12 | Watch: exposure first until exchange-confirmed flat; protection child before anything else; deterministic exit reasons (deterioration, invalidation, time, health); feed unusable -> halt with native stops retained | `watch/watch.js` | `test/judge-watch.test.js`, `test/judge-repair-exit.test.js`, PE2E-1 deterioration -> FLAT, PE2E-2(d) Watch resumes RESTORED |
| 13 | Projection / posture agree with the journal and are bound to the account, run mode and revision; a LIVE projection can never read as paper | `judge/composition.js` publishProjection, `state/execution-projection.js` | `test/judge-repair-projection.test.js`, `test/paper-runtime.test.js` P-04 (LIVE projection -> BLOCKED) |
| 14 | Permission clock: wall time observed, monotonic intervals; untrusted clock blocks LIVE and is recorded | `execution/clock.js`, `judge/replay-clock.js`, `judge/scheduler.js` | `test/judge-feed-clock.test.js`, `test/judge-repair-runtime.test.js` |
| 15 | Evaluation / challengers / holdout / release chain: nothing here grants authority; a paper result is a hypothesis until the independent chain says otherwise | `judge/evaluation` path in `judge/challengers.js`, `judge/experiment*.js`, `judge/arming.js` | `test/judge-evaluation.test.js`, `test/judge-holdout-truth.test.js`, `test/judge-experiment-*.test.js`, `test/judge-repair-arming.test.js` |
| 16 | The real Kraken adapter exists and is never reached by a PAPER run; a LIVE run needs a LIVE policy, an arm, a venue owner slot and an executions socket | `execution/kraken-adapter.js`, `judge/composition.js` | `test/judge-repair-kraken.test.js`, `test/judge-e2e-pg.test.js` E2E-2, PE2E-2(e) |

Test evidence for the three trees: 178 tests across `test/judge-*.test.js` and `test/paper-e2e-pg.test.js`; the full
regression at closeout is recorded in the final report (§11).

## 3. Bugs found by this audit

None in `judge/*`, `execution/*` or `watch/watch.js`. Two defects were found and repaired OUTSIDE the frozen trees while
wiring the paper profile: the sensor snapshot read the Judge projection from the process data dir instead of the snapshot's
own data dir (`paper/readiness.js`), and the dark-capture freshness law used a fixed 30-minute window although the runner
publishes per sealed segment (`paper/readiness.js`; now two segment lengths). Both carry regressions in
`test/paper-runtime.test.js` P-04. The bounded paper soak (`npm run paper`, 120 s, SIGTERM, exit 0) then found two more
defects outside the frozen trees, both repaired with regressions: the dark capture runner did not create its own
segments directory, so the capture command refused every segment (`paper/dark-capture.js`; P-06), and the sensor
snapshot derived DARK_CAPTURE_OPERATIONAL from a fresh heartbeat while the runner's own state said
DARK_CAPTURE_BLOCKED_EXTERNAL (`paper/readiness.js`; P-04). The Judge, execution and Watch trees needed no change.

## 4. FROZEN_FOR_PAPER

The three trees are frozen for the paper run. Any change to them must update this section (the fence in
`test/paper-runtime.test.js` P-08 recomputes these digests from the working tree and refuses a silent edit).

Digest law: `sha256` over the sorted repository-relative file list, each entry as `path + "\n" + bytes`.

```
FROZEN_FOR_PAPER
judge/*.js       37959eac34a71bc53104fcbd464c6b0ca35eda648745cbc5f4f605b9a7196f8e
execution/*.js   3d1fdb68416f9c097bc72f74f228d948bea45424d547ee0c7bdc68e7c58da8fa
watch/watch.js   6f319a1ee72a2b43346b8d07f906bb3ca31566ca7e3be0180d57f551d8a1afe1
all (49 files)   be769408aa1077b78c8921436cf9771aaa909196e60822fe571f773166d8f34d
```

### 4.32 Audited change — 2026-09-20 PUBLISH-FIX-83: the ONE full program review, every finding fixed (previous digests: judge `25153eda5c36…` → `37959eac34a7…`, execution `81bea0cccc0c…` → `3d1fdb68416f…`, watch/watch.js `0c6a43bf1ead…` → `6f319a1ee72a…`, all `ea28187cee2b…` → `be769408aa10…`; 49 files)

The owner's directive (2026-09-19, after weeks of "fixed everything" that did not hold): ONE review of the whole program
— "every door every closet every corner… under every rug" — then ONE list (38 items, `claude/serpent-full-review-2026-09-19.md`
in the project), then fix EVERYTHING on it ("not just the things that stop a bite"), then one more pass over every file
including the ones the surgery did not touch, then ONE publish. This entry records what changed inside the frozen trees.
Two independent adversarial reviewers read every core diff before this re-pin; their 24 findings are fixed and named below.

**execution/** (contract, dispatcher, feed, reducer)
- Item 2: the entry deadline is rebased at DISPATCH_ATTEMPTED (the durable attempt), not at the hypothesis — a slow
  append no longer eats the fill window. Item 3: an unfilled SHELL closes FLAT (`flattenUnfilledShell`) and settles its OPEN
  reservation first — on the ordinary path, on the restart path and on the remainder-cancel path (reviewer finding: the
  latter two had left reservations OPEN). Item 4: an adapter burst commits as ONE append, each event mapped against the
  state PROJECTED through the events before it (`reduceBatch` / `mapAdapterEvent`; the first cut mapped against the pre-fill
  state and read stop qty 0); a per-event failure isolates, EVENT_DUPLICATE counts as booked. `modeTs` joins the account
  state (ACCOUNT_STATE_VERSION → `execution-account-state-4`, the restoration law re-derives older projections).
- Item 16: a two-lane commit pump — `{ priority: true }` for entries, fills, exits and every Watch commit; ordinary commits
  (refusals, probes, measurements) queue behind; `chainSettled` is the ONE drain (reviewer finding: leftover `chain`
  references in reconcile/close broke 97 tests until every waiter used it). `bindStopOrder` is deferred until after the
  append (`pendingBindings` / `applyBindings`; a binding during projection had raced the reducer).
- Item 9 / 10 / 27 (feed): `unpin` steps a pin down without dropping its tracker or coverage; a receipt gap is only
  SUSPECTED (`pendingGap`) and is resolved by the venue clock (`resolveLiveness` / `breakCoverage`) — a processing stall
  whose messages carry a continuous venue clock is absorbed, real silence breaks coverage where messages resumed;
  `coverage()` reports `LIVENESS_GAP_SUSPECTED` while pending; a book/trade message naming no admitted symbol skips the
  lexeme parse on a symbol-named check (`SYMBOL_RE`; reviewer finding: the substring check was brittle) while its venue clock
  still vouches for liveness (`cheapSourceClock`).
- Item 6 (reducer): the owner's CLEAR carries a `clearedAt` watermark; RESTRICTION CLEAR events older latches by it; an
  owner CLEAR of PEAK_DRAWDOWN rebases the high-water mark (reviewer finding: the next valuation re-latched it otherwise);
  DAILY_LOSS inside its own session is still refused (logged once per CLEAR, never retried per tick).

**judge/** (composition, features, judge, readiness, setups)
- Item 7 (features): RV60 measures the TRAILING 60 s ending at the decision, 21 windows summed in one pass (item 26), with a
  5 s coverage-lag allowance (`RV60_COVERAGE_LAG_MS`); the completed-minute law read the empty minute BEFORE the move.
  Item 8: flow imbalance carries a trade-count floor (`FI_MIN_TRADES` 6) and widens its window 15 → 30 → 60 s
  (60 → 120 → 180 s) before reading UNKNOWN `TOO_FEW_TRADES` — one $3 print no longer reads −1. Item 12: the 10 bps depth
  band is measured from the best bid, not the mid. Item 11 (setups): RECLAIM_FI15 must be KNOWN by D.
- Item 13 (judge): a refusal on data-only gates gets a second look (`scheduleDataLook`, `DATA_LOOK_GATES`); an
  infrastructure refusal re-arms, bounded 3 per 5 min (`rearmAfterInfra`). Item 15: blind nominations are refused at
  admission; a 30 s re-cross hold after a refusal (`RECROSS_MIN_MS` in `createEpisodeTracker`; reviewer finding: the clock
  came from a future `expire()` and was counted per book — now `refusedAtTs`, counted once); refusal records coalesce
  (`commitRefusal` / `flushRefusals`); a probe memo (`probeFor`). Item 23: the learning bridge drains a queue of EVERY
  decision (`takeDecisions()`, 20k cap, 15-minute age bound) instead of sampling the cockpit ring. Item 37: counters
  `secondLooksEnded / Replaced / Superseded`, `secondLooksPending`, `bridgeQueueDepth` (a line comment had swallowed the
  block — `node --check` caught it; now a block comment). Readiness names the judged universe (`judgeExcludedCount`).
- Item 5 / 6 / 33 (composition): PAPER holds through a feed gap — the Watch latches FEED_IMPAIRED (source 'watch') and
  releases it when no open position is critical (`paperFeedHold` / `releasePaperFeedHold`; reviewer findings: a durable hold
  is ADOPTED by a fresh Watch after a restart — the log line is "durable restriction adopted locally"; hysteresis, no
  flapping); `applyOwnerClear` lifts every journal latch older than the owner's CLEAR and resumes PAPER after
  REDUCE_ONLY / HALTED_UNRESOLVED (`MODE_TRANSITION`), refusing nothing silently; the boot sweep closes leftover unfilled
  shells and releases pins no open position holds; ownerless CANDIDATE admissions are released in `admitNominations`;
  the projection is written on its timer only when dirty (item 28). The control plane's `mostRestrictiveControls` honours
  `clearedAt` EXCEPT for `integrityFailClosed` / `emergency` latches (reviewer finding: the watermark had silenced an
  emergency overlay kill).
- The 0.80% policy binding is NOT changed (a policy is immutable per account; a fee change is a new account — deliberate).

**watch/watch.js**
- Item 5: the paper feed hold (above) is the Watch's; every Watch commit rides the priority lane; `haltedLatched` re-arms
  after an owner resume so a second halt is latched again (reviewer finding).

Tests (all new or re-fixtured under the new laws): `test/publish-fix-83-execution.test.js` (FIX83-2, 3, 4, 9a, 9b, 16,
R1), `test/publish-fix-83-owner-clear.test.js` (FIX83-6, 33), `test/publish-fix-83-features.test.js` (FIX83-7, 8, 10, 12,
27), `test/publish-fix-83-collectors.test.js` (FIX83-29, ROT), judge-decisions DL-01 / BN-01 / BQ-01, judge-repair-runtime
R09-05 (LIVENESS_GAP_SUSPECTED), and the fixtures that the deliberate law changes moved (SHELL→FLAT, warm-up protection,
trailing RV60, re-cross hold, two-look forward groups, prefixes, digests). Learning, tape, ui, rumint, rumor2, survey,
lanes, memory and lib changes of the same review live OUTSIDE the frozen trees and are recorded in the project doc.
The full suite was run file by file (each file its own process) before this re-pin; the result is recorded in the project
status doc for 2026-09-20.

Authority unchanged: no order, size, exit or strategy law moved; no new sense, no new strategy (FREEZE stands); learning
remains ranking-only and always ON with the kill file ARMED; `THRESHOLD CHANGES: NONE` remains the authority line for
hand changes. What moved are rulers (RV60 window, FI floor, depth band), plumbing (batching, lanes, holds, sweeps) and the
owner's CLEAR — each one named above with its test.

The Judge differential (`test/judge-differential.test.js`) is re-based from `ea3bfbf` to `1bfa669`, the last commit of this
review: the rulers above moved on purpose, so a byte-identical differential against the pre-review Judge is no longer the
claim; the claim from here is that the working-tree Judge equals the audited tree at `1bfa669` until the next §4 entry.

### 4.31 Audited change — 2026-09-19 PUBLISH-FIX-82: GATE LEARNING — the Judge moves his own flow lines from his own scored looks, inside fixed bands, without the owner's say-so (previous judge digest `d86afbd55cf3…`; now `25153eda5c36…`; 49 files; execution and watch UNCHANGED)

The owner's directive, in his words (2026-09-19 afternoon): "I want him to move the gate once it's tested enough and he
should be doing thousands and thousands of tests every day before he can move the gate if we feel the patterns changed
enough" and, that evening: "I don't want to have to see if I want him to adjust when he has enough evidence to adjust
without me having to say so." The same evening's read of his ledger showed why: he had looked at the day's +50% mover 70
times and the closest look read 19.6% buying pressure against the 20% line; across 369 scored looks the line separated
nothing (heavy selling +0.06% at 15 minutes, strong buying +0.07%). A line somebody typed, defended by nothing.

- `judge/setups.js` `LEARNABLE_GATES`: the ONLY lines a lesson may move — FI15 (ref 0.2, band [−1, 0.5]), FI60_POSITIVE
  (ref 0, band [−1, 0.3]), RV60 (ref = the setup's own rv60Min, band [0, 3]), RECLAIM_FI15 and FI15_FRESH_AT_D (ref 0.2,
  band [−1, 0.5]); steps 0.05 / 0.25. `learnedLine(learned, id, reference)` answers the learned line only when it is a
  finite number inside the band, else the reference. `evaluateSetup({..., learned })`, `structuralClauses` and
  `fastClauses` thread it; each clause row's `threshold` is the line that judged it (the ledger scores later tests
  against the line actually used). Structural clauses (levels, stops, geometry, compression, EMAs) are NOT learnable.
  At a band's floor every KNOWN value passes; an unknown value still fails — a gate is moved, never blinded.
- `judge/judge.js` port `gateLearning` ({ lesson(setupId) → { FI15: 0.15, RV60: 1.5, … } }): read ONCE per decision per
  setup (one look is judged on one set of lines); lines re-validated against `LEARNABLE_GATES`; a faulting port reads as
  absent; the record carries a `GATE_LEARNING` MEASUREMENT row naming every line in force that differs from its reference.
  Port absent → reference lines, the record byte for byte as before. `judge/composition.js` passes it through.
- `learning/gate-lesson.js` (not frozen; learning/ never imports judge/ — GL-08 proves the band table mirrors
  `LEARNABLE_GATES` exactly): `testsOf` joins every look (episode gates: observed value, line, whether every OTHER real
  gate passed) with its scored 15-minute continuation return (decision-outcome yardstick); `evaluateUnit` tests, for a
  gate at line L, the first candidate below L whose NEWLY ADMITTED cohort (other gates ok) reaches `minCohort` and the
  first above L whose EXCLUDED cohort does; a LOOSEN needs the newly admitted cohort's mean ≥ 0 and bootstrap confidence
  ≥ `confidence` that the admitted set's mean does not fall by more than `tolerancePct`; a TIGHTEN needs the excluded
  cohort's mean < 0 and the same confidence that the admitted mean rises. `computeGateLesson` runs the cycle per gate
  (RV60 per setup): PROPOSED → forward test on `minForward` looks scored AFTER the proposal (the same test, on those
  looks alone) → PUBLISHED (the Judge's line moves) → kept under forward test → REVERTED to the line before when the
  cohort it admitted turns negative with confidence; WITHDRAWN when the forward looks do not hold a proposal. One step per
  gate per cycle. Every transition is one log line with its numbers. The kill file (`data/learning/kill.json`, KILLED /
  invalid / unreadable) → reference lines.
- `tools/gate-study-process.js` / `tools/gate-study-child.js`: the join runs in a child process every 30 minutes (90 s
  after boot first); the main thread never reads the ledger; the lesson lands in `data/learning/gate-lessons/lesson.json`
  (+ `state.json` with the proposal history). `fly.js` composes the reader as the Judge's port.
- `learning/judge-decision-bridge.js`: `MOVE_CLOCK`, `SECOND_LOOK` and `GATE_LEARNING` rows are measurements, never
  ledger gates (the move clock's "no move in progress" row had been landing as a failed gate on most looks).
- Paper profile `groups.judge.gateLearning` ON → `JUDGE_GATE_LEARNING` + `JUDGE_GATE_MIN_SCORED` 1000 /
  `JUDGE_GATE_MIN_COHORT` 100 / `JUDGE_GATE_MIN_FORWARD` 100 / `JUDGE_GATE_CONFIDENCE` 0.8 — the evidence minimums are
  named there for the owner to change by name, never by asking.

Tests: GL-01 (the join; measurement rows are not gates; lookback), GL-02 (below minScored nothing moves), GL-03 (LOOSEN
one step, empty bands stepped over), GL-04 (LOOSEN refused when the cohort cost or would drag the mean), GL-05 (TIGHTEN),
GL-06 (PROPOSED → PUBLISHED → REVERTED, one move per cycle, lines and log), GL-07 (RV60 per setup; the kill file),
GL-08 (band mirror), GL-09 (the study end to end; idempotent), GL-10 (judge-decisions: the same FI15-only refusal
reserves under a learned line with the GATE_LEARNING row; outside the band / faulting port / no port → the reference).
Full suite green before re-pinning.

Authority unchanged: the lines move inside their bands; no order, size, exit, strategy or structural clause is touched;
`THRESHOLD CHANGES: NONE` remains the authority line for hand changes — these are the Judge's own, each one logged.

### 4.30 Audited change — 2026-09-19 PUBLISH-FIX-81: independent review cb305c6e, F4 + F5 on the move clock — the clock measures over the study's own two-hour horizon and honours the learned-influence kill file (previous judge digest `4f8c9e59c77e…`; now `d86afbd55cf3…`; 49 files; execution and watch UNCHANGED)

The review's finding F5 was a real defect: the mover study measures low-to-peak over the hour before the event and the hour
after (up to 120 minutes), but the runtime read the move's age from the Judge's 61-bar block only — a learned late minute
above 60 could never be reached, so MOVE_TOO_OLD could never fire (the first nine archive measurements put the 75th
percentile near 100 minutes). Finding F4: the move-clock lesson was wired beside the learning ranking source and did not
consult `data/learning/kill.json`, so a KILLED (baseline) run still carried a learned timing refusal; the learned re-look
nomination (learning/relook.js) had the same gap.

- `judge/history.js` `bars(symbol, nowTs, count = BARS_REQUIRED)`: an optional count; the setups still receive exactly 61.
- `judge/move-clock.js`: `MOVE_CLOCK_DEFAULTS.lookbackBars` 60 → 120; `MOVE_CLOCK_BARS = 121`.
- `judge/judge.js`: the move-clock facts are read from `history.bars(symbol, D, 121)` when the history can serve a
  contiguous two-hour block, else from the frozen 61-bar setup block (the fallback measures ages up to 60 as before).
  The setup evaluation, the frozen references and every clause are untouched (`c.indicatorsRef.bars` unchanged).
- `learning/move-clock-lesson.js` (not frozen): KILLED / unreadable / invalid kill file → the lesson reports DORMANT
  (`lateMin` null, `killed.reason`), the line says so, the measurement continues. `learning/relook.js`: the same law for
  the learned nomination — evidence measured and reported, nothing re-offered while KILLED.
- Port absent → baseline byte for byte, as before.

Tests: MC-01 (two-hour lookback; 60 when asked; a 121-bar block measures a 101-minute age), MC-03 (KILLED → DORMANT;
invalid file → DORMANT; ARMED again), MC-04 (a 95-minute-old move refused under lateMin 80 through the two-hour block;
the setups still reserve under a DORMANT lesson), RL-04 (the re-look under KILLED). Full suite green before re-pinning.

Not changed, on purpose: F1 (the 0.40% taker reference is the owner's directive of PUBLISH-FIX-67 and is labelled
UNVERIFIED in the policy itself; the owner decides) and F2 (the boot latch clear is the owner's explicit directive of
PUBLISH-FIX-75; the durable CLEAR that does not persist across boots is the underlying defect, logged for repair).

### 4.29 Audited change — 2026-09-19 PUBLISH-FIX-79: THE SECOND LOOK — a look refused only on buying-pressure gates is retaken at the same level a few minutes later, every gate at full strength (previous judge digest `f476916f6544…`; now `4f8c9e59c77e…`; 49 files unchanged in number; execution and watch UNCHANGED)

The owner's directive, in his words: "I don't want to loosen the gates, but I wanna match up the times and the studying
because I know things have passed its eyes that fall within his parameters" and, this morning, "fix the thing that will
make him miss the winners."

The evidence (the gate match-up of 2026-09-19 over 807 graded live-judge episodes, 141 winners at >0.8% in 15 min or
>1.6% in 1 h): on the winners the Judge actually judged and refused, the failing clauses were the buying-pressure gates
— PRIOR_MID_RESPONSE_SMALL 10, PRIOR_FI_ABSORBED 8, FI15 7 (observed −0.33 against 0.2), FI60_POSITIVE 6, RV60 6 — the
structure was right and the look came a few minutes early, before the flow showed up. And the crossing law made that
final: `createEpisodeTracker` only reports a crossing on a below→above transition, so a coin that keeps climbing after
an early look is never looked at again until it dips back under the level.

The change, port-gated (`createJudge({ secondLook })`; `composeJudge` passes it; fly.js composes it from the paper profile
`groups.judge.secondLook` → `JUDGE_SECOND_LOOK_AFTER_MS` / `JUDGE_SECOND_LOOK_MAX`; port absent → nothing here runs and the
decision record is the baseline byte for byte, the judge-differential law):

- `judge/setups.js` `createEpisodeTracker.rearm()`: refused while an episode is pending; otherwise sets `below = true` so
  the NEXT book at/above the level is a fresh crossing (new episode id, new frozen references, new durable lock, new
  confirmation). The cooldown, the reset on a dip, the expiry: unchanged. Counter `rearms`.
- `judge/judge.js`: `SECOND_LOOK_FLOW_GATES` = FI15, FI60_POSITIVE, RV60, PRIOR_FI_ABSORBED, PRIOR_MID_RESPONSE_SMALL,
  RECLAIM_FI15. A NO_TRADE whose refused clauses are ALL in that set schedules ONE second look per candidate/setup
  (`WAITING`, due after `afterMs`, at the frozen trigger level, carrying the look count). A NEEDS_DATA or a structural
  refusal ends the chain; an ELIGIBLE look ends the chain. On the tick: a due look whose coin still has a fresh book with
  the mid at/above the level and no pending episode re-arms the tracker (`ARMED`; logged); a mid below the level drops it
  (`secondLooksDropped`); a stale book past `staleMs` drops it. The next crossing on an ARMED look is `CROSSED` (counter
  `secondLookCrossings`; `looks += 1`) and that decision carries one MEASUREMENT row `SECOND_LOOK` (value = look number,
  threshold = maxLooks, note names the earlier refusal). A natural crossing on a non-armed look starts a new chain. Bounded:
  `maxLooks` per chain (profile 2, hard cap 4), `afterMs` ≥ 15 s (profile 180 s).
- No threshold, no clause, no size, no exit moved. The second look is a second EVALUATION, not a second chance: the coin
  must pass FI15, FI60_POSITIVE, RV60 and every other clause exactly as at a natural crossing.

Tests: `test/judge-second-look.test.js` SL-01 (the tracker law), `test/judge-decisions.test.js` SL-02 (live path: a
FI15-only refusal, the wait with the coin holding its level, the re-armed crossing reserves with the SECOND_LOOK row;
port absent → one refusal, no rearm, baseline) and SL-03 (a coin that gives the level back drops the look). The full
suite ran green before the digests above were re-pinned.

### 4.28 Audited change — 2026-09-18 PUBLISH-FIX-73: the move clock — a look at a coin whose own move is as old as the minute most movers top out by is refused MOVE_TOO_OLD (previous judge digest `d70c8fe64e22…`; now `f476916f6544…`; the frozen set grows to 49 files with `judge/move-clock.js`; execution and watch UNCHANGED)

The owner's rule (his son's question, his words): "if it comes down at 30 minutes every time and it's been 28 minutes while
evaluated, then it should know not to get into it because it's probably too late." Until now the Judge measured a
crossing without asking how far into its move the coin already was.

What the mover study now measures (learning/mover-study.js, not frozen): every MOVER / control picture carries a
`moveClock` — the minute of the move's lowest close in the hour before the event, minutes from that low to the event,
minutes from that low to the highest close anywhere up to the end of the hour after (`minutesLowToPeak`), and the climb
low-to-peak. What the lesson says (learning/move-clock-lesson.js, NEW, authority NONE): over the last 7 daily study
files, the MOVER records that carry a move clock; DORMANT under 20 of them, ARMED at 20 with `lateMin` = the 75th
percentile of `minutesLowToPeak` (three of four measured movers had topped out by then; floor 5) and the median for
the record; re-read every 5 minutes; logged as `MOVE CLOCK: …` on every change and on the JUDGE FUNNEL line.
Records written before this change carry no clock, so the count starts at zero and the lesson is DORMANT until the
study has measured 20 new movers — the Judge records but refuses nothing on it until then.

The change to the frozen tree (judge/move-clock.js NEW, pure; judge/judge.js): a new OPTIONAL port `moveClock`
(`{ lesson() }`), null by default — with the port absent nothing new runs and every decision record is the baseline
byte for byte (`test/judge-differential.test.js` unchanged). With the port composed (judge/composition.js →
fly.js, wired only when the lesson reader started): for every decision that reaches the setup evaluation the Judge
takes the bar block it already froze for the decision, finds the lowest close of the last 60 closed bars, and records
two MEASUREMENT rows `MOVE_CLOCK` — the move's age in minutes at the decision (threshold: the learned late minute) and
the climb since that low in percent (threshold: the lesson's minimum climb, 5% — under it the coin is not "in a move"
and the clock does not apply). After the setup is ELIGIBLE (all existing gates passed, `funnel.setupQualified`
counted), and ONLY while the lesson is ARMED and the coin is in a move at least `lateMin` minutes old, the decision is
refused `NO_TRADE ['MOVE_TOO_OLD']` with the rows on the record and `counters.moveTooOld` on the funnel line. A port
that throws reads as absent for that decision (logged). Unchanged: T, the lock-before-valuation law, every existing
gate and its order, sizing, admission, the 10 s. Tests: `test/judge-move-clock.test.js` MC-01..03 (facts, verdict,
rows, lesson from files) and `test/judge-decisions.test.js` MC-04 (live path: an ARMED lesson refuses a 46-minute-old
+8.7% move with the age and climb recorded; the same bars under a DORMANT lesson still reserve; a faulting port is
baseline). `test/paper-runtime.test.js` P-08 re-pinned.

### 4.27 Audited change — 2026-09-18 PUBLISH-FIX-70: hypothesis locks that queue behind an in-flight lock append are committed together (previous judge digest `380e23374f2f…`; now `d70c8fe64e22…`; execution and watch UNCHANGED)

What was happening (1e76a415, first 3 minutes after the §4.24/§4.25 boot): AKE/USD crossed its trigger 301 times (300
resets) — a coin oscillating around the level — and every crossing locked a hypothesis with its own serialized journal
append: 363 commits in 3 minutes, journal commit p50 3.7 s / p95 22 s / max 49 s, every decision record queued behind
the locks. §4.24 keeps those decisions alive while the lock lands, but a saturated chain still lands most locks late.

The change (judge/judge.js only): `lockHypothesis()` hands its HYPOTHESIS_LOCKED event to a coalescing queue. While a
lock append is in flight, every further lock waits in the queue; when the append lands, the whole queue goes as ONE
append (`dispatcher.commit([...events])`, the journal appends the list atomically and the reducer applies it in order).
The chain carries one append per round trip instead of one per crossing. A refused batch falls back to one append per
lock, so one refusal never sinks the others; each lock's own promise resolves when its append lands (so §4.24's
re-offer fires per lock exactly as before). Counters `lockBatches` / `lockCoalesced` join `lockWaits` / `lockReoffered`
on the JUDGE FUNNEL line (fly.js). Unchanged: T, the lock-before-valuation law, the lock payload, the order of events,
the 10 s, every gate. The ONE observable difference: `portfolioRevision` (the account's append count at decision time)
and the `decisionDigest` sealed over it move by the number of coalesced appends — `test/judge-differential.test.js`
compares both trees with the revision set to 0 and the digest re-sealed through the working tree's own contract, and
everything else raw (documented normalization 2). Test: J10d also proves the locks behind a held one are committed
together (`lockBatches >= 2`, `lockCoalesced >= 1`). `test/paper-runtime.test.js` P-08 re-pinned.

### 4.26 Audited change — 2026-09-18 PUBLISH-FIX-69b: ACCOUNT_STATE_VERSION 2 → 3 so the restoration law re-derives projections written before §4.25 (previous execution digest `d58aea0ebc0d…`; now `81bea0cccc0c…`; judge and watch UNCHANGED)

What happened: 1e76a415 (fix64–69) booted 21:50 UTC and stopped right after "JUDGE specs" — no "JUDGE active". The
restoration law (judge/composition.js start(), closeout R16) replays the durable chain with the CURRENT reducer and
compares its digest to the STORED projection; §4.25's reducer evicts answered hypotheses, the projection stored by the
previous instance still held them, and because `stateVersion` was unchanged the law took the refusal branch
(RESTORE_FAILED) instead of the reprojection branch. My omission: a reducer change that alters the projection must move
`ACCOUNT_STATE_VERSION` (execution/contract.js), which is the signal the law uses to re-derive the projection from the
verified chain (`jr.reproject`, chain verified first, `RESTORE_FAILED` if the reprojection disagrees with the replay).
The change: `ACCOUNT_STATE_VERSION = 'execution-account-state-3'` with the reason in its comment. Nothing else moves;
`test/judge-repair-pg.test.js` R16-04 (a corrupted projection still refuses) and `test/judge-differential.test.js`
(the version move is the second half of the one documented normalization) hold. Expected boot line on the next start:
"account paper-starting-styles-usd500-fee040: projection re-derived from N events after a reducer version change
(execution-account-state-2 -> execution-account-state-3)".

### 4.25 Audited change — 2026-09-18 PUBLISH-FIX-69: a hypothesis leaves the account state once its decision is recorded (previous execution digest `83c4ce652d38…`; now `d58aea0ebc0d…`; judge and watch UNCHANGED)

What was happening: `execution/reducer.js` kept every HYPOTHESIS_LOCKED payload in `state.hypotheses` forever (9,303 after
20 h on 794afa2b). Every journal commit re-reads and re-writes the whole account-state JSON, so the commit cost grew all day:
journal commit p50 2.1 s three minutes after boot, 10.5 s (p95 217 s, max 491 s) after 20 h, with the main thread stalling on
the parse (465 stalls, worst 6.1 s). That growth is what turned the lock-durability race of §4.24 from an edge case into
65% of all decisions.

The change (execution/reducer.js only): `DECISION_RECORDED` deletes `state.hypotheses[decisionId]` after its checks (the
decision record carries what the law still reads); `HYPOTHESIS_LOCKED` sweeps any hypothesis still undecided an hour past
its `expiresTs` (`HYPOTHESIS_SWEEP_MS`). Both are pure functions of the event stream, so a replay reaches the same state.
The price-blind law is unchanged: a sized decision still needs its locked hypothesis, and the lock always precedes the
decision by at most the 10 s proposal life (`test/judge-reducer.test.js` RED-02 still refuses PRICE_BLIND_LAW). Nothing
outside the reducer reads `state.hypotheses`. Execution / adjustment identities stay durable (never evicted, closeout
R03 / R06). Test: RED-08 — answered hypotheses (sized or not) are gone, an undecided one is kept for half an hour and
swept an hour past its expiry by the next lock, a sized decision without its lock is still refused, fifty lock/decide
pairs leave nothing behind. `test/paper-runtime.test.js` P-08 re-pinned.

### 4.24 Audited change — 2026-09-18 PUBLISH-FIX-68: a decision that runs before its hypothesis lock is durable steps aside inside its 10 s and is re-offered when the lock lands (previous judge digest `12508ea61c86…`; now `380e23374f2f…`; execution and watch UNCHANGED)

What was happening (794afa2b, 20 h): 4,058 paper decisions, 2,646 of them NEEDS_DATA / HYPOTHESIS_NOT_DURABLE (65%).
The HYPOTHESIS_LOCKED commit is serialized behind every other journal write (execution/dispatcher.js commit chain), so a
burst of crossings queues seconds of commits; the confirmation arrives ≥ 2 s after T and the decision job found the lock
not yet durable — and `decide()` refused at once, although the proposal still had most of its 10 s.

The change (judge/judge.js only): `decide()` on an unlocked hypothesis INSIDE the proposal's 10 s records nothing and
steps aside (`frozen.awaitingLock`, counter `lockWaits`); `lockHypothesis()` — the moment its commit lands — reopens the
still-pending episode through the PUBLISH-FIX-51 re-offer path (`ep.submitted = false; ep.reoffer = true`, counter
`lockReoffered`): the next fresh book re-submits the SAME episode (same T, same 10 s, not a new confirmation), and the
decision is made on a fresh snapshot against a durable lock. One re-offer per lock, never a polling loop. A lock still
not durable when the 10 s end changes nothing: the episode expires exactly as before, and the EXPIRED record now carries
`HYPOTHESIS_NOT_DURABLE` beside `PROPOSAL_EXPIRED_10S` so the cause stays visible; an unlocked hypothesis reaching
`decide()` past the 10 s is the NEEDS_DATA / HYPOTHESIS_NOT_DURABLE it always was. Unchanged: T, the 10 s expiry, the
100 ms staleness rule, the price-blind law (no valuation before the durable lock), the lock order, every gate and cost
rule, the decision record contract (reason codes are a list). Test: `test/judge-decisions.test.js` J10d — held locks: the
decisions step aside (nothing recorded, needsData 0), the landed locks reopen every offer, the fresh book re-submits, and
the SAME episodes reach the SAME statuses as the unheld control inside their 10 s; a lock that never lands inside the 10 s
expires with both codes and reopens nothing afterwards. The test fails on the previous judge (J10d not ok) and passes on
this one. `test/paper-runtime.test.js` P-08 re-pinned.

### 4.23 Recorded change — 2026-09-18 PUBLISH-FIX-67: the paper profile's reference fee is the Kraken Pro public 0.40% taker (frozen core UNCHANGED; no digest moves)

Not a frozen change: `judge/`, `execution/` and `watch/watch.js` are byte-identical to §4.21. What changed is the paper
PROFILE (`config/paper-runtime.json`): `files.judgePolicy` and `groups.judge.judge.policyFile` now name
`config/judge.paper.starting-styles-fee040.json` (judge-policy-2, the same six setups as §4.22) whose `fees.taker.rate`
is `0.004` — Kraken Pro's PUBLIC spot taker base rate — instead of the `0.008` placeholder of PUBLISH-FIX-19, and the
account it binds, `paper-starting-styles-usd500-fee040`. The fee is still UNVERIFIED against the owner account (the
`scheduleId` says so) and is replaced only by the owner tier read from `TradeVolume` (`lib/kraken-fee-tier.js`).
Everything else in the policy — limits, execution controls, universe, evaluation, capital, the fee's rounding, scope,
minimum and currency — is byte-identical to the reference policy, proven at module load by `test/paper-e2e-pg.test.js`
(the profile policy IS `judge/samples/policy.paper-starting-styles-fee040.json` byte for byte; every section but `setups`
and the taker `rate`/`scheduleId` equals the reference's). `test/paper-runtime.test.js` P-01 pins the file name. The
same account law as §4.19/§4.22 applies: a changed policy names its own account, the boot creates it ONCE under owner
intent (`SERPENT_PAPER_INIT_ACCOUNT` = `paper-starting-styles-usd500-fee040`), and the earlier accounts
`paper-reference-usd500-fee080` and `paper-starting-styles-usd500` and their journals stay untouched and readable.
Reason: the owner's directive and the independent review of f32484ca (fee finding): at 0.80% a side the 1.6% round
trip was larger than every 20-minute target the setups can name, so the Judge was arithmetically inert; 0.40% is the
published rate, not an assumption of the owner's tier. The cost model, its rounding and the NO_TRADE law are unchanged.

### 4.22 Recorded change — 2026-09-18 PUBLISH-FIX-62: the paper profile names the six-setup policy (frozen core UNCHANGED; no digest moves)

Not a frozen change: `judge/`, `execution/` and `watch/watch.js` are byte-identical to §4.21. What changed is the
paper PROFILE (`config/paper-runtime.json`): `files.judgePolicy` and `groups.judge.judge.policyFile` now name
`config/judge.paper.starting-styles.json` (judge-policy-2; setups MOMENTUM_CONTINUATION, RANGE_IGNITION,
TREND_PULLBACK_CONTINUATION, ABSORPTION_RECLAIM, CATALYST_TRANSMISSION, MICRO_BITE) and the account it binds,
`paper-starting-styles-usd500`. The same account law as §4.19 applies: a changed policy names its own account, the boot
creates it ONCE under owner intent (`SERPENT_PAPER_INIT_ACCOUNT` = that name, PUBLISH-FIX-58 waits out the republish
overlap), the reference account `paper-reference-usd500-fee080` and its journal stay untouched and readable, the Judge
refuses to migrate a v1 ledger to v2 (`test/judge-starting-styles-composition.test.js` STRAT-C04). Fees (the UNVERIFIED
0.80% taker), limits, execution controls, universe and evaluation are byte-identical to the reference policy — proven at
module load by `test/paper-e2e-pg.test.js` (the profile policy IS `judge/samples/policy.paper-starting-styles.json` byte
for byte, and every section but `setups` equals the reference's). `test/paper-runtime.test.js` P-01 pins the file name.
Reason: the independent review of f32484ca (finding 5) and the owner's directive that every trade strategy be in front
of the Judge. Learning is not account-bound; the promoter's sealed `policyDigest` binding means any lesson frozen under
judge-policy-1 does not apply to judge-policy-2 (none had been published).

### 4.21 Audited change — 2026-09-17 PUBLISH-FIX-51: a decision cancelled as stale is offered again on the next fresh snapshot inside its own 10 s (previous judge digest `df462599953c…`; now `12508ea61c86…`; execution and watch UNCHANGED)

Finding (production 4dd77a32, JUDGE FUNNEL 17:13 local, first line with the fix47 clocks): 17 confirmed decisions, 10
cancelled by the scheduler's 100 ms queue rule before they ever ran (`scheduler queue-expired 10`), 0 entries. The rule is
right — a job that waited more than 100 ms is stale for ITS snapshot (the main thread was blocked; the 25 ms bucket timer
could not fire) — but `judge.js` marked the episode `submitted` once and never offered it again, so a cancelled episode
sat idle until its 10 s ran out and was stamped `EXPIRED / PROPOSAL_EXPIRED_10S`. Over the day: 361 of 1,040 decisions.

What changed: `judge/scheduler.js` `submit()` accepts an optional `onStale` and calls it (try/catch, logged) when THAT
queued job is cancelled as `QUEUE_DELAY_EXPIRED` — unsent work only, the replay record unchanged; `judge/judge.js` passes
`onStale` from the confirmation path: if the episode is still `PENDING` it clears `submitted`, so the NEXT accepted book
(`observe` keeps answering `CONFIRMED`) re-submits the decision on a FRESH snapshot with the same key / episode; the
re-offer is not a second confirmation (`counters.confirmations` unchanged) and is counted as `counters.staleReoffered`.

What did NOT change: the episode's trigger T, its 10 s expiry (`decide()` still refuses `PROPOSAL_EXPIRED_10S` past it,
`onTick` still expires the tracker), the confirmation law, the 100 ms staleness rule, the price-blind lock order, every
status / refusal / sizing / risk input. A run with no stall is byte-identical (`test/judge-differential.test.js`
unchanged); `test/judge-decisions.test.js` J10b pins the scheduler notice (stale only, never superseded, a throwing
listener is logged) and J10c proves the live path: the same ignition with a 150 ms stall after confirmation now decides
inside the original 10 s with the same episodes and the same statuses as the unstalled control, where before it died
to `PROPOSAL_EXPIRED_10S`. Authority NONE changed: the Judge decides sooner, never differently.

### 4.20 Audited change — 2026-09-17 PUBLISH-FIX-38: the six prepared learning facts ride every decision's measurements (previous judge digest `8b8b84332656…`; now `df462599953c…`; execution and watch UNCHANGED)

What changed: `judge/learning-intake.js` gains `learnedFactMeasurements(features)` — one measurement row per prepared
fact (`id LEARNED_FACT`, `note` = the fact name, `ok` = KNOWN, `value` = the fact or null, `unit` as prepared); `judge/judge.js`
prepares `learnedFactsOf(fast, frozen)` once per evaluation, hands it to the selector exactly as before, and — ONLY when a
learning port is composed — appends the six rows (`rv60 fi15 fi60 spreadBps depthUsd10bps atrPct`) to the decision's
measurements before the existing `LEARNED_RANK_ADJUSTMENT` row.

What did NOT change: no status, refusal, sizing, risk, scenario, valuation or ranking input reads these rows; with the
port absent the decision record is byte-identical to the baseline (`test/judge-differential.test.js` still passes
unchanged; `test/judge-learning-intake.test.js` PRESERVATION now also asserts the six rows appear with the port and never
without it). The rows exist so the learning bridge can record what the market looked like when the Judge decided —
the input a learned "when" needs. Authority NONE; the Judge never reads its own trace.

### 4.19 Audited change — 2026-09-17 PUBLISH-FIX-23: the 0.80% policy binds a NEW paper account, `paper-reference-usd500-fee080` (frozen digests UNCHANGED: judge `8b8b84332656…`, execution `83c4ce652d38…`, watch/watch.js `0c6a43bf…`, all `6166dc44ad39…`)

Scope: `config/judge.paper.json` (+ byte-identical `judge/samples/policy.paper-reference.json`), `config/paper-runtime.json`
(the profile's JUDGE_ACCOUNT), `fly.js` (one explanatory log line beside the existing failure line). No frozen file changed.
Finding: production boot aac10add after PUBLISH-FIX-19 — `JUDGE failed to start … ACCOUNT_POLICY_MISMATCH:
paper-reference-usd500 was initialized under another policy binding`. The law in `judge/composition.js` is exact and
kept: an account's `policyDigest` / `policyVersion` are immutable, a mismatch is never an implicit migration or reset.
Changing the fee changed the policy digest, so the old account can no longer run it.

Law now: a changed policy names the account it binds. `policyName` and `account.accountId` are
`paper-reference-usd500-fee080`; the boot initializes it ONCE under owner intent through the existing
`lib/paper-account-init.js` path (`SERPENT_PAPER_INIT_ACCOUNT` = the same name, verified against the policy, password
via `SERPENT_CONTROL_PASSWORD`, audit line written, refuses to reset). The previous account and its journal stay
untouched and readable (history is never rewritten); the learning memory is not account-bound. When David's own Kraken
tier replaces the UNVERIFIED 0.80%, the digest moves again and the policy names its next account the same way. The
Judge failure line now states this law beside `ACCOUNT_POLICY_MISMATCH` / `ACCOUNT_UNINITIALIZED`. Proof:
`test/paper-runtime.test.js` P-01 (the policy IS the reference byte for byte), `test/paper-account-init.test.js`
(the boot init path refuses a name that differs from the policy's), `test/judge-composition-input-binding-review.test.js`
(ACCOUNT_POLICY_MISMATCH still refuses).

### 4.18 Audited change — 2026-09-17 PUBLISH-FIX-19 (independent review F1 / F1b): the paper taker reference is an UNVERIFIED conservative 0.80%; null fee fields are never a verified tier (frozen digests UNCHANGED: judge `8b8b84332656…`, execution `83c4ce652d38…`, watch/watch.js `0c6a43bf…`, all `6166dc44ad39…`)

Scope: `config/judge.paper.json` (+ its byte-identical reference `judge/samples/policy.paper-reference.json` and the
opt-in `config/judge.paper.starting-styles.json`), `lib/kraken-fee-tier.js`. No frozen file changed. Finding: 4.12
set the paper taker to 0.40% and called it the verified Kraken Pro base; the review read the public schedule on
2026-09-16 and found a 0.80% spot taker base tier, and no account tier was ever read for this account. The review's
witness on the identical book: rate 0.004 => OK at reward/risk 2.21; rate 0.008 => REFUSED at 1.04 — the fee input is
authoritative and the 0.40% figure was not established. Separately (F1b) `lib/kraken-fee-tier.js` coerced a null /
missing fee field with `Number()` (null → 0) into a VERIFIED zero-percent ACCOUNT_TIER.

Law now: the paper fee is `0.008` `PAPER_REFERENCE`, labelled in its scheduleId as UNVERIFIED conservative, to be
replaced ONLY by the owner's own tier read from TradeVolume through the read-only reader (David reads his tier; the
figure is never assumed). Historical records keep the fee contract they were dispatched under (the fee digest travels
in every decision and fill; nothing is rewritten). The reader accepts only a number or a numeric string as a fee
figure; null / missing / boolean / empty / non-numeric fields answer `FIELDS_MISSING` and the base schedule. Proof:
`test/kraken-fee-tier.test.js` FEE-6 (null / missing / boolean / empty / non-numeric → BASE_SCHEDULE FIELDS_MISSING;
a numeric string still resolves), `test/judge-five-family-composition-positive.test.js` (all five families still
qualify their fixtures under 0.8%, fee rate `0.008` recorded), `test/paper-runtime.test.js` P-01 (the paper policy IS
the reviewed reference byte for byte), `test/judge-starting-styles-composition.test.js` STRAT-C01.

### 4.17 Audited change — 2026-09-17 PUBLISH-FIX-17 (independent review F4): the paper depletion map holds only safety-relevant levels (previous digests: execution `2551fcb6c4d0…`, all `f0526120a879…`; judge `8b8b84332656…` and watch/watch.js `0c6a43bf…` UNCHANGED)

Scope: `execution/paper-adapter.js` `observeBook` only. Finding: every distinct price ever displayed on any admitted
book created a depletion entry (`dep(k)` on every change) and its removal left a tombstone forever; the review's witness
(10,000 distinct levels added and removed with zero orders) left 10,000 map entries and 10,000 checkpoint rows. The map
grew with price diversity for the life of the process, and every paper checkpoint carried it.

Law now: an entry exists only for a level that carries safety information — a consumed quantity or a continuity-loss
mark. A level nothing was ever taken from answers `available` identically with or without an entry (max(0, Q − 0) = Q),
so it gets none, and its removal (Q = 0) leaves nothing. A CONSUMED level's removal keeps its tombstone, so the
generation law (reset only after an explicit removal followed by a newly observed positive level) is unchanged; an
uncertain level is kept the same way; a tombstoned level whose consumption was already reset is dropped at its next
removal. `available`, `walk`, `consume`, the fill sampling rule, the continuity-loss marking, the checkpoint format and
restore are byte-unchanged. Proof: `test/paper-depletion-compaction.test.js` (the review witness → 0 entries, empty
checkpoint; consumed level survives 500 unrelated levels, keeps its tombstone through removal, restart conserves the
consumed quantity, re-add is generation 2, reset level dropped at its next removal; continuity loss still marks and
retains) and `test/judge-adapters.test.js` P09 unchanged. The execution digest moves to `83c4ce652d38…` and the whole
frozen set to `6166dc44ad39…`, which `test/paper-runtime.test.js` P-08 re-verifies.

### 4.16 Audited change — 2026-09-17 PUBLISH-FIX-14 (independent review F5): learning wired into the Judge, ranking-only (frozen digests UNCHANGED: judge `8b8b84332656…`, execution `2551fcb6c4d0…`, watch/watch.js `0c6a43bf…`, all `f0526120a879…`)

Scope: composition only — `fly.js`, `.replit`, `lib/learning-ranking-source.js` (new), `lib/learning-activation-steward.js`
(new), `lib/learned-selection-state.js` (new), `ui/server.js`. No file under `judge/`, `execution/` or `watch/` changed.
Finding: the review was right — learning was OFF twice over. `LEARNING_ENABLED` was never set for the deployment (LEARN-1
capture / maturation / pattern memory never ran), and `composeJudge` was never given a `learningActivationSource`, so
the consumer seam that ADDENDUM-2 §08 built and `test/judge-learning-intake.test.js` proves (a decision's rank changes by
the bounded nudge, nothing else) was dormant in every boot. Two further structural blocks were measured and are recorded
here, not hidden: (1) `lib/decision-memory-port.js` runs its reader in a worker thread whose V8 `resourceLimits` do NOT
bind when the process carries a heap flag — the deployment runs under `NODE_OPTIONS=--max-old-space-size=1400`
(PUBLISH-FIX-9), so the thread's measured heap limit was the parent's 1424 MB and the worker refused every request
(`WORKER_RESOURCE_LIMIT_INVALID`); (2) the same worker withholds every activation the current promotion law can produce
(`learning-activation-1` → `ACTIVATION_V1_EFFECT_AND_FEATURE_RECIPE_BODY_UNSEALED`). Through that port no learned
adjustment could ever reach the Judge. Sealing the v2 activation contract it demands (feature-recipe body digest +
effect transform in the artifact, verified by `judge/learning-intake.js`) touches the frozen core and is a separate
ticket (BACKLOG B-14); the port stays dormant and unchanged.

Law now: under `SERPENT_LEARNING_RANKING=true` (PAPER only; `.replit` production + development) fly.js composes
`lib/learning-ranking-source.js` as the Judge's `learningActivationSource`: the validated DECISION view
(`learning/memory-view.js readDecisionMemory` — an activation enters only when its pattern head is bound
`ACTIVE_PAPER`, its sealed design / evidence / terminal digests, consumer binding (feature recipe version + policy
digest), scope, validation block and null size limit re-verify against the prospective journal, with the kill file
beside it). The Judge's own snapshot cache copies it immutably and refreshes it in the maintenance lane, never in
admission; `resolveLearningContribution` applies at most the allowlisted rank-order nudge inside the activation's
`maxAbsAdjust` — statuses, refusals, sizing, risk, exits and the Watch untouched. A fault in the source answers "no
snapshot" and the Judge decides at baseline. The ACTIVATION STEWARD (`lib/learning-activation-steward.js`, 60 s,
unref'd, PAPER only) is the one runtime act that takes a promotion-published activation from
`PUBLISHED_WAITING_FOR_PAPER` to `ACTIVE_PAPER` (reason `PAPER_RUNTIME_ADOPTED`, both journals) and retires it at its
lifetime (`EXPIRED` / pattern `RETIRED`); it creates, validates and scores nothing. BASELINE ARM: `cobra learning kill`
(data/learning/kill.json `KILLED`) → every decision baseline while collection and learning continue; `cobra learning arm`
restores. OFF SWITCH: unset `SERPENT_LEARNING_RANKING` → no source is composed. The cockpit's
`integrity.switches.learnedSelection` now reports the live state (`ON_RANKING_ONLY (snapshot prepared …)`,
`ON_RANKING_ONLY_BASELINE_ARM (learned influence KILLED)`, `ON_RANKING_ONLY_WAITING`, `OFF_NOT_ENABLED`,
`OFF_NO_PAPER_JUDGE`) instead of the constant `OFF_NOT_WIRED`. Boot logs `LEARNING RANKING: ON (…)` and the steward logs
`LEARNING RANKING status: …` on every change. `LEARNING_ENABLED=true` starts LEARN-1 as documented (authority NONE).

Proof: `test/learning-activation-steward.test.js` (the real promotion fixture: waiting → invisible to the selector;
one pass → both heads `ACTIVE_PAPER`, the contribution applies, idempotent; paper-not-active refuses; lifetime →
`EXPIRED` + `RETIRED`; unreadable store contained), `test/learning-ranking-wiring.test.js` (store → steward → the composed
source → the Judge's snapshot cache → the nudge applied inside the bound; kill file → baseline; enable unset → nothing
composed), `test/judge-learning-intake.test.js` (unchanged: with the seam present and nothing eligible only the audit
row differs; with one validated in-scope candidate only the rank contribution and its measurement appear),
`test/learning-fences.test.js` and `test/integrity-boundary.test.js` (fences rewritten from "the seam is dormant" to
"the seam is gated on PAPER + the explicit enable, through the one named source, the worker port not composed").

### 4.15 Audited change — 2026-09-17 PUBLISH-FIX-12 (independent review F2): fair rotation of the preparation slots (previous digests: judge `6b8908a4b256…`, all `b058952b3925…`; execution `2551fcb6c4d0…` and watch/watch.js `0c6a43bf…` UNCHANGED)

Scope: `judge/readiness.js` (`selectPreparation`) and `judge/composition.js` (`admitNominations`). Finding: the standing
tape universe is stamped once (4.13's OR-2 law, which stopped the six slots flipping every cadence), so with more
nominations than slots the SAME six assets held the slots forever — the independent review's witness reproduced it: 30
stable nominations, six slots, 100 refreshes, the same six every time, 24 never prepared. The Judge saw 14 pairs and
could only ever evaluate six of them.

Law now: a prepared candidate holds its slot for a TENURE (`PREP_TENURE_MS` = 60 min: enough to warm — 61 bars + 21 min
of flow — and then be evaluated for a while). Once its tenure is up and other eligible nominations are waiting, the
longest-tenured tenant yields to the nomination that has waited longest (never prepared first, then oldest last
release), at most ONE rotation per `PREP_ROTATION_INTERVAL_MS` (10 min), so the warm set never churns. What is
unchanged: held / pending exposure never contests a slot; a genuinely NEWER nomination (a real event, never a
re-affirmation) still preempts the tenant with the oldest nomination; the nomination TTL still expires from the last
affirmation. New: at equal clocks a current tenant outranks a non-tenant and a rotated-in tenant carries its rotation
clock as its rank, so the tenant it replaced cannot bounce straight back and a newer nomination preempts an original
tenant rather than the newcomer. A rotated-out candidate is released with the reason `ROTATED_FOR_FAIRNESS` and the
composition logs every rotation (`preparation rotated for fairness: X out after N min, Y in …; waiting: …`). The
policy may override both clocks (`universe.preparationTenureMs`, `universe.preparationRotationIntervalMs`); the paper
policy carries neither, so the constants apply. Tests: `test/judge-preparation-rotation.test.js` (the review witness with
the correct expectation: 30 assets, six slots, a day of refreshes — all 30 prepared, no tenant rotated before its tenure,
at most one rotation per interval, no bounce-back, held untouched), `test/judge-operational-repair.test.js` OR-2a/OR-2b
(updated to the tenure law), `test/judge-composition.test.js` J11/E03 (unchanged expectations). The judge digest moves to
`8b8b84332656…` and the whole frozen set to `f0526120a879…`, which `test/paper-runtime.test.js` P-08 re-verifies.

### 4.14 Audited change — 2026-09-16 PUBLISH-FIX-10: the Judge's per-book evaluation no longer starves the event loop (previous digests: judge `aae0b5dc1899…`, execution `68222023e144…`, all `9dd72c5919bc…`; watch/watch.js UNCHANGED `0c6a43bf…`)

Evidence: production PAPER boots 954229d8 / b88bca71 / 0972bcbe blocked the main thread for 9 s, 13 s, 57 s and 61 s at a
time with a tiny heap (`RESOURCE_WARNING lag=61567ms heap=155MB`), starving the cockpit, the health check and the
PostgreSQL socket. The in-process sampler (`lib/cpu-profile-report.js`, opt-in) named the code: `parseDecimal money.js`
63%, `medianDecimal features.js` 16%, `normalize`/`align` money.js, `fastFacts judge.js:247`, `onBook judge.js:265` —
every book update computed `fastFacts` once PER SETUP (six times) and each computation sorted the 60 s prior-depth window
with `M.cmp` (a BigInt parse per comparison) and re-parsed every trade lexeme in the flow windows.

Scope: exactness is untouched — no Number ever enters arithmetic; three changes, each a pure speed-up with the same result:
- `execution/money.js`: (1) `cmp` fast path — for two plain decimal lexemes of at most 20 significant digits (ECMAScript's
  correctly-rounded range) that convert to DIFFERENT doubles, the exact order equals the double order (correct rounding is
  monotonic); equal doubles, longer or non-plain lexemes take the exact BigInt path. (2) `parseDecimal` memoizes the
  default-bound parse in a bounded, cleared-when-full map of frozen `{ int, scale }` values (identical lexeme → identical
  value). (3) `out()` no longer re-parses its own canonical `formatDecimal` output (pure cost; formatDecimal is canonical
  by construction).
- `judge/features.js`: `medianDecimal` sorts by double for plain ≤20-digit lexemes and falls back to the exact sort
  whenever the doubles adjacent to the middle collide (a tie could hide a different exact order) or any lexeme is
  long/non-plain. The returned value is the same exact string / exact half-up average.
- `judge/judge.js`: `onBook` computes `fastFacts(c, snap, snap.receiptTs)` ONCE per book update and hands the same
  object to every setup (the inputs are identical per setup; nothing in the setup loop mutates flow, books or the snapshot).
- `judge/judge.js` (second pass, same day — boot f566132c still showed `cmp` 57% with the tape shed to zero pairs, the
  Judge draining a backlog of ticks): the WINDOW aggregates of `fastFacts` (fi15/fi60/rv60/vwap60/priorFi/reclaimFi, the
  prior-mid change, the 60 s prior-depth median, the prior low) are recomputed at most once per 250 ms per candidate
  (`windowFacts`, keyed on decision time and feed epoch); the per-snapshot facts (mid, best bid/ask, spread, book age,
  depth within 10 bps, crc, receipt sequence, snapshot digest) are recomputed on every tick exactly as before. A decision
  may therefore see flow windows up to 250 ms older than its snapshot — on the 5m/15m decision horizon this is below the
  tape's own 5 s snapshot cadence, and it is the difference between a Judge that runs and one that starves.
- `judge/features.js` (second pass): `medianDecimal` keys on a native `Float64Array` sort and resolves the exact lexeme at
  the median position by counting doubles below it; a run of equal doubles is ordered exactly only when its strings differ.
- Verified: `test/money-cmp-fast-path.test.js` (cmp vs exact ordering on adversarial near-equal lexemes and 20,000 random
  lexemes; medianDecimal vs an independent exact reference over 300 random lists plus collision / long-lexeme / trailing-
  zero cases; memo identity and non-default bounds), and the whole judge/execution/paper suite green. The frozen set
  digest moves to `b058952b3925…`, which `test/paper-runtime.test.js` P-08 re-verifies.

### 4.13 Audited change — 2026-09-16 PAPER-FLIP-PREP (a): the boot waits out a Republish overlap for the execution writer lock (previous digests: judge `a38fa9ed86e5…`, execution `676e15339b6c…`, all `1a287ba4471a…`; watch/watch.js UNCHANGED `0c6a43bf…`)

Scope: `execution/journal.js` and `judge/composition.js` only; the writer FENCE, epoch establishment,
per-commit epoch check, replay/verify, projection, sizing, reducer, reservation, fee and fill law are all
byte-for-byte unchanged. This mirrors PUBLISH-FIX-5 for the RUMOR-2 / checkpoint owner locks.

- `execution/journal.js`: `createPgJournal` gains an optional `lockWait = null`. `acquireWriter` is **try-once by
  default** (a runtime writer fence must fail fast on real contention — every CLI, REPLAY, experiment-replay and
  test caller keeps this, and `WRITER_HELD` still raises immediately). When the boot creator injects
  `lockWait { waitMs, intervalMs }` AND the Db exposes `acquireSessionLockWithWait` (PUBLISH-FIX-5), the
  acquisition polls that bounded wait so a Replit Republish overlap — the outgoing deployment still holds the
  advisory lock for a few seconds — is waited out instead of failing the boot. On timeout the wait returns null
  and the existing fail-closed path (`WRITER_HELD`) is unchanged. `pg_try_advisory_lock` semantics, the epoch
  INSERT/UPDATE on the lock session, and `held()` / `release()` are untouched.
- `judge/composition.js`: `composeJudge` gains a `writerLockWait = null` pass-through, forwarded to
  `createPgJournal({ lockWait })` ONLY when it creates the PAPER / LIVE journal itself. An injected journal (tests,
  experiment replay) is unchanged; the memory journal is unchanged. fly.js (the root, not frozen) supplies
  `{ waitMs: 180_000, intervalMs: 5_000 }` at the real production boot, so only that boot opts into the wait.
- Verified: `test/execution-journal-lock-wait.test.js` (pure — try-once default, waits then acquires, fail-closed
  on spent budget, falls back to try-once without the waiting variant); the PostgreSQL journal / e2e tests
  (`judge-journal-pg`, `judge-e2e-pg`, `paper-e2e-pg`) pass unchanged against PostgreSQL 16; and a local
  `npm run paper` boot reaches `JUDGE active: PAPER account paper-reference-usd500 mode PAPER` and `TAPE LIVE`.
  The whole frozen set digest moves to `9dd72c59…`, which `test/paper-runtime.test.js` P-08 re-verifies.

### 4.12 Audited change — 2026-09-15 Ticket A (fees): the paper taker reference is the Kraken Pro base rate 0.40%, not 0.8% (frozen digests UNCHANGED)

Scope: CONFIGURATION ONLY — `config/judge.paper.json`, its byte-identical reference `judge/samples/policy.paper-reference.json`, and `config/judge.paper.starting-styles.json` change the taker `rate` from `0.008` to `0.004` (Kraken Pro's real base schedule: 0.40% taker / 0.25% maker; the maker rate lives in the separate read-only fee-tier reader, used by maker-first entry later). NO frozen `.js` byte changed: `judge/*.js`, `execution/*.js` and `watch/watch.js` read the rate as data from the loaded policy, so the fee flows into fills and cost-aware admission unchanged in code. The Judge's eligibility logic is robust to the correction — `test/judge-five-family-composition-positive.test.js` (all setups) qualifies / refuses exactly as before at the lower fee; only the reference `fee.rate` assertions moved to `0.004`. Paper now pays exactly what a base-tier live account pays as a taker. The whole frozen set digest is UNCHANGED (`all (48 files) 1a287ba4…`), which `test/paper-runtime.test.js` P-08 re-verifies from the working tree.

### 4.11 Audited change — 2026-09-15 Ticket Z part B: depth-capped whole-nut is the LIVE paper sizing law (previous digests: judge `babd2f69…`, all `5ef55b6e…`; execution `676e1533…` and watch `0c6a43bf…` UNCHANGED)

Scope: `judge/size-ladder.js` (one new option) and `judge/judge.js` (thread it). No decision, permission, exit, reducer, reservation, fee, or fill law changed; the ladder still runs the UNCHANGED `sizeSearch` cost law and the risk caps still bind every size.

David's decision: the live paper sizing law is **depth-capped whole-nut** — turn the size ladder on for the live PAPER Judge (fractions 0.25/0.5/0.75/1, absorption objective = the largest bite the book absorbs cleanly), with the loss law that the most one bite may lose is 3% of the nut, so the whole nut goes in whenever the structural stop is within 3% and the bite shrinks on wider stops; upside is never capped. Pure all-in stays a REPLAY arm until SIZING qualifies.

- `judge/size-ladder.js`: `evaluateSizeLadder` gains `allInEvidence` (`'REQUIRED'` default | `'RISK_BOUNDED'`). Under `RISK_BOUNDED` the fraction-1 (whole-nut) candidate drops the `CANDIDATE_MAX_SIZE_EVIDENCE` prerequisite and competes bounded by the risk law (`scenarioStressedLoss ≤ riskBudget`, enforced inside `sizeSearch` for every fraction) plus the absorption/sustainability objective and the protective-exit-at-depth check. `'REQUIRED'` (the default) is byte-behaviour-identical to before — the evidence gate still holds full balance ineligible without qualified learning — so the REPLAY `SIZING_PURE_ALL_IN` arm stays learning-gated.
- `judge/judge.js`: threads `allInEvidence: dynamicSizing.allInEvidence` into the ladder (default preserved when a caller omits it).
- Not frozen: `fly.js` wires `dynamicSizing = { fractions: ['0.25','0.5','0.75','1'], allInEvidence: 'RISK_BOUNDED' }` for `JUDGE_MODE === 'PAPER'` only (REPLAY drives its own per-arm sizing; LIVE composes the Kraken adapter and is unaffected). `config/judge.paper.json` (byte-equal reference sample + starting-styles): `maxModelledRiskPerPositionFraction`/`maxAggregate…`/`maxCorrelatedCluster…` all → 0.03 (the 3% loss law); `maxGross`/`maxAsset` stay 1 so the whole nut is spendable. The `integrity-boundary` and `ui/server` dynamic-sizing status were updated to reflect the deliberate live wiring.

Proof: `test/judge-size-ladder.test.js` (RISK_BOUNDED all-in: REQUIRED refuses fraction 1 without evidence, RISK_BOUNDED lets the whole nut win when the book absorbs it, a tight risk budget shrinks the bite), the existing ladder/learning-intake/sizing-review tests unchanged (default `'REQUIRED'`), and the full suite green at this commit.

### 4.10 Audited change — 2026-09-15 Ticket Z (sizing side by side): two REPLAY-only sizing arms (pure all-in vs depth-capped) (previous digests: judge `35f7be96…`, all `126b58d0…`; execution `676e1533…` and watch `0c6a43bf…` UNCHANGED)

Scope: `judge/experiment-replay.js` only (the offline REPLAY experiment engine). No decision, permission, exit, reducer, reservation, fee or fill law changed; `judge/judge.js`, `judge/cost.js`, `judge/size-ladder.js`, `judge/risk.js` and the live sizing path are byte-unchanged. The live PAPER Judge still runs the fixed `sizeSearch` (fly.js never passes `dynamicSizing`); SIZING remains UNSUPPORTED in `learning/adaptive-registry.js` until separately qualified.

David's decision (PHILOSOPHY.md, Position & sizing): the paper runs **pure all-in vs depth-capped all-in side by side**. Both realise the whole-nut spirit over the SAME risk-bounded budget and cost law, differing only in whether the book's absorption caps the bite. The pre-existing dynamic size ladder (`judge/size-ladder.js`, default-off, unchanged) already expresses both; this change wires it as two REPLAY arms:
- `SIZING_DEPTH_CAPPED` (`dynamicSizing.fractions = ['0.25','0.5','0.75','1']`): the full ladder; the sustainability objective selects the largest size whose marginal fills do not degrade the net return beyond tolerance — the largest bite the book absorbs cleanly. Fraction 1 competes only with the all-in prerequisites, so without qualified sizing evidence it caps below full balance — the live "largest bite" law.
- `SIZING_PURE_ALL_IN` (`dynamicSizing.fractions = ['1']`): the whole-nut candidate alone. Learning-gated: `ALL_IN_PREREQUISITES` (incl. `CANDIDATE_MAX_SIZE_EVIDENCE`) hold it ineligible until SIZING qualifies, so the arm is DORMANT (no eligible size, no trades) until then.

The arms live ONLY in `EXPERIMENT_ARMS` (invoked via `replay-experiment --arms …`), never in the policy's `evaluation.arms` (the legacy `evaluateArms` HISTORICAL_ATTRIBUTION path replays one recorded ledger and cannot re-size — it says so, and disclaims sizing comparison). `replayExperiment` threads `dynamicSizing: def.dynamicSizing ?? null` into each FUNDED arm's `composeJudge` (REPLAY); `composeJudge` already accepted and forced it null under nothing-but-REPLAY here. Both arms are their own USD-500 REPLAY accounts consuming the same stream.

Proof: `test/judge-experiment-replay.test.js` S09 (DEPTH_CAPPED enters through the ladder at a sustainable sub-full size recording DYNAMIC_SIZE_SELECTION + SIZE_CANDIDATE rows; PURE_ALL_IN refuses NO_ELIGIBLE_SIZE_ON_LADDER with zero positions — dormant; two independent accounts; deterministic), S04 (the arm table stays closed: every arm FUNDED/MATCHED), and the full suite green at this commit.

### 4.9 Audited change — 2026-09-15 Ticket P (paper realism): the paper fill delay is the live-measured Kraken round-trip, not a fixed 250ms (previous digests: judge `8702f68ebeeb…`, execution `dd321ce97e24…`, all `43669403af15…`; watch `0c6a43bf…` UNCHANGED)

Scope: `execution/paper-adapter.js` and `judge/composition.js` (a new optional pass-through parameter). No decision, permission, sizing, reducer, reservation, fee or fill-sampling law changed; the fill still samples the FIRST accepted post-arrival book within the same bounded window, walks displayed depth with the same depletion, and takes the same taker fee. Only WHEN the arrival happens is now measured.

David's decision (PHILOSOPHY.md, Decided doctrine c — paper realism): a paper fill happens against the recorded book a REALISTIC delay after the decision, and that delay is the LIVE-MEASURED Kraken round-trip from the gateway collector, widened when Kraken reports degraded — never a fixed assumption ("venue: stay on Kraken; latency measured, not assumed").

- `execution/paper-adapter.js`: `createPaperAdapter` gains an optional `latencySource` (a `() => ms` reader). When present and returning a finite positive number it is the simulated arrival delay for every entry, exit and stop fill (read PER fill, so a mid-run degradation widens the very next arrival); a null / NaN / non-positive / throwing reading falls back to the fixed conservative default (entry `latencyMs` 250 / exit `exitLatencyMs` 250) — the sim never fills FASTER on a bad reading. With no source injected the adapter is byte-for-byte behaviour-identical to before (the fixed 250ms). The measurement itself, its bounds and the degraded widening live OUTSIDE the frozen tree in `lib/paper-fill-latency.js` (`effectiveFillLatencyMs`) fed by `gateway/collector.js` `readGatewayLatency`; the frozen adapter only consumes the injected number.
- `judge/composition.js`: `composeJudge` gains a `paperLatencySource` pass-through, forwarded to the paper adapter as `latencySource` — but forced to `null` under REPLAY so an offline experiment stays deterministic (the C01/H-fences: a replay never reads the live gateway matrix). LIVE composes the Kraken adapter and never sees it. fly.js (the root, not frozen) supplies `() => effectiveFillLatencyMs(readGatewayLatency(dataDir()))`.

Proof: `test/judge-adapters.test.js` P-LAT (an injected source drives arrival off the 250ms default; entry and stop fill; every bad reading and a throwing source fall back), `test/paper-fill-latency.test.js` PFL-1..6 (the model + the accessor), the existing P01..P-series (no source → identical 250ms behaviour), and the full suite green at this commit.

### 4.8 Audited change — 2026-09-15 Ticket 4 exit law: no live target; the D4 experiment flipped (previous digests: judge `638038da03d8…`, watch `be41c4bed1ce…`, all `345b28be7c89…`; execution `dd321ce9…` UNCHANGED)

Scope: `watch/watch.js` and the frozen experiment framework (`judge/challengers.js`, `judge/experiment-replay.js`). No decision, permission, sizing or reducer law changed; `entryPermission()` and the reducer are untouched; the paper profile still forces `JUDGE_MODE=PAPER` / no private / no orders.

David's decision (PHILOSOPHY.md, Decided doctrine): the live exit law has **no target price or percent anywhere**. A position rides until its ENTRY THESIS is invalidated (thesis falsification, flow/liquidity deterioration, edge-state decay), its protective stop or 1R trail is crossed, or a backstop timer fires; the 180 s no-progress and 4 h max timers are backstops, not the exit; the protective stop (native / structural / trail) is kept.

- `watch/watch.js`: `plannedTargetEnabled` now defaults to **OFF** (`exitPolicy?.plannedTarget === true`) — the live PAPER path (no exitPolicy) never takes a planned target and computes no target basis. The planned full exit at the frozen scenario target is RETAINED only as an opt-in research counterfactual carried by a REPLAY experiment arm. `finalizeR` computes the target basis only under the opt-in; a new `lazyTargetBasis` derives the in-memory basis for an already-FINAL position under the opt-in (a restored position, or the experiment's matched clone that begins after its reference's R was FINAL) without re-committing POSITION_R. `PLANNED_TARGET` stays a valid `execution/contract.js` EXIT_REASON (replay/restore of an in-flight exit and the experiment fixtures depend on it — execution/ is byte-unchanged).
- The D4 experiment is FLIPPED (`judge/experiment-replay.js`): `D4_EXIT_POLICY` is now `{ plannedTarget: true }`; the REFERENCE arms (no explicit exitPolicy) run the live no-target law; the D4 arm is the counterfactual that ENABLES the planned target, measuring whether adding it helps against the live no-target reference. The `D4_TRAIL_CONTINUATION_*` arms are renamed `D4_PLANNED_TARGET_*` (name follows meaning) across `judge/challengers.js`, `judge/experiment-replay.js`, the policy/config samples and docs.

Proof: `test/judge-watch.test.js` W01/W06 (the live law never takes a target; rides past the scenario target; the opt-in counterfactual still exits at the target), `test/judge-watch-escalation-review.test.js`, `test/judge-repair-restart.test.js` (target basis durable under the opt-in), `test/judge-experiment-replay.test.js` S01/S04 (REF = no-target, D4 = with-target on the same entry), and the full suite green at this commit.

### 4.7 Audited change — 2026-09-14 runtime unification step 3: fly.js onto the spine (frozen digests UNCHANGED)

Scope: the composition root only. `judge/`, `execution/` and `watch/watch.js` are byte-identical — the digests above did
not move — and `judge/composition.js` is untouched. fly.js is the root, not a frozen tree.

- `fly.js` derives `SERPENT_MODE` fail-closed (DATA_ONLY iff the data-only launcher pinned `SERPENT_DATA_ONLY`; PAPER iff
  `COBRA_PROFILE` is present AND every forced authority name holds — `JUDGE_MODE=PAPER`, `JUDGE_ALLOW_PRIVATE=false`,
  `JUDGE_ALLOW_ORDERS=false`; anything else exits 1 before composing anything: `test/serpent-mode-law.test.js`).
  DATA_ONLY delegates to the step-2 spine. PAPER runs today's sequence on the spine: the single-instance runtime lock is
  taken FIRST (a second instance on the same data dir refuses in either mode), then `startPersistence` (signals now owned
  by the runtime, `registerSignals: false`), the external-quota restore, and — new to the ship — the collector additions
  (market catalogs, broad Kraken capture, public discovery; `lib/collectors.js startPaperCollectorAdditions`, authority
  NONE, own transports and durable quotas). The Tape remains the signal owner; the spine's ordered stop (additions in
  reverse, checkpoints closed, persistence stopped, lock released) runs after the tape drains and after the Judge, the
  research service and the paper seam have stopped — so the DB is alive for every drain that needs it.
- What did NOT change: the Judge composition call and everything passed to it, `entryPermission()` and its call sites,
  the paper profile's forced names, the RUMOR-2 wiring (strainer, catalog source, Childhood bridge — byte-identical in
  fly.js), press/infra/video/gateway/wide-eye/governance/rumint starts, the learning opt-in, the cockpit order
  (PERSIST-0A §2 holds: the runtime establishes the persistence bootstrap before `ui/server.js` listens).

Proof: `test/serpent-paper-spine.test.js` PR-1..3 (injected starters: restore order, exact addition set and options, no
spine signals in PAPER, reverse stop, one-lock law both modes, fail-closed restore), `test/serpent-mode-law.test.js`
MODE-1..3 (spawned refusals before any write), and the untouched P-0x / fence suites; full suite green at this commit.

### 4.6 Audited change — 2026-09-14 lean trim step 1: one bankroll, one daily-lock law (previous digests: judge `b0f322af5648…`, execution `9e03f82702ce…`, all `5a36c0ebc96f…`, 47 files; watch/watch.js unchanged)

Scope: two files. No decision, sizing, permission, exit or risk law changed; the Judge's admission path is untouched.

- `execution/ledger-view.js` (new, pure): `ledgerView(state, { nowMs })` derives the cockpit ledger summary — closed trades with
  entry/exit/fees/realized P&L and close reason, open positions with the Watch's conservative mark, session P&L, win rate, profit
  factor, exit-reason census — from the reduced execution-journal state. Exact decimals in, display numbers out at this edge only.
  It is read by nothing in the decision path.
- `judge/composition.js`: the projection now publishes `dailyLock` (the journal's session P&L against opening equity under
  `config.locks` — the SAME `lockLevelForPnlPct` law `lockLevel()` already consulted in-process) and `ledger` (the view above).
  `composeJudge` gains one import; nothing passed to `createJudge` changed.

Why: the legacy JSONL ledger (`ledger/`, now `attic/ledger/`) computed a SECOND daily-lock answer from CLI-written files the
running app never wrote, so the cockpit could show "no lock" while the Judge refused. `state/locks.js dailyLockStatus()` now reads
`dailyLock` from the projection (or the simulated-P&L drill file); with no projection it reports level NONE, `source:
NO_PROJECTION`, and no fabricated P&L. The persistence pump no longer mirrors `ledger/*.jsonl`; `serpent_ledger_*` tables remain by
the additive migration law and are unused. `cobra ledger …` / `cobra rollup` are gone; `cobra status` reads the projection.

Proof: suite green after the change (see the commit); `test/judge-reservation-settlement.test.js`, `test/judge-e2e-preservation.test.js`
and the Judge differential (ea3bfbf Judge == working-tree Judge, ports absent) unchanged and passing.

### 4.5 Audited change — 2026-09-14 release-acceptance assembly + reservation settlement (previous digests: judge `58f04c37a1b5…`, execution `d9ce90d9b089…`, watch `dc49a39444e2…`, all `de596a965640…`, 41 files)

Scope: 27 commits between GitHub `main` (`ea3bfbf`) and `serpent/baseline` (`cbe2de5`) touched the frozen set — 24 files, +3,380 / −128 lines, six new `judge/` modules. These are the isolated repairs assembled into `codex/release-acceptance-20260914` on 2026-09-14 plus one dispatcher fix found by the full read-through. None of them had updated this section: the P-08 fence was red from the Replit patch series onward and stayed red because only focused files were ever run. This entry records the audit performed before re-pinning.

What changed, by law:

- **Five strategy families / edge-state exits** (`c3798ee`, `a659649`, `1aa979c`, `9affa73`): `judge/edge-state.js`, `judge/setup-selection.js`, `judge/size-ladder.js` added; `judge/setups.js`, `judge/policy.js`, `judge/judge.js`, `watch/watch.js` extended. Momentum and Micro-Bite become operational PAPER setups behind an explicit opt-in policy; Watch gains versioned edge-state exit reasons (`EDGE_STATE_UNKNOWN`, `EDGE_DECAY`, `DISTRIBUTION_EXHAUSTION`). Entry-time management versions are preserved across policy rollback. Catalyst evidence (exact crossing-time event/price) is frozen through confirmation and cannot be substituted later. Default policy unchanged.
- **Learning intake and adaptive ranking hook** (`b775d05`, `33a06f0`, `c695632`, `893e92f`, `c70d103`, `d4986c2`, `f4c23d7`, `1ab37fa`, `c76feac`): `judge/learning-intake.js`, `judge/learning-recipe.js`, `judge/learning-snapshot-cache.js`, `judge/adaptive-facts-source.js`, `judge/adaptive-ranking-port.js` added. The Judge accepts a dormant-by-default adaptive ranking port whose only permitted effect is a bounded rank offset (`ADAPTIVE_EFFECT_REGISTRY.RANKING_SELECTION`); entry, exit and sizing remain `UNSUPPORTED`. Lossy fact inputs are rejected; the sidecar market identity is bound; escaped JSON is bounded before serialization. Any invalid or absent port input resolves to pure baseline. `composeJudge` passes no port today, so the running Judge is byte-for-byte the baseline decision path.
- **Input history identity** (`ea26d03`): `judge/history.js` preserves exact Kraken pair identity, actual candle availability, and refuses falsely early live-bar closure.
- **Account / input bindings** (`42edffe`): XBT/XDG alias mapping, PAPER policy-digest gate, non-QUOTE fee-mode refusal.
- **Queue / canary / closeout integrity** (`4ff852e`, `c1b008f`, `5aa531d`, `f8525d6`, `a1d1396`, `167aa2c`, `e4dcf27`): zero-attempt entries recover after queue refusal; canary completion requires a dispatch attempt; unexecuted shells are excluded from trade evidence; executed closes with unknown outcomes are classified; composed ARM is guarded on persistence integrity; the CLI is bound to the persistence lifecycle; entry-only integrity gates (store guard) are added — unactivated.
- **Reservation settlement** (`cbe2de5`, `execution/dispatcher.js`): a normally FILLED / EXPIRED / CANCELLED paper entry now settles its `RESERVATION_OPENED` hold exactly once when the venue reports the order terminal. Before this, the hold stayed OPEN forever after a fill: on a USD 500 account, cash 65.96 but availableCash −368.27 after one trade; the asset stayed held after FLAT and the slot never returned. Reproduced through the real Judge → dispatcher → paper adapter → Watch path (`test/judge-reservation-settlement.test.js`). The release math is the pre-existing `settleReservation` law; no reducer rule changed.

Laws re-proved on the assembled tree (serial, offline guard, real PostgreSQL 16): 3,076 tests, 3,066 pass, 0 cancelled, 0 outbound attempts. `entryPermission()` remains the single permission law and is still evaluated pre-commit and twice pre-send. The paper profile still forces `JUDGE_MODE=PAPER`, `JUDGE_ALLOW_ORDERS=false`, `JUDGE_ALLOW_PRIVATE=false`. No LIVE path, threshold, or dark-Kraken authority changed.

### 4.4 Audited change — 2026-09-13 fail-closed learning and sizing review (previous digests: judge `c8e48d5c10b5...`, all `f9487cccf92f...`; execution/ and watch/watch.js still byte-identical)

Configuration baseline correction: commit `db4b1a2` already carried the operator's
`paper.baseBalanceUsd: 500` before this review (exact `cobra.config.json` SHA-256
`687d136747ee1292cbcfec6c4ac57ddcc322499696d65e9ab3cd90b087c61d87`). The two
closeout byte fences now protect that committed configuration instead of the stale
pre-`db4b1a2` $100 digest. This correction does not edit configuration, runtime state,
execution, Watch, or trading authority.

The package fence likewise now protects the already-authorized data-only entrypoints
(`data:only`, `data:only-ui`, and `data:status`) at exact `package.json` SHA-256
`22868ac835d3be284b6cb3a63703b27c92c04a2bcf4301b360511fb5ff3208d8`. No dependency
changed: `package-lock.json` remains exactly
`85ade4bd1ce094c37c89574a0adbe4e057e7d1a39358c45dcc3336925ee4ac6e`.

This review repaired reproduced integrity and bounded-record defects in the dormant learning/sizing path. It does not
claim model quality, profitable behavior, paper readiness, or complete validation. Both ports remain null-default and
unwired in `fly.js`; no threshold, risk cap, admission rule, entry permission, execution path, Watch rule, or LIVE
authority changed.

- `judge/learning-intake.js` + `judge/judge.js` — the consumer now requires the exact decision-view provenance,
  non-future prepared clock, explicit feature-recipe and policy versions, finite prepared values, non-negative fact ages,
  and every applicability feature. Corrupt/withheld records and conflicting versions fail to baseline with the affected
  candidates logged; no default version or zero-age value is invented.
- `judge/size-ladder.js` (`judge-size-ladder-4`) — fraction inputs are exact-decimal canonicalized, aliases cannot evade
  the all-in prerequisites, duplicates/malformed/count-over-limit inputs fail closed, and admission callback faults refuse
  only that candidate. Future books and negative freshness laws fail closed. The sustainability boundary uses exact decimal
  cross-products, while its percentage remains display-only. The deepest protective-exit proof is independently priced at
  the stop-stress mid with 25% recorded depth; target-exit sensitivity is not mislabelled as stop protection.
- The maximum ladder is 16 candidates. The largest existing setup contributes 13 clauses; the learning side contributes
  at most 24 candidate rows plus one summary; sizing contributes 16 rows plus one summary: `13 + 24 + 1 + 16 + 1 = 55`.
  This stays inside the unchanged 64-measurement contract, so the final decision slice cannot silently discard an allowed
  size row while its summary claims complete logging. Default fractions remain `0.25/0.5/0.75/1`.
- Companion learning producers now bind published activations to canonical design/evidence/terminal digests, re-derive that
  provenance in the decision view, leave a premature formal look pending without consuming the candidate, freeze the
  formal estimate to the first predeclared groups, and reject backdated or forged terminals. The portable JSON replacement
  path retains file-fsync/rename failure visibility while tolerating only Windows' unsupported directory-fsync `EPERM`.
- Focused regressions: `test/judge-sizing-review.test.js`, `test/judge-learning-intake.test.js`,
  `test/judge-e2e-preservation.test.js`, `test/learning-adapter-review.test.js`,
  `test/learning-prospective-terminal-regression.test.js`, and `test/jsonl-atomic-portable.test.js`. The differential and
  integrity-boundary tests continue to require the default-off Judge to match the archived baseline and forbid execution or
  Watch imports. Digest proof is still `test/paper-runtime.test.js` P-08.

### 4.3 Audited change — 2026-09-13 independent-review corrections (previous digests: judge `767bb48158ad…`, all `9012dd402d57…`; execution/ and watch/watch.js still byte-identical to the paper audit)

The dormant ports from §4.2 were completed per the independent review, still null-default and still unwired in
`fly.js`. Differential proof: `test/judge-differential.test.js` runs the ACTUAL `ea3bfbf` Judge (git archive)
beside this tree on identical recorded inputs and requires raw deepEqual over complete decisions, refusals and
account/execution state — passing, with zero normalizations.

- `judge/learning-intake.js` — the selector now matches the COMPLETED candidate contract: asset/venue scope
  lists (set membership, no name preference), mandatory eligibility envelope (liquidity + volatility ranges,
  requiredFeatures, maxFactAgeMs freshness), featureRecipeVersion/policyVersion pinning; every candidate seen
  is durably logged (`LEARNED_CANDIDATE` measurement rows). Still RANKING-only, bounded, baseline on any gap.
- `judge/size-ladder.js` (`judge-size-ladder-2`) — sustainable objective (net-return degradation tolerance
  anchored to the best smaller supported size); per-size records (entry/exit, fees, spread/slippage, net
  return %, stressed loss, reward/risk, depth-haircut exit sensitivities, admission verdict, opportunity
  cost); full-balance prerequisites (admission law, declared candidate max size, freshness, fresh book,
  protective exit at the deepest haircut) — any gap ⇒ conservative smaller-size fallback, recorded by name.
- `judge/judge.js` — the dynamic-sizing branch passes prepared inputs built ONLY from what the decision
  already holds (the unchanged admitCandidate per size, policy freshness, the validated candidate's declared
  maxSizeUsd or null); learned facts gain asset/venue/atrPct/ageMs. Ports still `null` by default; with both
  absent the differential proof above holds. No threshold, gate, authority, order permission, admission rule
  or risk rule was modified; sizing with the switch OFF is the exact §4.2 path.

### 4.2 Audited change — 2026-09-13 dormant learning/sizing ports (previous digests: judge `187fbace4d56…`, all `075ecd3aecef…`; execution/ and watch/watch.js byte-identical)

The continuous-learning branch (`claude/continuous-learning-2026-09-13`, ADDENDUM-2 + final sizing addendum)
adds two null-default consumer ports to the Judge. Nothing operational changes while they are unwired, and the
production composition root (`fly.js`) wires NEITHER — proved structurally by `test/integrity-boundary.test.js`
and behaviorally by `test/judge-learning-intake.test.js` (rig comparison: with both ports absent, decisions,
refusals, rankings, sizing and risk math are identical to baseline on identical recorded inputs).

- `judge/learning-intake.js` (NEW) — the ONE bridge to validated learning artifacts. Imports only
  `learning/contracts.js` + `learning/features.js`. Deterministic versioned selector (`learning-selector-1`),
  conservative tie-break, baseline fallback on no-match / staleness (15 min) / invalid artifact / scope or
  eligibility miss / conflicting active versions / kill switch. Consumable axis: RANKING only, bounded by the
  frozen `adjust` within `maxAbsAdjust`. Contribution is logged as a `LEARNED_RANK_ADJUSTMENT` MEASUREMENT row.
- `judge/size-ladder.js` (NEW) — the size ladder over the UNCHANGED `sizeSearch` cost law (imports only
  `./cost.js` + `../execution/money.js`). Fractions 0.25/0.5/0.75/1 of the risk-bounded spendable; risk caps
  bind at every size; a missing/one-sided book selects nothing; every candidate size and rejection reason is
  recorded (`DYNAMIC_SIZE_SELECTION`). All-in is only ever flagged eligible when fraction 1 strictly wins.
- `judge/judge.js` — `createJudge` gains `learning = null` and `dynamicSizing = null` parameters; when null
  (the default and the production state) the decide() pipeline is unchanged. No threshold, gate, authority,
  order permission, admission rule or risk rule was modified.
- `judge/composition.js` — `composeJudge` gains pass-through parameters (`learningActivationSource`,
  `dynamicSizing`), both defaulting to null/off, with a 60-second-cached snapshot accessor when supplied.
- No change to thresholds, sizing defaults, risk, gates, authority, order permissions or the paper runtime;
  PAPER and LIVE remain OFF; both new ports remain unwired in `fly.js`.

### 4.1 Audited change — 2026-09-12 operational repair (previous digests: judge `ca3b1c8f0b2e…`, execution `1885a471b7d2…`, all `cbdf08784769…`)

Two reproduced runtime defects were repaired inside the frozen trees. `watch/watch.js` is byte-identical. Evidence and
before/after counters: `docs/evidence/operational-repair-2026-09-12.md`; regressions: `test/judge-operational-repair.test.js`.

- `execution/feed.js` — the venue sends ONE book snapshot per subscription, so a symbol admitted AFTER the tape's book
  subscription had no synchronized book and every later `update` hit the not-synchronized guard: books stayed at ZERO for
  the whole run while trades flowed. The feed now asks the bound tape for a REAL venue snapshot (bounded, rate-limited,
  `requestBookSnapshot`), keeps the public instrument PRECISION for every announced pair (so `crcVerified` can become true
  for a later admission), and starts a carried symbol's trade coverage at the ADMISSION clock. No depth is manufactured,
  no stale depth is reused as current, and the synchronization / CRC / freshness laws are unchanged. Authority unchanged.
- `judge/readiness.js` + `judge/composition.js` — a standing nomination list that carries no nomination clock was
  re-stamped with the current clock on every pass, so the six preparation slots flipped between disjoint groups every
  cadence and warmup never accumulated. The nomination's KNOWN-AT clock (rank) is now separated from its LAST-AFFIRMED
  clock (expiry). Warmup lengths, eligibility clauses, capacity limits, held-position protection and legitimate expiry
  are unchanged; `judge/readiness.js` also names WHY a book is unusable (`bookFreshDetail`) instead of `age nullms`.
- No change to thresholds, sizing, risk, gates, authority, order permissions or the paper runtime.

## 5. Socrates under the paper profile

- Case runtime: `desiredState ON` (`config/paper-runtime.json` groups.socrates.caseRuntime); it runs inside the market
  research service and seals cases under `<researchRoot>/cases/`.
- Model: `DISABLED_BY_PAPER_POLICY` — `config/market-research.paper.json` `model.enabled=false` with zero USD caps. A key in
  the environment never enables it; a case without a model seals `BUDGET_BLOCKED` (fail-closed). Enabling it is an operator
  policy change with explicit per-case / per-day caps, never an inference.
- Authority: `SEALED_CASE_INPUT_ONLY`. The Judge reads COMPLETED, byte-verified cases (law 5); Socrates output is
  interpretation, never source truth, never an order, never a threshold.
- The two dark families (Kraken Charts, Kraken L3) are OUTSIDE the decision registries and cannot reach Socrates, the
  Judge, Watch or execution (`test/market-kraken-edge-fences.test.js` F-03).
