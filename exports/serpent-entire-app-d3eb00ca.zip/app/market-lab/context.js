// MARKET LAB — the CONTEXT: deterministic features for ONE subject at ONE as-of from admissible observations (§6, §7).
// Pure: given the same observation prefix, policy and as-of, the canonical context is byte-identical across directory
// names and restarts (no wall clock, no randomness). Every component references the exact observation ids it used,
// carries its own derivation clock and support, and never references the summary back. Resource loss propagates
// as support / completeness, never as a quiet zero.
import { deepFreeze, canonicalDigest, exactKeys, isTs, isPlainObject, isFiniteNum, FAMILIES, fail, PAYLOAD_KINDS, PROVIDER_IDS, COVERAGE_STATES, QUALITY_REASON_CODES, SUBJECT_KEYS, subjectError } from './contracts.js';
import { PREFIX_KEYS, PREFIX_VERSION } from './prefix.js';
import { WINDOWS_MS, MINUTE_MS, HOUR_MS, DAY_MS, adjacentWindows, derivationClockError } from './time.js';
import { intervalCoverage } from './recipes.js';
import { selectNativeSeries, selectionFacts, seriesKeyOf, partitionNativeSeries } from './native-series.js';
import { componentValueError, contextSupportError, METRIC_SCHEMAS } from './context-schema.js';
import { RECIPE_SET_VERSION, RECIPES, tradeWindow, bookMetrics, walkBook, roundTrip, haircutScenarios, pressureResponse, pressureResponseChange, peerRelativeMove, venueDispersion, orderedFirstChanges, basisBps, oiChange, fundingNative, supplyRatios, exchangeNetFlow, stablecoinChange, pegDeviationBps, liquidationTotals, etfFlowSummary, macroSurprise, relativeActivity, indicators, breakoutDistance } from './recipes.js';
import { RESOURCE_DEFAULTS } from './policy.js';

export const CONTEXT_VERSION = 'market-context-2'; // closeout: positive interval coverage, recorded census, prefix capture references, closed value schemas
export const LEGACY_CONTEXT_VERSIONS = Object.freeze(['market-context-1']); // rejected explicitly on reopen: they lack coverage / census proof (never converted)
export const CONTEXT_KEYS = Object.freeze(['contextVersion', 'contextId', 'canonicalCoin', 'asOfTs', 'derivationTs', 'recipeSetVersion', 'captureRef', 'subjects', 'families', 'omitted', 'resourceState', 'limits']);
export const COMPONENT_KEYS = Object.freeze(['componentId', 'family', 'metricId', 'recipeId', 'version', 'subjectId', 'windowStartTs', 'windowEndTs', 'derivationTs', 'inputObservationIds', 'inputObservationCount', 'inputDigest', 'inputKnownAtMax', 'value', 'support', 'limitations']);
export const FAMILY_STATES = Object.freeze(['OBSERVED', 'PARTIAL', 'MISSING', 'NOT_SUPPORTED', 'NOT_QUERIED']);
export const MAX_INPUT_IDS = 64;
export const MAX_COMPONENTS_PER_FAMILY = 96;
export const BOOK_ENDPOINT_MAX_AGE_MS = 15_000;
export const NETWORK_METRIC_OF = deepFreeze({ active_addresses: 'active_addresses', transaction_count: 'transaction_count', transfer_volume: 'transfer_volume', fees_total: 'network_fees', mvrv: 'realized_value_metrics', sopr: 'realized_value_metrics', realized_price: 'realized_value_metrics', whale_transaction_count_100k_usd_to_inf: 'whale_transaction_count_100k_usd_to_inf', whale_transaction_count_1m_usd_to_inf: 'whale_transaction_count_1m_usd_to_inf', whale_transaction_volume_100k_usd_to_inf: 'whale_transaction_volume_100k_usd_to_inf', whale_transaction_volume_1m_usd_to_inf: 'whale_transaction_volume_1m_usd_to_inf' });
export const METRIC_RECIPE = deepFreeze({ holder_cohorts: 'latest_observation', exchange_reserve: 'latest_observation', active_addresses: 'latest_observation', transaction_count: 'latest_observation', transfer_volume: 'latest_observation', network_fees: 'latest_observation', realized_value_metrics: 'latest_observation', whale_transaction_count_100k_usd_to_inf: 'latest_observation', whale_transaction_count_1m_usd_to_inf: 'latest_observation', whale_transaction_volume_100k_usd_to_inf: 'latest_observation', whale_transaction_volume_1m_usd_to_inf: 'latest_observation', pool_liquidity: 'latest_observation', protocol_tvl: 'latest_observation', protocol_fees_revenue: 'latest_observation', lending_rates: 'latest_observation' });
const recipeOf = (metricId) => RECIPES[metricId] ?? RECIPES[METRIC_RECIPE[metricId]] ?? null;
// correction D: ONE closed component metric -> family binding, authoritative for the builder, the candidate publisher, the reader,
// the verifier and evidence construction. A single-family recipe binds its own family; the intentionally generic
// `latest_observation` recipe (nominal family NETWORK_ACTIVITY) is reused by entity-flow / holder and DEX / DeFi metrics, which are
// bound EXPLICITLY here rather than by the recipe's nominal family. A component is lawful only when its supplied family, its
// containing family, its metric, its recipe and the recipe version all agree with this binding — never by hash or count alone.
export const GENERIC_RECIPE_METRIC_FAMILY = deepFreeze({ holder_cohorts: 'ONCHAIN_ENTITY_FLOW', exchange_reserve: 'ONCHAIN_ENTITY_FLOW', active_addresses: 'NETWORK_ACTIVITY', transaction_count: 'NETWORK_ACTIVITY', transfer_volume: 'NETWORK_ACTIVITY', network_fees: 'NETWORK_ACTIVITY', realized_value_metrics: 'NETWORK_ACTIVITY', whale_transaction_count_100k_usd_to_inf: 'NETWORK_ACTIVITY', whale_transaction_count_1m_usd_to_inf: 'NETWORK_ACTIVITY', whale_transaction_volume_100k_usd_to_inf: 'NETWORK_ACTIVITY', whale_transaction_volume_1m_usd_to_inf: 'NETWORK_ACTIVITY', pool_liquidity: 'DEX_DEFI', protocol_tvl: 'DEX_DEFI', protocol_fees_revenue: 'DEX_DEFI', lending_rates: 'DEX_DEFI' });
for (const metricId of Object.keys(METRIC_RECIPE)) if (!GENERIC_RECIPE_METRIC_FAMILY[metricId]) throw new Error(`GENERIC_RECIPE_METRIC_FAMILY: ${metricId} unbound`);
export const COMPONENT_FAMILY = deepFreeze(Object.fromEntries(Object.keys(METRIC_SCHEMAS).map((metricId) => [metricId, RECIPES[metricId] ? RECIPES[metricId].family : GENERIC_RECIPE_METRIC_FAMILY[metricId] ?? null])));
for (const [metricId, family] of Object.entries(COMPONENT_FAMILY)) { if (!FAMILIES.includes(family)) throw new Error(`COMPONENT_FAMILY: ${metricId} has no closed family binding`); if (!recipeOf(metricId)) throw new Error(`COMPONENT_FAMILY: ${metricId} has no recipe`); }
export function componentBindingError(c, containingFamily, where = 'component') {
  if (typeof c?.metricId !== 'string' || !Object.hasOwn(COMPONENT_FAMILY, c.metricId)) return `${where}.metricId: no closed schema`;
  const bound = COMPONENT_FAMILY[c.metricId]; const recipe = recipeOf(c.metricId);
  if (c.family !== bound || containingFamily !== bound) return `${where}: family disagrees with the metric's closed binding`;
  if (!recipe || c.recipeId !== recipe.recipeId || !RECIPES[c.recipeId] || RECIPES[c.recipeId].version !== c.version) return `${where}: recipe binding malformed`;
  return null;
}
const componentIdentity = (c) => { const b = {}; for (const k of COMPONENT_KEYS) if (k !== 'componentId') b[k] = c[k]; return `mcc-${canonicalDigest(b).slice(0, 40)}`; };
export const contextIdentity = (ctx) => { const b = {}; for (const k of CONTEXT_KEYS) if (k !== 'contextId') b[k] = ctx[k]; return `mctx-${canonicalDigest(b)}`; };

// ---- helpers over admissible observation sets ------------------------------------------------------------------
const latestAtOrBefore = (list, ts, clockOf = (o) => o.receivedTs) => { let best = null; for (const o of list) { const t = clockOf(o); if (isTs(t) && t <= ts && (!best || t > clockOf(best) || (t === clockOf(best) && o.sequence > best.sequence))) best = o; } return best; };
const idsOf = (obs) => [...new Set(obs.map((o) => o.observationId))].sort();
const knownMax = (obs) => obs.reduce((m, o) => Math.max(m, o.knownAtTs), 0) || null;

export function buildContext({ canonicalCoin, asOfTs, observations, coverage = [], captureRef, referenceNotionals = [1000, 10000], peers = [], limits = RESOURCE_DEFAULTS, resourceState = null }) {
  if (!isTs(asOfTs)) fail('INVALID_REQUEST', 'as-of required');
  const admissible = observations.filter((o) => o.knownAtTs <= asOfTs);
  const late = observations.length - admissible.length;
  const subjectsSeen = new Map();
  for (const o of admissible) { const sid = o.subjectId ?? null; if (!subjectsSeen.has(o.subject.canonicalCoin)) subjectsSeen.set(o.subject.canonicalCoin, new Set()); }
  const mine = admissible.filter((o) => o.subject.canonicalCoin === canonicalCoin || o.subject.canonicalCoin === null);
  const byKind = (kind, pred = () => true) => mine.filter((o) => o.kind === kind && pred(o));
  const families = {}; const omitted = { lateArrivals: late, componentsOverCap: 0, inputIdsTruncated: 0 }; const usedIds = new Set();
  const component = ({ family, metricId, subjectId = null, windowStartTs = null, windowEndTs = null, inputs, value, support, limitations = [] }) => {
    const r = recipeOf(metricId); if (!r) fail('INTERNAL_FAILURE', `no recipe bound to metric ${metricId}`); const ids = idsOf(inputs); for (const id of ids) usedIds.add(id); const truncated = ids.length > MAX_INPUT_IDS; if (truncated) omitted.inputIdsTruncated += 1;
    const c = { componentId: 'mcc-x', family, metricId, recipeId: r ? r.recipeId : metricId, version: r ? r.version : 1, subjectId, windowStartTs, windowEndTs, derivationTs: asOfTs, inputObservationIds: truncated ? ids.slice(0, MAX_INPUT_IDS) : ids, inputObservationCount: ids.length, inputDigest: canonicalDigest(ids), inputKnownAtMax: knownMax(inputs), value, support, limitations: [...(r?.limitations ?? []), ...limitations] };
    c.componentId = componentIdentity(c); return c;
  };
  const addFamily = (family, comps, state) => { const list = comps.filter(Boolean).sort((a, b) => (a.metricId < b.metricId ? -1 : a.metricId > b.metricId ? 1 : (a.subjectId ?? '') < (b.subjectId ?? '') ? -1 : (a.subjectId ?? '') > (b.subjectId ?? '') ? 1 : (a.windowEndTs ?? 0) - (b.windowEndTs ?? 0) || (a.windowStartTs ?? 0) - (b.windowStartTs ?? 0))); if (list.length > MAX_COMPONENTS_PER_FAMILY) omitted.componentsOverCap += list.length - MAX_COMPONENTS_PER_FAMILY; const cov = coverage.filter((c) => c.family === family); families[family] = { state: state ?? (list.length ? 'OBSERVED' : cov.some((c) => c.state === 'ACCESS_BLOCKED') ? 'NOT_SUPPORTED' : cov.length ? 'MISSING' : 'NOT_QUERIED'), components: list.slice(0, MAX_COMPONENTS_PER_FAMILY), coverage: cov.map((c) => ({ coverageId: c.coverageId, provider: c.provider, endpointId: c.endpointId, subjectId: c.subjectId, kind: c.kind, state: c.state, reasonCodes: c.reasonCodes, startTs: c.startTs, endTs: c.endTs, observationCount: c.observationCount, droppedCount: c.droppedCount })).sort((a, b) => (a.coverageId < b.coverageId ? -1 : 1)) }; };
  const marketSubjects = [...new Map(mine.filter((o) => o.subject.subjectKind === 'MARKET').map((o) => [o.subject.nativeSymbol + '@' + o.subject.venue, o.subject])).values()].sort((a, b) => (a.venue < b.venue ? -1 : 1));
  const sidOf = (s) => `ms-${canonicalDigest(s).slice(0, 32)}`;
  // ---- SPOT_PRICE_CHART + SPOT_FLOW + DISPLAYED_LIQUIDITY + H01/H03 per venue -----------------------------------------------
  const chart = []; const flow = []; const liq = []; const crossVenue = []; const venueMids = []; const venueChanges = []; const windowsByVenue = new Map();
  for (const s of marketSubjects) {
    const sid = sidOf(s); const trades = byKind('TRADE', (o) => sidOf(o.subject) === sid && o.sourceEventTs !== null); const books = byKind('BOOK_SNAPSHOT', (o) => sidOf(o.subject) === sid); const bars = byKind('CANDLE', (o) => sidOf(o.subject) === sid);
    // closeout R02: trade windows consume POSITIVE interval coverage for this exact subject / channel (SUBSCRIBED intervals,
    // bounded history spans) minus gaps / drops / evictions; nothing is inferred from a book, a heartbeat or one trade
    const tradeCov = coverage.filter((c) => c.subjectId === sid && (c.kind === 'TRADE' || (c.kind === null && c.family === 'SPOT_FLOW')) && c.startTs <= asOfTs);
    const ic = (startTs, endTs) => intervalCoverage(tradeCov, { startTs, endTs, asOfTs });
    const evictedUntil = resourceState?.perSubject?.[sid]?.evictedTradesUntilTs ?? null;
    const windows = {};
    for (const w of WINDOWS_MS) { const { previous, current } = adjacentWindows(asOfTs, w); const cur = tradeWindow(trades, { ...current, evictedUntilTs: evictedUntil, coverage: ic(current.startTs, current.endTs) }); const prev = tradeWindow(trades, { ...previous, evictedUntilTs: evictedUntil, coverage: ic(previous.startTs, previous.endTs) }); windows[w] = { cur, prev }; const inputs = trades.filter((t) => t.sourceEventTs > previous.startTs && t.sourceEventTs <= current.endTs);
      chart.push(component({ family: 'SPOT_PRICE_CHART', metricId: 'window_ohlcv', subjectId: sid, windowStartTs: current.startTs, windowEndTs: current.endTs, inputs, value: { current: cur, previous: prev, venue: s.venue, quote: s.quote, changes: { logReturn: cur.logReturn !== null && prev.logReturn !== null ? cur.logReturn - prev.logReturn : null, quoteNotional: cur.quoteNotional !== null && prev.quoteNotional !== null ? cur.quoteNotional - prev.quoteNotional : null, count: cur.count !== null && prev.count !== null ? cur.count - prev.count : null } }, support: cur.support }));
      flow.push(component({ family: 'SPOT_FLOW', metricId: 'signed_notional', subjectId: sid, windowStartTs: current.startTs, windowEndTs: current.endTs, inputs, value: { current: cur.flow, previous: prev.flow, stats: cur.stats, venue: s.venue, quote: s.quote }, support: cur.flow.support })); }
    windowsByVenue.set(sid, windows);
    // relative activity: current 60s vs trailing 60s windows of equal elapsed time (up to 10)
    const trailing = []; for (let k = 2; k <= 11; k += 1) { const a = asOfTs - k * MINUTE_MS; const b = asOfTs - (k - 1) * MINUTE_MS; trailing.push(tradeWindow(trades, { startTs: a, endTs: b, evictedUntilTs: evictedUntil, coverage: ic(a, b) })); }
    const ra = relativeActivity(windows[60_000].cur, trailing, 'quoteNotional'); const rr = relativeActivity(windows[60_000].cur, trailing, 'range');
    chart.push(component({ family: 'SPOT_PRICE_CHART', metricId: 'relative_activity', subjectId: sid, windowStartTs: asOfTs - 11 * MINUTE_MS, windowEndTs: asOfTs, inputs: trades.filter((t) => t.sourceEventTs > asOfTs - 11 * MINUTE_MS), value: { notional: ra, range: rr, venue: s.venue }, support: ra.support }));
    // indicators per closed-bar interval
    const byInterval = new Map(); for (const b of bars) { const key = seriesKeyOf(b); if (!byInterval.has(key)) byInterval.set(key, []); byInterval.get(key).push(b); }
    for (const [, list] of [...byInterval.entries()].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)) { const intervalMs = list[0].payload.intervalMs; const sel = selectNativeSeries(list.filter((b) => b.payload.closed && b.periodEndTs <= asOfTs), { asOfTs }); const closed = sel.selected.slice().sort((a, b) => a.periodStartTs - b.periodStartTs); const ind = indicators(closed); /* correction B: one selected version per native period; the component references exactly these inputs */ const evictedBars = resourceState?.perSubject?.[sid]?.evictedBarsUntilTs ?? null; const provisional = list.filter((b) => b.payload.provisional).sort((a, b) => b.periodStartTs - a.periodStartTs)[0] ?? null;
      chart.push(component({ family: 'SPOT_PRICE_CHART', metricId: 'indicators', subjectId: sid, windowStartTs: closed.length ? closed[0].periodStartTs : null, windowEndTs: closed.length ? closed[closed.length - 1].periodEndTs : null, inputs: closed, value: { intervalMs, ...ind, breakout: breakoutDistance(ind.lastClose, ind, windows[3_600_000].cur.vwap), provisionalBar: provisional ? { periodStartTs: provisional.periodStartTs, close: provisional.payload.close, state: 'PROVISIONAL' } : null, completeness: { bars: closed.length, evictedBarsUntilTs: evictedBars, capReached: closed.length >= limits.barsPerInterval, selection: selectionFacts(sel) }, venue: s.venue }, support: ind.support, limitations: evictedBars ? ['PREREQUISITE_BARS_EVICTED'] : [] })); }
    // displayed liquidity at the as-of endpoint + previous minute endpoint
    const bookNow = latestAtOrBefore(books, asOfTs); const bookPrev = latestAtOrBefore(books, asOfTs - MINUTE_MS);
    if (bookNow) { const bm = bookMetrics(bookNow.payload); const age = asOfTs - bookNow.receivedTs; const fresh = bookNow.payload.synchronized && age <= BOOK_ENDPOINT_MAX_AGE_MS;
      liq.push(component({ family: 'DISPLAYED_LIQUIDITY', metricId: 'spread_bps', subjectId: sid, windowEndTs: bookNow.receivedTs, inputs: [bookNow], value: { ...bm, bookAgeMs: age, synchronized: bookNow.payload.synchronized, checksumVerified: bookNow.payload.checksumVerified, sampleReason: bookNow.payload.sampleReason, venue: s.venue, quote: s.quote }, support: { state: fresh ? 'FRESH' : 'STALE', reasons: fresh ? [] : ['BOOK_ENDPOINT_AGE'] } }));
      if (bm.mid !== null) { venueMids.push({ venue: s.venue, quote: s.quote, mid: bm.mid, receivedTs: bookNow.receivedTs, aliasGroup: s.quoteAliasGroup }); venueChanges.push({ venue: s.venue, receivedTs: bookNow.receivedTs, clockUncertaintyMs: null }); }
      for (const N of referenceNotionals) { const rt = roundTrip(bookNow.payload, N); const rtPrev = bookPrev ? roundTrip(bookPrev.payload, N) : null; const hc = haircutScenarios(bookNow.payload, N);
        liq.push(component({ family: 'DISPLAYED_LIQUIDITY', metricId: 'round_trip_loss', subjectId: sid, windowStartTs: bookPrev ? bookPrev.receivedTs : null, windowEndTs: bookNow.receivedTs, inputs: bookPrev ? [bookNow, bookPrev] : [bookNow], value: { quoteNotional: N, current: rt, previous: rtPrev, lossChangeBps: rt.lossBps !== null && rtPrev?.lossBps !== null && rtPrev ? rt.lossBps - rtPrev.lossBps : null, haircuts: hc, buyWalk: walkBook(bookNow.payload.asks, { quoteNotional: N }), sellWalk: walkBook(bookNow.payload.bids, { quoteNotional: N }), fees: 'NOT_SUPPLIED_PRE_FEE_ONLY', venue: s.venue }, support: { state: fresh ? (rt.coverage === 'FULL' ? 'COMPLETE' : 'PARTIAL') : 'STALE', reasons: fresh ? (rt.coverage === 'FULL' ? [] : [rt.coverage]) : ['BOOK_ENDPOINT_AGE'] } })); }
    } else liq.push(component({ family: 'DISPLAYED_LIQUIDITY', metricId: 'spread_bps', subjectId: sid, inputs: [], value: { venue: s.venue, mid: null, spreadBps: null }, support: { state: 'NO_BOOK', reasons: ['NO_ACCEPTED_BOOK_AT_OR_BEFORE_AS_OF'] } }));
    // H01 across two adjacent 60 s windows with lawful fresh endpoints
    const { previous, current } = adjacentWindows(asOfTs, 60_000); const ep = (ts) => { const b = latestAtOrBefore(books, ts); return b && b.payload.synchronized && ts - b.receivedTs <= BOOK_ENDPOINT_MAX_AGE_MS ? { book: b, m: bookMetrics(b.payload) } : null; };
    const e0 = ep(previous.startTs); const e1 = ep(previous.endTs); const e2 = ep(current.endTs);
    const pr = (w, a, b) => pressureResponse({ signedNotional: w.flow.signedNotional, startMid: a?.m.mid ?? null, endMid: b?.m.mid ?? null, spreadStart: a?.m.spreadBps ?? null, spreadEnd: b?.m.spreadBps ?? null, knownSideFraction: w.flow.knownSideFraction, complete: w.support.state === 'COMPLETE' || w.support.state === 'COMPLETE_NO_TRADES' });
    const p0 = pr(windows[60_000].prev, e0, e1); const p1 = pr(windows[60_000].cur, e1, e2);
    flow.push(component({ family: 'SPOT_FLOW', metricId: 'pressure_response_efficiency', subjectId: sid, windowStartTs: previous.startTs, windowEndTs: current.endTs, inputs: [...trades.filter((t) => t.sourceEventTs > previous.startTs && t.sourceEventTs <= current.endTs), e0?.book, e1?.book, e2?.book].filter(Boolean), value: { ...pressureResponseChange(p0, p1), replenishment: e1 && e2 ? { depth10bpsBidChange: e2.m.bands['10bps'].bid.notional - e1.m.bands['10bps'].bid.notional, depth10bpsAskChange: e2.m.bands['10bps'].ask.notional - e1.m.bands['10bps'].ask.notional } : null, venue: s.venue, quote: s.quote, quoteUnitNote: s.quote === 'USD' ? 'bps per million USD' : `bps per million ${s.quote}` }, support: { state: p0.support.state === 'COMPLETE' && p1.support.state === 'COMPLETE' ? 'COMPLETE' : 'PARTIAL', reasons: [...new Set([...p0.support.reasons, ...p1.support.reasons, ...(e0 && e1 && e2 ? [] : ['BOOK_ENDPOINTS_INCOMPLETE'])])] } }));
  }
  addFamily('SPOT_PRICE_CHART', chart); addFamily('SPOT_FLOW', flow); addFamily('DISPLAYED_LIQUIDITY', liq);
  // ---- CROSS_VENUE: dispersion, first-observed changes, H02 peers --------------------------------------------------------
  const usdMids = venueMids.filter((m) => m.quote === 'USD' || m.aliasGroup === 'COINBASE_USD_USDC').map((m) => ({ ...m, quote: 'USD' }));
  const vd = venueDispersion(usdMids); const bookInputs = byKind('BOOK_SNAPSHOT').filter((o) => usdMids.some((m) => m.receivedTs === o.receivedTs && m.venue === o.subject.venue));
  crossVenue.push(component({ family: 'CROSS_VENUE', metricId: 'venue_mid_dispersion', windowEndTs: asOfTs, inputs: bookInputs, value: { dispersion: vd, firstObservedChanges: orderedFirstChanges(venueChanges), aliasNote: 'COINBASE_USD_USDC is one venue quote group, never a second venue' }, support: vd.support }));
  const peerTrades = admissible.filter((o) => o.kind === 'TRADE' && o.subject.subjectKind === 'MARKET' && o.subject.canonicalCoin !== canonicalCoin && o.subject.venue === (marketSubjects[0]?.venue ?? 'kraken') && o.subject.quote === 'USD' && peers.includes(o.subject.canonicalCoin) && o.sourceEventTs !== null);
  const peerReturns = [...new Set(peerTrades.map((o) => o.subject.canonicalCoin))].sort().map((coin) => { const list = peerTrades.filter((o) => o.subject.canonicalCoin === coin); const psid = sidOf(list[0].subject); const w = tradeWindow(list, { startTs: asOfTs - 60_000, endTs: asOfTs, coverage: intervalCoverage(coverage.filter((c) => c.subjectId === psid && c.kind === 'TRADE' && c.startTs <= asOfTs), { startTs: asOfTs - 60_000, endTs: asOfTs, asOfTs }) }); return { coin, returnBps: w.logReturn !== null ? 1e4 * w.logReturn : null, coverage: w.support.state, reason: w.logReturn === null ? 'NO_TRADES_IN_WINDOW' : null }; });
  const missingPeers = peers.filter((p) => p !== canonicalCoin && !peerReturns.some((r) => r.coin === p)).map((coin) => ({ coin, returnBps: null, reason: 'NOT_OBSERVED' }));
  const targetWindow = marketSubjects.length ? windowsByVenue.get(sidOf(marketSubjects[0]))?.[60_000].cur : null;
  const h02 = peerRelativeMove({ targetReturnBps: targetWindow?.logReturn !== null && targetWindow?.logReturn !== undefined ? 1e4 * targetWindow.logReturn : null, peers: [...peerReturns, ...missingPeers] });
  crossVenue.push(component({ family: 'CROSS_VENUE', metricId: 'peer_relative_move', windowStartTs: asOfTs - 60_000, windowEndTs: asOfTs, inputs: [...peerTrades.filter((o) => o.sourceEventTs > asOfTs - 60_000), ...(marketSubjects.length ? byKind('TRADE', (o) => sidOf(o.subject) === sidOf(marketSubjects[0]) && o.sourceEventTs > asOfTs - 60_000) : [])], value: { ...h02, cohortMappingKnownAtTs: null, cohortNote: 'same quote/venue cohort at identical endpoints; category cohorts only with mapping known as of the comparison' }, support: h02.support }));
  addFamily('CROSS_VENUE', crossVenue);
  // ---- DERIVATIVES / LIQUIDATIONS ------------------------------------------------------------------------------------------
  const derivs = []; const ticks = byKind('DERIVATIVE_TICK'); const byInstr = new Map(); for (const t of ticks) { const k = `${t.subject.venue}:${t.subject.instrumentId}`; if (!byInstr.has(k)) byInstr.set(k, []); byInstr.get(k).push(t); }
  for (const [k, list] of [...byInstr.entries()].sort().slice(0, limits.derivativesPerCase)) { const now = latestAtOrBefore(list, asOfTs); if (!now) continue; const hourAgo = latestAtOrBefore(list.filter((t) => t.subject.specificationId === now.subject.specificationId), asOfTs - HOUR_MS); const p = now.payload;
    derivs.push(component({ family: 'DERIVATIVES_FUNDING_OI', metricId: 'basis_bps', subjectId: sidOf(now.subject), windowEndTs: now.knownAtTs, inputs: [now, hourAgo].filter(Boolean), value: { instrument: k, marketType: now.subject.marketType, basisBps: basisBps(p.markPrice, p.indexPrice), markPrice: p.markPrice, indexPrice: p.indexPrice, openInterest: { value: p.openInterest, unit: p.openInterestUnit, changeOverHour: oiChange(hourAgo, now) }, funding: fundingNative(now), ageMs: asOfTs - now.knownAtTs, quality: now.quality.state }, support: { state: p.markPrice !== null && p.indexPrice !== null ? 'COMPLETE' : 'PARTIAL', reasons: p.markPrice !== null && p.indexPrice !== null ? [] : ['MARK_OR_INDEX_MISSING'] } })); }
  addFamily('DERIVATIVES_FUNDING_OI', derivs);
  // liquidation totals exist ONLY when a liquidation feed was observed (a connected or absent feed never yields an invented zero)
  const liqEvents = byKind('LIQUIDATION'); const liqs = []; const liqCoverage = coverage.some((c) => c.family === 'LIQUIDATIONS' && c.state === 'OBSERVED');
  for (const w of liqEvents.length || liqCoverage ? [HOUR_MS, DAY_MS] : []) { const tot = liquidationTotals(liqEvents, { startTs: asOfTs - w, endTs: asOfTs, coverageKnown: coverage.some((c) => c.family === 'LIQUIDATIONS' && c.state === 'OBSERVED') }); liqs.push(component({ family: 'LIQUIDATIONS', metricId: 'liquidation_notional_by_side', windowStartTs: asOfTs - w, windowEndTs: asOfTs, inputs: liqEvents.filter((e) => (e.sourceEventTs ?? e.periodEndTs ?? 0) > asOfTs - w), value: { ...tot, venues: [...new Set(liqEvents.map((e) => e.payload.venueScope))].sort() }, support: tot.support })); }
  addFamily('LIQUIDATIONS', liqs);
  // ---- SUPPLY / DEX / ONCHAIN / NETWORK / STABLE / ETF / MACRO / EVENTS / INFRA --------------------------------
  const refs = byKind('ASSET_REFERENCE'); const refNow = latestAtOrBefore(refs, asOfTs, (o) => o.knownAtTs); const unlocks = byKind('UNLOCK_EVENT').filter((u) => u.payload.scheduledTs !== null && u.payload.scheduledTs > asOfTs).sort((a, b) => a.payload.scheduledTs - b.payload.scheduledTs).slice(0, 16);
  const supply = [];
  if (refNow) supply.push(component({ family: 'SUPPLY_UNLOCKS', metricId: 'supply_ratios', subjectId: sidOf(refNow.subject), windowEndTs: refNow.knownAtTs, inputs: [refNow], value: { ...supplyRatios(refNow), reference: { provider: refNow.provider, marketCapUsd: refNow.payload.marketCapUsd, fdvUsd: refNow.payload.fdvUsd, circulatingSupply: refNow.payload.circulatingSupply, totalSupply: refNow.payload.totalSupply, maxSupply: refNow.payload.maxSupply, priceUsd: refNow.payload.priceUsd, lastUpdatedTs: refNow.payload.lastUpdatedTs, ageMs: asOfTs - refNow.knownAtTs } }, support: { state: 'COMPLETE', reasons: [] } }));
  if (unlocks.length || byKind('UNLOCK_EVENT').length) supply.push(component({ family: 'SUPPLY_UNLOCKS', metricId: 'unlock_schedule', windowEndTs: asOfTs, inputs: byKind('UNLOCK_EVENT'), value: { upcoming: unlocks.map((u) => ({ provider: u.provider, eventId: u.payload.eventId, scheduledTs: u.payload.scheduledTs, timePrecision: u.payload.timePrecision, amountToken: u.payload.amountToken, amountUsd: u.payload.amountUsd, recipientCategory: u.payload.recipientCategory, unlockType: u.payload.unlockType, tracked: u.payload.tracked, knownAtTs: u.knownAtTs })), untrackedAllocations: byKind('UNLOCK_EVENT').filter((u) => !u.payload.tracked).length, laws: ['UNLOCKED_CIRCULATING_AND_SOLD_ARE_THREE_DIFFERENT_FACTS', 'SCHEDULED_TIME_IS_PAYLOAD_NOT_KNOWLEDGE'] }, support: { state: unlocks.length ? 'COMPLETE' : 'NO_UPCOMING_TRACKED', reasons: [] } }));
  addFamily('SUPPLY_UNLOCKS', supply);
  const dex = []; for (const p of [...new Map(byKind('DEX_POOL').map((o) => [o.subject.poolAddress, latestAtOrBefore(byKind('DEX_POOL', (x) => x.subject.poolAddress === o.subject.poolAddress), asOfTs, (x) => x.knownAtTs)])).values()].filter(Boolean)) dex.push(component({ family: 'DEX_DEFI', metricId: 'pool_liquidity', subjectId: sidOf(p.subject), windowEndTs: p.knownAtTs, inputs: [p], value: { ...p.payload, ageMs: asOfTs - p.knownAtTs, provider: p.provider, laws: ['TOTAL_POOL_VALUE_IS_NOT_EXECUTABLE_DEPTH', 'ROLLING_VOLUME_IS_NOT_NEW_FLOW'] }, support: { state: p.payload.liquidityUsd !== null ? 'COMPLETE' : 'PARTIAL', reasons: [] } }));
  for (const d of [...new Map(byKind('DEFI_METRIC').map((o) => [`${o.payload.metricId}:${o.payload.protocol}:${o.payload.chain}`, latestAtOrBefore(byKind('DEFI_METRIC', (x) => x.payload.metricId === o.payload.metricId && x.payload.protocol === o.payload.protocol && x.payload.chain === o.payload.chain), asOfTs, (x) => x.knownAtTs)])).values()].filter(Boolean)) dex.push(component({ family: 'DEX_DEFI', metricId: d.payload.metricId === 'protocol_tvl' || d.payload.metricId === 'chain_tvl' ? 'protocol_tvl' : /apy/.test(d.payload.metricId) ? 'lending_rates' : 'protocol_fees_revenue', subjectId: sidOf(d.subject), windowStartTs: d.periodStartTs, windowEndTs: d.knownAtTs, inputs: [d], value: { ...d.payload, ageMs: asOfTs - d.knownAtTs, provider: d.provider, law: d.payload.metricId.includes('tvl') ? 'TVL_CHANGES_INCLUDE_PRICE_EFFECTS' : d.payload.metricId.includes('apy') ? 'APY_IS_NOT_A_FUNDING_RATE' : 'GROSS_AND_NET_DIFFER' }, support: { state: d.payload.value !== null ? 'COMPLETE' : 'MISSING', reasons: [] } }));
  addFamily('DEX_DEFI', dex);
  const onchain = byKind('ONCHAIN_METRIC'); /* a period still open at the as-of (the current 5m whale interval, a provisional day) is never bound as a complete component */ const latestMetric = (pred) => latestAtOrBefore(onchain.filter((x) => pred(x) && !(Number.isSafeInteger(x.periodEndTs) && x.periodEndTs > asOfTs)), asOfTs, (x) => x.knownAtTs);
  const flowComps = []; const netProviders = [...new Set(onchain.filter((o) => o.payload.metricId === 'exchange_inflow').map((o) => `${o.provider}|${o.payload.entitySet}`))].sort();
  for (const key of netProviders) { const [prov, ent] = key.split('|'); const inflow = latestMetric((o) => o.provider === prov && o.payload.entitySet === ent && o.payload.metricId === 'exchange_inflow'); const outflow = inflow ? latestMetric((o) => o.provider === prov && o.payload.entitySet === ent && o.payload.metricId === 'exchange_outflow' && o.periodStartTs === inflow.periodStartTs) : null; const nf = exchangeNetFlow(inflow, outflow); flowComps.push(component({ family: 'ONCHAIN_ENTITY_FLOW', metricId: 'exchange_net_flow', windowStartTs: inflow?.periodStartTs ?? null, windowEndTs: inflow?.periodEndTs ?? null, inputs: [inflow, outflow].filter(Boolean), value: { provider: prov, ...nf, ageMs: inflow ? asOfTs - inflow.knownAtTs : null }, support: nf.support })); }
  const reserve = latestMetric((o) => o.payload.metricId === 'exchange_reserve'); if (reserve) flowComps.push(component({ family: 'ONCHAIN_ENTITY_FLOW', metricId: 'exchange_reserve', windowStartTs: reserve.periodStartTs, windowEndTs: reserve.periodEndTs, inputs: [reserve], value: { provider: reserve.provider, ...reserve.payload, ageMs: asOfTs - reserve.knownAtTs }, support: { state: reserve.payload.value !== null ? 'COMPLETE' : 'MISSING', reasons: [] } }));
  const cohort = latestMetric((o) => o.payload.metricId === 'holder_age_cohort'); if (cohort) flowComps.push(component({ family: 'ONCHAIN_ENTITY_FLOW', metricId: 'holder_cohorts', windowStartTs: cohort.periodStartTs, windowEndTs: cohort.periodEndTs, inputs: [cohort], value: { provider: cohort.provider, ...cohort.payload, ageMs: asOfTs - cohort.knownAtTs }, support: { state: cohort.payload.value !== null ? 'COMPLETE' : 'MISSING', reasons: [] } }));
  addFamily('ONCHAIN_ENTITY_FLOW', flowComps);
  // closeout R03/R04: the native metric -> registered metric mapping is CLOSED (NETWORK_METRIC_OF); a native id without a registered
  // metric (supply, developer activity) is never relabelled as an active-address observation
  const net = []; for (const id of Object.keys(NETWORK_METRIC_OF)) { for (const prov of [...new Set(onchain.filter((o) => o.payload.metricId === id).map((o) => o.provider))].sort()) { const o = latestMetric((x) => x.payload.metricId === id && x.provider === prov); if (!o) continue; const prev = latestAtOrBefore(onchain.filter((x) => x.payload.metricId === id && x.provider === prov && x.periodStartTs < o.periodStartTs), asOfTs, (x) => x.knownAtTs); net.push(component({ family: 'NETWORK_ACTIVITY', metricId: NETWORK_METRIC_OF[id], windowStartTs: o.periodStartTs, windowEndTs: o.periodEndTs, inputs: [o, prev].filter(Boolean), value: { nativeMetric: id, provider: prov, ...o.payload, previousValue: prev?.payload.value ?? null, change: isFiniteNum(o.payload.value) && isFiniteNum(prev?.payload.value) ? o.payload.value - prev.payload.value : null, ageMs: asOfTs - o.knownAtTs }, support: { state: o.payload.value !== null ? 'COMPLETE' : 'MISSING', reasons: [] } })); } }
  addFamily('NETWORK_ACTIVITY', net);
  const stables = byKind('STABLECOIN_METRIC'); const stab = [];
  for (const key of [...new Set(stables.filter((o) => o.payload.metricId === 'circulating_supply').map((o) => `${o.payload.stablecoinId}|${o.payload.chain}`))].sort()) { const [sc, chain] = key.split('|'); const list = stables.filter((o) => o.payload.metricId === 'circulating_supply' && o.payload.stablecoinId === sc && String(o.payload.chain) === chain); const now = latestAtOrBefore(list, asOfTs, (x) => x.knownAtTs); const prev = latestAtOrBefore(list.filter((x) => x.knownAtTs < now.knownAtTs), asOfTs, (x) => x.knownAtTs); const peg = latestAtOrBefore(stables.filter((o) => o.payload.metricId === 'peg_price' && o.payload.stablecoinId === sc), asOfTs, (x) => x.knownAtTs); stab.push(component({ family: 'STABLECOIN_LIQUIDITY', metricId: 'stablecoin_supply_change', windowStartTs: prev?.knownAtTs ?? null, windowEndTs: now.knownAtTs, inputs: [now, prev, peg].filter(Boolean), value: { stablecoinId: sc, chain: chain === 'null' ? null : chain, ...stablecoinChange(prev, now), current: now.payload.value, pegPrice: peg?.payload.value ?? null, pegDeviationBps: pegDeviationBps(peg?.payload.value ?? null), pegAgeMs: peg ? asOfTs - peg.knownAtTs : null, ageMs: asOfTs - now.knownAtTs, laws: ['BRIDGED_BALANCES_NEVER_DOUBLE_COUNTED', 'SUPPLY_EXPANSION_IS_NOT_A_TOKEN_PURCHASE', 'NO_PARITY_DEFAULT'] }, support: { state: prev ? 'COMPLETE' : 'SINGLE_POINT', reasons: prev ? [] : ['NO_PRIOR_POINT'] } })); }
  addFamily('STABLECOIN_LIQUIDITY', stab);
  const etf = byKind('ETF_FLOW');
  const etfScopes = partitionNativeSeries(etf, (o) => seriesKeyOf({ ...o, payload: { ...o.payload, fund: null } }));
  addFamily('ETF_FLOWS', etfScopes.map((scope) => { const selected = selectNativeSeries(scope, { asOfTs }).selected; const es = etfFlowSummary(selected); return component({ family: 'ETF_FLOWS', metricId: 'etf_daily_flow', windowStartTs: es.latest ? es.latest.periodStartTs : null, windowEndTs: es.latest ? es.latest.periodEndTs : null, inputs: selected, value: { ...es, ageMs: es.latest ? asOfTs - es.latest.receivedTs : null, funds: [...new Set(selected.map((f) => f.payload.fund).filter(Boolean))].sort() }, support: es.support }); }));
  const macro = [];
  const events = byKind('ECONOMIC_EVENT'); const upcoming = events.filter((e) => e.payload.scheduledTs !== null && e.payload.scheduledTs > asOfTs).sort((a, b) => a.payload.scheduledTs - b.payload.scheduledTs).slice(0, 16); const released = events.filter((e) => e.payload.actualValue !== null && e.payload.scheduledTs !== null && e.payload.scheduledTs <= asOfTs).sort((a, b) => b.payload.scheduledTs - a.payload.scheduledTs).slice(0, 16);
  if (events.length) macro.push(component({ family: 'MACRO_RELEASES', metricId: 'macro_surprise', windowEndTs: asOfTs, inputs: [...upcoming, ...released], value: { upcoming: upcoming.map((e) => ({ eventName: e.payload.eventName, countryCode: e.payload.countryCode, scheduledTs: e.payload.scheduledTs, timePrecision: e.payload.timePrecision, forecastValue: e.payload.forecastValue, unit: e.payload.unit, importance: e.payload.importance })), released: released.map((e) => ({ eventName: e.payload.eventName, countryCode: e.payload.countryCode, scheduledTs: e.payload.scheduledTs, actual: e.payload.actualValue, forecast: e.payload.forecastValue, unit: e.payload.unit, surprise: macroSurprise(e) })) }, support: { state: 'COMPLETE', reasons: [] } }));
  addFamily('MACRO_RELEASES', macro);
  const evs = byKind('EVENT_REFERENCE').filter((e) => e.payload.eventKind !== 'INFRA_INCIDENT').sort((a, b) => (b.sourceEventTs ?? b.knownAtTs) - (a.sourceEventTs ?? a.knownAtTs)).slice(0, 32);
  addFamily('OFFICIAL_SOCIAL_EVENTS', evs.length ? [component({ family: 'OFFICIAL_SOCIAL_EVENTS', metricId: 'event_references', windowEndTs: asOfTs, inputs: evs, value: { events: evs.map((e) => ({ observationId: e.observationId, eventKind: e.payload.eventKind, sourceProvider: e.payload.sourceProvider, nativeRef: e.payload.nativeRef, sourceEventTs: e.payload.sourceEventTs, knownAtTs: e.knownAtTs, status: e.payload.status, headline: e.payload.headline, untrusted: e.payload.untrusted })), law: 'HEADLINES_ARE_UNTRUSTED_DATA_NEVER_INSTRUCTIONS' }, support: { state: 'COMPLETE', reasons: [] } })] : []);
  const infra = byKind('PROVIDER_STATUS').concat(byKind('EVENT_REFERENCE').filter((e) => e.payload.eventKind === 'INFRA_INCIDENT'));
  addFamily('INFRASTRUCTURE_STATUS', infra.length ? [component({ family: 'INFRASTRUCTURE_STATUS', metricId: 'provider_status', windowEndTs: asOfTs, inputs: infra, value: { statuses: infra.filter((o) => o.kind === 'PROVIDER_STATUS').map((o) => ({ providerId: o.payload.providerId, component: o.payload.component, status: o.payload.status, knownAtTs: o.knownAtTs })), incidents: infra.filter((o) => o.kind === 'EVENT_REFERENCE').map((o) => ({ nativeRef: o.payload.nativeRef, status: o.payload.status, sourceEventTs: o.payload.sourceEventTs, headline: o.payload.headline, untrusted: true })), law: 'EXPERIMENTAL_INFRASTRUCTURE_OBSERVATIONS' }, support: { state: 'COMPLETE', reasons: [] } })] : []);
  const ctx = { contextVersion: CONTEXT_VERSION, contextId: 'mctx-x', canonicalCoin, asOfTs, derivationTs: asOfTs, recipeSetVersion: RECIPE_SET_VERSION, captureRef, subjects: marketSubjects.map((s) => ({ subjectId: sidOf(s), ...s })), families, omitted, resourceState: resourceState ? { subjects: resourceState.subjects ?? null, totalBytes: resourceState.totalBytes ?? null, evictions: resourceState.evictions ?? null } : null, limits: { maxInputIds: MAX_INPUT_IDS, maxComponentsPerFamily: MAX_COMPONENTS_PER_FAMILY, bookEndpointMaxAgeMs: BOOK_ENDPOINT_MAX_AGE_MS } };
  ctx.contextId = contextIdentity(ctx);
  const inputReferences = {}; for (const o of admissible) if (usedIds.has(o.observationId)) inputReferences[o.observationId] = { provider: o.provider, kind: o.kind, receivedTs: o.receivedTs, knownAtTs: o.knownAtTs, sourceEventTs: o.sourceEventTs };
  return deepFreeze({ context: ctx, inputReferences, admissibleCount: admissible.length, lateCount: late });
}

// ---- validator (shared by builder output, publisher, reopen, evidence builder) ----------------------------------------
// closeout P5: the pure validator closes EVERY container of the saved shape (top level, family entries, family coverage rows,
// subjects, omission / resource / limit metadata, the capture reference, components and their values) with typed scalars; a
// diagnostic names the schema path or key position, never the untrusted key or value text.
export const FAMILY_ENTRY_KEYS = Object.freeze(['state', 'components', 'coverage']);
export const FAMILY_COVERAGE_KEYS = Object.freeze(['coverageId', 'provider', 'endpointId', 'subjectId', 'kind', 'state', 'reasonCodes', 'startTs', 'endTs', 'observationCount', 'droppedCount']);
export const OMITTED_KEYS = Object.freeze(['lateArrivals', 'componentsOverCap', 'inputIdsTruncated']);
export const RESOURCE_STATE_KEYS = Object.freeze(['subjects', 'totalBytes', 'evictions']);
export const EVICTION_KEYS = Object.freeze(['trades', 'bookSamples', 'bars', 'subjects', 'bytesPressure']);
export const LIMIT_KEYS = Object.freeze(['maxInputIds', 'maxComponentsPerFamily', 'bookEndpointMaxAgeMs']);
export const SEALED_CAPTURE_REF_KEYS = Object.freeze(['bundleId', 'manifestSha256', 'observationsSha256', 'coverageSha256']);
export const MAX_LIMITATIONS = 32;
const isCount = (v) => Number.isSafeInteger(v) && v >= 0; const isTsOrNull = (v) => v === null || isTs(v); const isCountOrNull = (v) => v === null || isCount(v);
const SUBJECT_ID_RE = /^ms-[0-9a-f]{32}$/; const OBS_ID_RE = /^mo-[0-9a-f]{64}$/; const SHA_RE = /^[0-9a-f]{64}$/; const BUNDLE_RE = /^mb-[0-9a-f]{64}$/;
const shortStr = (v, max = 300) => typeof v === 'string' && v.length >= 1 && v.length <= max;
function captureRefError(ref, where) {
  if (!isPlainObject(ref)) return `${where}: must be an object`;
  if (Object.hasOwn(ref, 'prefixVersion')) { // a versioned capture prefix: closed by PREFIX_KEYS here, bound to its bytes by prefixError at the bundle reader
    const k = exactKeys(ref, PREFIX_KEYS, where); if (k) return k;
    if (ref.prefixVersion !== PREFIX_VERSION || !/^mpx-[0-9a-f]{64}$/.test(String(ref.prefixId)) || !(ref.bundleId === null || BUNDLE_RE.test(String(ref.bundleId))) || !(ref.manifestSha256 === null || SHA_RE.test(String(ref.manifestSha256))) || !Array.isArray(ref.segments) || !isPlainObject(ref.membership) || !isPlainObject(ref.limits) || !(ref.resourceState === null || isPlainObject(ref.resourceState)) || !(ref.recording === null || isPlainObject(ref.recording))) return `${where}: prefix reference malformed`;
    return null;
  }
  const k = exactKeys(ref, SEALED_CAPTURE_REF_KEYS, where); if (k) return k;
  if (!BUNDLE_RE.test(String(ref.bundleId)) || !SHA_RE.test(String(ref.manifestSha256)) || !SHA_RE.test(String(ref.observationsSha256)) || !SHA_RE.test(String(ref.coverageSha256))) return `${where}: sealed capture reference malformed`;
  return null;
}
function familyCoverageError(c, where) {
  const k = exactKeys(c, FAMILY_COVERAGE_KEYS, where); if (k) return k;
  if (!/^mc-[0-9a-f]{40}$/.test(String(c.coverageId)) || !PROVIDER_IDS.includes(c.provider) || !shortStr(c.endpointId, 120) || !SUBJECT_ID_RE.test(String(c.subjectId)) || !(c.kind === null || PAYLOAD_KINDS.includes(c.kind))) return `${where}: identity malformed`;
  if (!COVERAGE_STATES.includes(c.state) || !Array.isArray(c.reasonCodes) || c.reasonCodes.length > 16 || c.reasonCodes.some((r) => !QUALITY_REASON_CODES.includes(r))) return `${where}: state/reasons malformed`;
  if (!isTs(c.startTs) || !isTsOrNull(c.endTs) || (c.endTs !== null && c.endTs < c.startTs) || !isCount(c.observationCount) || !isCount(c.droppedCount)) return `${where}: interval/counters malformed`;
  return null;
}
function subjectEntryError(s, where) {
  if (!isPlainObject(s) || !Object.hasOwn(s, 'subjectKind') || !SUBJECT_KEYS[s.subjectKind]) return `${where}: subject malformed`;
  const k = exactKeys(s, ['subjectId', ...SUBJECT_KEYS[s.subjectKind]], where); if (k) return k;
  const body = {}; for (const key of SUBJECT_KEYS[s.subjectKind]) body[key] = s[key];
  const se = subjectError(body, where); if (se) return se;
  if (s.subjectId !== `ms-${canonicalDigest(body).slice(0, 32)}`) return `${where}: subjectId does not match the subject`;
  return null;
}
export function contextError(ctx, { inputReferences = null, where = 'context' } = {}) {
  const k = exactKeys(ctx, CONTEXT_KEYS, where); if (k) return k;
  if (LEGACY_CONTEXT_VERSIONS.includes(ctx.contextVersion)) return `${where}: legacy context version ${ctx.contextVersion} lacks coverage / census proof and is not converted — rebuild from its capture`;
  if (ctx.contextVersion !== CONTEXT_VERSION || ctx.recipeSetVersion !== RECIPE_SET_VERSION) return `${where}: unsupported version`;
  if (!/^[A-Z0-9][A-Z0-9.]{0,14}$/.test(String(ctx.canonicalCoin)) || !isTs(ctx.asOfTs) || !isTs(ctx.derivationTs) || ctx.derivationTs > ctx.asOfTs) return `${where}: identity/clock malformed`;
  if (!isPlainObject(ctx.captureRef) || !isPlainObject(ctx.families) || !isPlainObject(ctx.omitted) || !isPlainObject(ctx.limits) || !Array.isArray(ctx.subjects) || !(ctx.resourceState === null || isPlainObject(ctx.resourceState))) return `${where}: structure malformed`;
  const cr = captureRefError(ctx.captureRef, `${where}.captureRef`); if (cr) return cr;
  const ok = exactKeys(ctx.omitted, OMITTED_KEYS, `${where}.omitted`); if (ok) return ok; if (!OMITTED_KEYS.every((key) => isCount(ctx.omitted[key]))) return `${where}.omitted: counts malformed`;
  const lk = exactKeys(ctx.limits, LIMIT_KEYS, `${where}.limits`); if (lk) return lk; if (!LIMIT_KEYS.every((key) => isCount(ctx.limits[key]) && ctx.limits[key] > 0)) return `${where}.limits: malformed`;
  if (ctx.resourceState !== null) { const rk = exactKeys(ctx.resourceState, RESOURCE_STATE_KEYS, `${where}.resourceState`); if (rk) return rk; if (!isCountOrNull(ctx.resourceState.subjects) || !isCountOrNull(ctx.resourceState.totalBytes) || !(ctx.resourceState.evictions === null || isPlainObject(ctx.resourceState.evictions))) return `${where}.resourceState: malformed`; if (ctx.resourceState.evictions !== null) { const ek = exactKeys(ctx.resourceState.evictions, EVICTION_KEYS, `${where}.resourceState.evictions`); if (ek) return ek; if (!EVICTION_KEYS.every((key) => isCount(ctx.resourceState.evictions[key]))) return `${where}.resourceState.evictions: counts malformed`; } }
  if (ctx.subjects.length > 256) return `${where}.subjects: over the cap`; const subjectIds = new Set();
  for (let i = 0; i < ctx.subjects.length; i += 1) { const e = subjectEntryError(ctx.subjects[i], `${where}.subjects[${i}]`); if (e) return e; if (subjectIds.has(ctx.subjects[i].subjectId)) return `${where}.subjects[${i}]: duplicate subject`; subjectIds.add(ctx.subjects[i].subjectId); }
  const seen = new Set(); const famSeen = new Set();
  for (const fam of Object.keys(ctx.families)) {
    if (!FAMILIES.includes(fam)) return `${where}.families: undeclared family at position ${famSeen.size + 1}`; famSeen.add(fam);
    const f = ctx.families[fam]; const fk = exactKeys(f, FAMILY_ENTRY_KEYS, `${where}.${fam}`); if (fk) return fk;
    if (!FAMILY_STATES.includes(f.state) || !Array.isArray(f.components) || !Array.isArray(f.coverage)) return `${where}.${fam}: malformed`;
    if (f.components.length > MAX_COMPONENTS_PER_FAMILY) return `${where}.${fam}: over the component cap`;
    if (f.coverage.length > 4_096) return `${where}.${fam}.coverage: over the cap`;
    for (let i = 0; i < f.coverage.length; i += 1) { const e = familyCoverageError(f.coverage[i], `${where}.${fam}.coverage[${i}]`); if (e) return e; }
    for (let i = 0; i < f.components.length; i += 1) {
      const c = f.components[i]; const w = `${where}.${fam}[${i}]`; const e = exactKeys(c, COMPONENT_KEYS, w); if (e) return e;
      const be = componentBindingError(c, fam, w); if (be) return be; // correction D: family + metric + recipe + version bound together
      if (!(c.subjectId === null || SUBJECT_ID_RE.test(String(c.subjectId))) || !isTsOrNull(c.windowStartTs) || !isTsOrNull(c.windowEndTs) || !isTs(c.derivationTs) || !isTsOrNull(c.inputKnownAtMax)) return `${w}: subject/clock fields malformed`;
      if (!Array.isArray(c.inputObservationIds) || c.inputObservationIds.length > MAX_INPUT_IDS || c.inputObservationIds.some((id) => !OBS_ID_RE.test(String(id))) || new Set(c.inputObservationIds).size !== c.inputObservationIds.length || [...c.inputObservationIds].sort().join() !== c.inputObservationIds.join()) return `${w}: input ids must be a sorted unique set`;
      if (!isCount(c.inputObservationCount)) return `${w}.inputObservationCount: must be a non-negative integer`;
      if (c.inputObservationCount < c.inputObservationIds.length) return `${w}: input count below listed ids`;
      if (!SHA_RE.test(String(c.inputDigest))) return `${w}.inputDigest: malformed`;
      if (!Array.isArray(c.limitations) || c.limitations.length > MAX_LIMITATIONS || c.limitations.some((l) => !shortStr(l, 300))) return `${w}.limitations: malformed`;
      const ce = derivationClockError({ windowEndTs: c.windowEndTs, derivationTs: c.derivationTs, asOfTs: ctx.asOfTs, inputKnownAtTs: c.inputKnownAtMax === null ? [] : [c.inputKnownAtMax] }, w); if (ce) return ce;
      if (c.windowStartTs !== null && c.windowEndTs !== null && c.windowStartTs > c.windowEndTs) return `${w}: window reversed`;
      if (inputReferences) { for (const id of c.inputObservationIds) { const ref = inputReferences[id]; if (!ref) return `${w}: input id not in input references`; if (ref.knownAtTs > c.derivationTs) return `${w}: input known after derivation`; } if (c.inputObservationCount === c.inputObservationIds.length && c.inputDigest !== canonicalDigest(c.inputObservationIds)) return `${w}: input digest disagrees`; const listedMax = c.inputObservationIds.length ? Math.max(...c.inputObservationIds.map((id) => inputReferences[id].knownAtTs)) : null; if (listedMax !== null && (c.inputObservationCount === c.inputObservationIds.length ? c.inputKnownAtMax !== listedMax : c.inputKnownAtMax < listedMax)) return `${w}: inputKnownAtMax disagrees with the references`; }
      // closeout R07: the value and support of every component obey its metric's CLOSED schema (types, enums, nullability, nesting)
      const se = contextSupportError(c.support, `${w}.support`); if (se) return se;
      const ve = componentValueError(c, `${w}.value`); if (ve) return ve;
      if (typeof c.componentId !== 'string' || componentIdentity(c) !== c.componentId) return `${w}: componentId does not match content`;
      if (seen.has(c.componentId)) return `${w}: duplicate component`; seen.add(c.componentId);
      if (JSON.stringify(c.value).includes(ctx.contextId)) return `${w}: a component references the summary (cycle)`;
    }
  }
  if (typeof ctx.contextId !== 'string' || contextIdentity(ctx) !== ctx.contextId) return `${where}: contextId does not match content`;
  return null;
}
export const INPUT_REFERENCE_KEYS = Object.freeze(['provider', 'kind', 'receivedTs', 'knownAtTs', 'sourceEventTs']);
export function inputReferencesError(refs, where = 'input-references') {
  if (!isPlainObject(refs)) return `${where}: expected object`;
  for (const [id, r] of Object.entries(refs)) { if (!/^mo-[0-9a-f]{64}$/.test(id)) return `${where}: malformed observation id`; const e = exactKeys(r, INPUT_REFERENCE_KEYS, where); if (e) return e; if (!PROVIDER_IDS.includes(r.provider) || !PAYLOAD_KINDS.includes(r.kind) || !isTs(r.receivedTs) || !isTs(r.knownAtTs) || r.knownAtTs < r.receivedTs || !(r.sourceEventTs === null || isTs(r.sourceEventTs))) return `${where}: reference malformed`; }
  return null;
}
