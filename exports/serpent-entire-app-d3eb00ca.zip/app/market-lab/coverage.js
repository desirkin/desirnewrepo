// MARKET LAB — the declared-plan / required-family / cost matrix (§3). Compares SUPPLIED plan records against the
// required family x asset x latency matrix, computes calls/day and calls/month from the actual cadence schedule, and
// lists the cheapest SUPPLIED qualifying plan combination with uncovered requirements and unknown prices. No web
// shopping, no claim of global optimality, no unverified trial counted as zero-cost coverage.
import { deepFreeze, FAMILIES, PROVIDER_IDS } from './contracts.js';
import { ENDPOINTS, PROVIDERS, COST_FACTS, providersForFamily } from './registry.js';
import { credentialPresence, paidCallAuthorized } from './policy.js';
import { DAY_MS } from './time.js';

const ROUTE_PLAN = deepFreeze({ // per family: which endpoints the owner schedules per subject (WS = 0 REST calls/day)
  SPOT_PRICE_CHART: [['KRAKEN_SPOT', 'rest-ohlc', 6], ['COINBASE_SPOT', 'rest-candles', 3]], SPOT_FLOW: [['KRAKEN_SPOT', 'ws-v2', 0], ['COINBASE_SPOT', 'ws-feed', 0]], DISPLAYED_LIQUIDITY: [['KRAKEN_SPOT', 'ws-v2', 0], ['COINBASE_SPOT', 'ws-feed', 0]], CROSS_VENUE: [['KRAKEN_SPOT', 'rest-ticker', 1], ['COINBASE_SPOT', 'rest-book', 1]],
  DERIVATIVES_FUNDING_OI: [['KRAKEN_DERIVATIVES', 'rest-tickers', 1], ['COINGLASS', 'oi-exchange-list', 1]], LIQUIDATIONS: [['COINGLASS', 'liquidation-aggregated-history', 1]],
  SUPPLY_UNLOCKS: [['COINGECKO', 'coins-markets', 1], ['COINGLASS', 'coin-vesting', 1], ['TOKENOMIST', 'upcoming-unlock-events', 0.05]], DEX_DEFI: [['GECKOTERMINAL', 'pool', 1], ['DEFILLAMA', 'tvl', 1]], ONCHAIN_ENTITY_FLOW: [['CRYPTOQUANT', 'exchange-flows', 3]], NETWORK_ACTIVITY: [['CRYPTOQUANT', 'network-data', 2]],
  STABLECOIN_LIQUIDITY: [['DEFILLAMA', 'stablecoins', 0.2]], ETF_FLOWS: [['COINGLASS', 'etf-bitcoin-flow-history', 0.2]], MACRO_RELEASES: [['COINGLASS', 'economic-data', 0.2]], OFFICIAL_SOCIAL_EVENTS: [['SETTLED_RECORDS', 'official-claims', 0]], INFRASTRUCTURE_STATUS: [['SETTLED_RECORDS', 'gateway-status', 0]],
});
const perSubjectMultiplier = (endpointId) => (endpointId === 'stablecoins' || endpointId === 'economic-data' || endpointId === 'etf-bitcoin-flow-history' || endpointId === 'upcoming-unlock-events' ? 0 : 1); // shared across subjects (cached by identity/vintage)
export function buildCoverageMatrix({ policy, subjects, env = {}, probeResults = null }) {
  const presence = credentialPresence(policy, env); const nSubjects = subjects.subjects.length;
  const families = {}; const providerCalls = {};
  for (const fam of FAMILIES) {
    const routes = ROUTE_PLAN[fam].map(([providerId, endpointId, weight]) => { const ep = ENDPOINTS.find((e) => e.providerId === providerId && e.endpointId === endpointId); const p = policy.providers[providerId]; const callsPerDay = ep && ep.method !== 'WS' && ep.cadenceMs ? Math.ceil((DAY_MS / ep.cadenceMs) * weight * (perSubjectMultiplier(endpointId) ? nSubjects : 1)) : 0; const enabled = p?.enabled === true; const paidOk = enabled && paidCallAuthorized(policy, providerId); if (enabled) providerCalls[providerId] = (providerCalls[providerId] ?? 0) + callsPerDay;
      return { providerId, endpointId, method: ep?.method ?? null, planRequirement: ep?.planRequirement ?? null, cadenceMs: ep?.cadenceMs ?? null, lagMs: ep?.lagMs ?? null, callsPerDay, callsPerMonth: callsPerDay * 30, enabled, access: presence[providerId]?.access ?? 'UNVERIFIED', billing: p?.plan.billing ?? 'UNKNOWN', paidCallAuthorized: paidOk, quoteUsdPerMonth: p?.plan.quoteUsdPerMonth ?? null, planName: p?.plan.name ?? null, attestation: p?.plan.attestation ?? null, probe: probeResults?.[providerId] ?? null }; });
    const covering = routes.filter((r) => r.enabled && (r.billing === 'FREE' || r.paidCallAuthorized) && (r.access === 'PUBLIC' || r.access === 'CONFIGURED'));
    const cheapest = covering.map((r) => ({ providerId: r.providerId, quoteUsdPerMonth: r.billing === 'FREE' ? 0 : r.quoteUsdPerMonth })).sort((a, b) => (a.quoteUsdPerMonth === null ? 1e12 : a.quoteUsdPerMonth) - (b.quoteUsdPerMonth === null ? 1e12 : b.quoteUsdPerMonth))[0] ?? null;
    families[fam] = { requiredProviders: providersForFamily(fam), routes, state: covering.length ? 'COVERED_BY_DECLARED_POLICY' : routes.some((r) => r.enabled) ? 'ENABLED_BUT_BLOCKED' : 'UNCOVERED', cheapestSupplied: cheapest, unknownPrice: covering.filter((r) => r.billing !== 'FREE' && r.quoteUsdPerMonth === null).map((r) => r.providerId) };
  }
  const chosen = new Map(); for (const fam of FAMILIES) { const c = families[fam].cheapestSupplied; if (c && c.quoteUsdPerMonth !== null && c.quoteUsdPerMonth > 0) chosen.set(c.providerId, c.quoteUsdPerMonth); }
  const totalKnown = [...chosen.values()].reduce((a, b) => a + b, 0);
  const quotaCheck = Object.entries(providerCalls).map(([id, calls]) => { const p = policy.providers[id]; return { providerId: id, callsPerDay: calls, callsPerMonth: calls * 30, maxCallsPerDay: p.limits.maxCallsPerDay, maxCallsPerMonth: p.limits.maxCallsPerMonth, includedCallsPerMonth: p.plan.includedCallsPerMonth, withinLocalCaps: calls <= p.limits.maxCallsPerDay && calls * 30 <= p.limits.maxCallsPerMonth, withinIncludedQuota: p.plan.includedCallsPerMonth === null ? null : calls * 30 <= p.plan.includedCallsPerMonth }; });
  return deepFreeze({ matrixVersion: 'market-coverage-matrix-1', subjects: nSubjects, families, providerCalls: quotaCheck, cheapestSuppliedCombination: { providers: [...chosen.entries()].map(([providerId, usd]) => ({ providerId, quoteUsdPerMonth: usd })), knownUsdPerMonth: totalKnown, unknownPriceProviders: [...new Set(FAMILIES.flatMap((f) => families[f].unknownPrice))], uncoveredFamilies: FAMILIES.filter((f) => families[f].state !== 'COVERED_BY_DECLARED_POLICY'), law: 'cheapest among SUPPLIED plan records only; not a proof of global optimality; trials are not zero-cost coverage' }, costFacts: COST_FACTS, billingStates: { feedOff: 'STOPS_NEW_CALLS_ONLY', subscription: 'NOT_CANCELLED_BY_THIS_SOFTWARE', vendorBilling: 'CONTINUES_UNTIL_CANCELLED_WITH_VENDOR' }, providers: Object.fromEntries(PROVIDER_IDS.map((id) => [id, { name: PROVIDERS[id].name, hosts: PROVIDERS[id].hosts, billing: PROVIDERS[id].billing, pricing: PROVIDERS[id].pricing ?? null, access: presence[id]?.access ?? null, enabled: policy.providers[id]?.enabled ?? false }])) });
}
export { ROUTE_PLAN };
