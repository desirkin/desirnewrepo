// JUDGE — closed 1m bar history for the 61-bar indicator block (ticket §4.4). Cold start loads validated locally retained
// bars, then permitted missing-history work goes through the existing public REST OHLC path (bounded, asynchronous,
// retrieval / known-at floors kept); afterwards bars are continued from ACCEPTED continuous trades. A minute without an
// observed trade has no observed price: it stays a gap (never filled from a later bar), which honestly blocks the block
// until a refreshed retrieval supplies verified bars. Nothing here invents signed trades, quote notional or L2 history.
import * as M from '../execution/money.js';
import { BAR_MS, BARS_REQUIRED } from './features.js';

export const HISTORY_VERSION = 'judge-history-1';
export const KRAKEN_OHLC_URL = 'https://api.kraken.com/0/public/OHLC';
const num = (v) => (typeof v === 'string' ? Number(v) : v);
// onRetrieved (focused completion §3): the exact retrieved OHLC rows with their receipt clock and the provider's `last` committed bar
// are handed to the caller (the composition records them as HISTORY inputs) — a replay seeds the same rows through ingestRows
export function createBarHistory({ clock, fetchImpl = null, pairKeyOf = () => null, log = () => {}, maxBars = 720, refreshMs = 60_000, onRetrieved = null } = {}) {
  const series = new Map(); // symbol -> { bars: Map(periodStartTs -> bar), live: Map(periodStartTs -> partial), lastRetrievalTs, retrievalKnownAtTs, inFlight, failures }
  const s = (symbol) => series.get(symbol) ?? (series.set(symbol, { bars: new Map(), live: new Map(), lastRetrievalTs: null, retrievalKnownAtTs: null, inFlight: false, failures: 0 }), series.get(symbol));
  function ingestRows(symbol, rows, receiptTs, lastCommitted) { const st = s(symbol); let added = 0; for (const row of rows) { if (!Array.isArray(row) || row.length < 8) continue; const open = Math.round(Number(row[0]) * 1000); if (!Number.isFinite(open)) continue; const provisional = open + BAR_MS > receiptTs || (lastCommitted !== null && open > lastCommitted); const vol = num(row[6]); const count = Number(row[7]); if (provisional) continue; const noTrade = vol === 0 && count === 0; const bar = { periodStartTs: open, periodEndTs: open + BAR_MS, open: noTrade ? null : num(row[1]), high: noTrade ? null : num(row[2]), low: noTrade ? null : num(row[3]), close: noTrade ? null : num(row[4]), volumeBase: vol, volumeQuote: vol !== null && num(row[5]) !== null ? vol * num(row[5]) : null, tradeCount: count, closed: true, source: 'REST_OHLC', knownAtTs: receiptTs }; st.bars.set(open, bar); added += 1; } trim(st); return added; }
  function trim(st) { if (st.bars.size > maxBars) { const keys = [...st.bars.keys()].sort((a, b) => a - b); for (const k of keys.slice(0, st.bars.size - maxBars)) st.bars.delete(k); } }
  // bounded asynchronous retrieval through the public REST OHLC endpoint (no key; a receipt floor is the known-at of every bar)
  async function refresh(symbol) {
    const st = s(symbol); const pair = pairKeyOf(symbol);
    if (!fetchImpl || !pair || st.inFlight) return { ok: false, reason: !fetchImpl ? 'NO_TRANSPORT' : !pair ? 'NO_PAIR_KEY' : 'IN_FLIGHT' };
    st.inFlight = true;
    try {
      const url = `${KRAKEN_OHLC_URL}?pair=${encodeURIComponent(pair)}&interval=1`;
      const r = await fetchImpl(url, { method: 'GET', headers: { accept: 'application/json' } });
      const text = await r.text(); const receiptTs = clock(); const j = JSON.parse(text);
      if (r.ok === false || !Array.isArray(j.error) || j.error.length) { st.failures += 1; return { ok: false, reason: 'PROVIDER_ERROR' }; }
      // pairKeyOf comes from the exact AssetPairs catalog key. No display-name
      // request option is sent, so the response must use that same internal key.
      const keys = Object.keys(j.result ?? {}).filter((key) => key !== 'last');
      if (keys.length !== 1 || keys[0] !== pair || !Array.isArray(j.result[pair])) {
        st.failures += 1; return { ok: false, reason: 'PAIR_IDENTITY_MISMATCH' };
      }
      const rows = j.result[pair];
      const last = Number.isFinite(Number(j.result?.last)) ? Number(j.result.last) * 1000 : null;
      const added = ingestRows(symbol, rows, receiptTs, last);
      st.lastRetrievalTs = receiptTs; st.retrievalKnownAtTs = receiptTs;
      if (onRetrieved) { try { onRetrieved({ symbol, rows, receiptTs, lastCommitted: last }); } catch (err) { log(`history capture ${symbol}: ${String(err?.message ?? err).slice(0, 120)}`); } }
      return { ok: true, added, receiptTs, rows: rows.length, capReached: rows.length >= 720 };
    } catch (err) { st.failures += 1; return { ok: false, reason: String(err?.message ?? err).slice(0, 120) }; }
    finally { st.inFlight = false; }
  }
  // live continuation from accepted trades: partial minute -> closed when the clock passes the minute end
  function onTrade(t) { const st = s(t.symbol); if (t.fromSubscriptionSnapshot) return; const start = Math.floor(t.eventTs / BAR_MS) * BAR_MS; const p = Number(t.price); const q = Number(t.qty); const cur = st.live.get(start) ?? { periodStartTs: start, periodEndTs: start + BAR_MS, open: p, high: p, low: p, close: p, volumeBase: 0, volumeQuote: 0, tradeCount: 0, closed: false, source: 'LIVE_TRADES', knownAtTs: t.receiptTs, epoch: t.feedEpoch }; if (cur.epoch !== t.feedEpoch) cur.gap = true; cur.high = Math.max(cur.high, p); cur.low = Math.min(cur.low, p); cur.close = p; cur.volumeBase += q; cur.volumeQuote += Number(t.quoteNotional); cur.tradeCount += 1; cur.knownAtTs = Math.max(cur.knownAtTs, t.receiptTs); st.live.set(start, cur); }
  function advance(symbol, nowTs, { coverage = null } = {}) { const st = s(symbol); for (const [start, bar] of [...st.live.entries()]) { if (nowTs >= bar.periodEndTs) { st.live.delete(start); const covered = coverage ? coverage.continuous && coverage.startTs <= bar.periodStartTs : true; if (covered && !bar.gap && !st.bars.has(start)) st.bars.set(start, { ...bar, closed: true, knownAtTs: Math.max(bar.knownAtTs, nowTs), coverage: 'CONTINUOUS_TRADES' }); } } trim(st); }
  // the 61 contiguous complete bars ending at the latest closed minute before nowTs (null when any is missing or has no price)
  function bars(symbol, nowTs) { if (!Number.isSafeInteger(nowTs) || nowTs < 0) return null; const st = series.get(symbol); if (!st) return null; const end = Math.floor(nowTs / BAR_MS) * BAR_MS; const out = []; for (let k = BARS_REQUIRED; k >= 1; k -= 1) { const b = st.bars.get(end - k * BAR_MS); if (!b || b.close === null || !Number.isSafeInteger(b.knownAtTs) || b.knownAtTs < b.periodEndTs || b.knownAtTs > nowTs) return null; out.push(Object.freeze({ ...b })); } return out; }
  function status(symbol) { const st = series.get(symbol); if (!st) return null; const end = Math.floor(clock() / BAR_MS) * BAR_MS; let missing = 0; const missingStarts = []; for (let k = BARS_REQUIRED; k >= 1; k -= 1) { const b = st.bars.get(end - k * BAR_MS); if (!b || b.close === null) { missing += 1; if (missingStarts.length < 8) missingStarts.push(end - k * BAR_MS); } } return { symbol, retained: st.bars.size, live: st.live.size, missingOf61: missing, missingStarts, lastRetrievalTs: st.lastRetrievalTs, knownAtFloorTs: st.retrievalKnownAtTs, failures: st.failures, earliestReadyTs: missing ? end + missing * BAR_MS : null }; }
  function needsRefresh(symbol, nowTs) { const st = series.get(symbol); return !st || st.lastRetrievalTs === null || nowTs - st.lastRetrievalTs >= refreshMs; }
  return { bars, refresh, onTrade, advance, status, needsRefresh, ingestRows, symbols: () => [...series.keys()] };
}
