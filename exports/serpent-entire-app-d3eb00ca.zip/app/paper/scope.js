// SERPENT PAPER — the 56-row REQUESTED SENSOR SCOPE (owner ticket of 2026-09-12), mapped onto the repository's own sensor
// inventory (paper/inventory.js). Fifty-six scope rows are NOT fifty-six external providers: a row names a requested
// capability; `inventoryIds` names the inventory row(s) that carry its code, composition, credentials and blocker facts.
// A row whose inventory rows are all NOT_PRESENT is a capability the repository does not implement — it stays in the
// scope, named, with its blocker, and is never dropped because it is blocked. Read-only, no network, no runtime effect.
export const SCOPE_VERSION = 'serpent-sensor-scope-1';
const R = (id, label, inventoryIds, note = null) => Object.freeze({ id, label, inventoryIds: Object.freeze(inventoryIds), note });
export const SCOPE = Object.freeze([
  // MARKET AND FINANCIAL — 20
  R('M01', 'Kraken public L2 books and depth (initial snapshot + ongoing synchronization)', ['TAPE'], 'the execution feed obtains a REAL venue snapshot for a symbol admitted after the subscription (2026-09-12 repair)'),
  R('M02', 'Kraken public trades and subscription / coverage state', ['TAPE']),
  R('M03', 'Kraken candles / configured price history', ['KRAKEN_OHLC_HISTORY']),
  R('M04', 'Kraken ticker, instruments and precision metadata', ['TAPE', 'KRAKEN_SPOT'], 'instrument precision is kept for every announced pair (2026-09-12 repair)'),
  R('M05', 'Kraken derivatives / futures ticker and configured funding', ['KRAKEN_DERIVATIVES']),
  R('M06', 'Kraken Futures Charts historical / open-interest observations', ['KRAKEN_CHARTS_DARK']),
  R('M07', 'Kraken Level 3 (separately permissioned, data-only; never a substitute for M01)', ['KRAKEN_L3_DARK']),
  R('M08', 'Coinbase spot market, trade, book and candle capabilities', ['COINBASE_SPOT']),
  // M09 / M10 retired: the Deribit (options / futures) and Bybit providers were culled to attic/ (SENSE-CULL-3). The whole
  // OPTIONS_TERM_SKEW family died with Deribit (its sole provider); DERIVATIVES_FUNDING_OI + LIQUIDATIONS survive on CoinGlass
  // (Kraken Derivatives too, for OI/funding). M-ids are stable, not renumbered.
  R('M11', 'CoinGecko Demo catalog / market / detail capabilities', ['COINGECKO']),
  R('M12', 'GeckoTerminal DEX / pool observations', ['GECKOTERMINAL']),
  R('M13', 'DefiLlama TVL, fee and stablecoin observations', ['DEFILLAMA']),
  // M14 / M15 retired: the CoinMetrics Community and FRED / ALFRED providers were culled to attic/ (SENSE-CULL-2).
  // NETWORK_ACTIVITY now runs on CryptoQuant alone (Santiment retired, SENSE-CULL-3); MACRO_RELEASES runs on the CoinGlass
  // economic calendar. M-ids are stable, not renumbered.
  R('M16', 'CoinGlass derivatives, liquidation, event / unlock and headline capabilities (each verified separately)', ['COINGLASS'], 'endpoints: oi-exchange-list, funding-exchange-list, liquidation-aggregated-history, coin-unlock-list, coin-vesting, economic-data, article-list'),
  R('M17', 'CryptoQuant on-chain / exchange metrics', ['CRYPTOQUANT']),
  // M18 retired: the Santiment provider was culled to attic/ (SENSE-CULL-3); its whale large-transfer metrics are now unfed
  // (no live provider), the honest NOT_SUPPORTED coverage state. M-ids are stable, not renumbered.
  // M19 retired: the Twelve Data cross-asset provider and the whole CROSS_ASSET family were culled to attic/ (market-lab
  // providers cut). M-ids are stable, not renumbered.
  R('M20', 'Tokenomist unlock events', ['TOKENOMIST']),
  // SOCIAL — 5 (LEAN PASS 4a retired the official StockTwits route S04, TikTok S06 and the Meta / Facebook + Instagram routes S07/S08;
  // the surviving social senses are Bluesky, X, the legacy StockTwits RUMINT aggregate, Reddit and Farcaster. S-ids are stable, not renumbered.)
  R('S01', 'Bluesky Jetstream', ['BLUESKY_OFFICIAL']),
  R('S02', 'X / Twitter configured collection', ['X_OFFICIAL']),
  R('S03', 'Legacy StockTwits aggregate route', ['RUMINT_STOCKTWITS_AGGREGATE']),
  R('S05', 'Reddit', ['REDDIT_OFFICIAL']),
  R('S09', 'Farcaster / Neynar', ['FARCASTER_OFFICIAL', 'FARCASTER_LIVE_TRANSPORT']),
  // OFFICIAL AND NEWS — 6
  R('N01', 'Kraken official announcements / news', ['KRAKEN_OFFICIAL']),
  R('N02', 'SEC press releases', ['SEC_OFFICIAL']),
  R('N03', 'CFTC press releases', ['CFTC_OFFICIAL']),
  R('N04', 'SEC EDGAR filings for the configured issuer / watchlist scope', ['EDGAR_OFFICIAL']),
  R('N05', 'OFAC sanctions updates (identity / diff semantics)', ['OFAC_OFFICIAL']),
  R('N06', 'CoinGlass headlines (linked to M16; not a second poller)', ['COINGLASS'], 'the article-list endpoint of the SAME CoinGlass client and quota accounting'),
  // CRYPTO PUBLISHER CONNECTIONS — 4 (LEAN PASS 4a retired the non-crypto publishers: Reuters/Bloomberg/CNN licensed-only, CNBC/FT/Google-News aggregator)
  R('P05', 'CoinDesk', ['COINDESK_NEWS']),
  R('P06', 'The Block', ['THEBLOCK_NEWS']),
  R('P07', 'Cointelegraph', ['COINTELEGRAPH_NEWS']),
  R('P08', 'Decrypt', ['DECRYPT_NEWS']),
  // EXCHANGE STATUS — 4 (LEAN PASS 4a retired the NOAA / RIPE RIS / Cloudflare Radar infra observation tier and the Tally governance sense)
  R('I05', 'Kraken Statuspage', ['GATEWAY_KRAKEN_STATUS']),
  R('I06', 'Kraken system-status API', ['GATEWAY_KRAKEN_SYSTEM']),
  R('I07', 'Coinbase service status', ['GATEWAY_COINBASE_STATUS']),
  R('I08', 'OKX service status', ['GATEWAY_OKX_STATUS']),
  // INTERNAL CAPABILITIES TO PRESERVE — 3
  R('C01', 'WideEye market scanning', ['WIDEEYE']),
  R('C02', 'Universe coverage and selection', ['UNIVERSE_EXPANSION']),
  R('C03', 'Historical capture / replay and its point-in-time boundaries', ['HISTORICAL_CAPTURE_REPLAY']),
]);
export const SCOPE_IDS = Object.freeze(SCOPE.map((r) => r.id));
// the scope joined to the inventory: one object per scope row carrying the inventory rows it maps to (read-only)
export function scopeInventory(inventory) { const byId = new Map(inventory.rows.map((r) => [r.id, r])); return SCOPE.map((s) => ({ ...s, rows: s.inventoryIds.map((id) => byId.get(id) ?? null) })); }
