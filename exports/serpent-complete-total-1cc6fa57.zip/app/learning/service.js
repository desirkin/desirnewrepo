// LEARN-1 — the supervised recurring data-only learning service. Composed by fly.js behind LEARNING_ENABLED='true'
// exactly like the other observation tiers: constructed dark, fails dark (a learning failure never crashes market
// collection, never touches trading state, never alters a sensor), timers unref'd, heartbeat + counters in
// data/learning/status.json (atomic, no secrets). It observes the wide eye's completed sweep population through an
// INJECTED read-only accessor (the same seam rumor2 uses) — it starts no provider polling of its own and imports
// no execution, judge, watch or tape module.
//
// Each tick: (1) CAPTURE — coverage ledger rows for the whole observed population (the honest denominator) plus
// bounded immutable episodes for triggers, near-misses and a deterministic rotation exploration share;
// (2) MATURATION — attach outcomes whose knowledge floors have passed, from an injected read-only archive source
// (absent archive = honest ARCHIVE_UNAVAILABLE pending state, never invented); (3) LEARNING — refresh provisional
// pattern memory from matured evidence at group level. PAPER stays off; nothing here starts an order process.
import { createLearningStore } from './store.js';
import { buildCoverageRow, buildEpisode } from './capture.js';
import { maturationSweep } from './maturation.js';
import { createMainLaneMeter } from '../lib/main-lane-meter.js';
import { classifyOutcome, nextPatternStep, buildPatternRecord, horizonKeyForScope } from './patterns.js';
import { planCaptureTick, rollCounters, countCapture, coverageAges, emptyDailyCounters, DEFAULT_DAILY_TARGET } from './continuous.js';
import { buildDailySummary } from './summary.js';
import { LEARNING_VERSION, BASELINE_RULE_VERSION, AUTHORITY, PURPOSE, utcDateOf, canonicalDigest } from './contracts.js';
import { PROVIDER_DELAY_EVIDENCE } from './source-delay.js';

export const SERVICE_VERSION = 'learning-service-1';
export const DEFAULT_TICK_MS = 60_000;
export const MAX_EPISODES_PER_TICK = 32;
export const MAX_MATURATION_PER_TICK = 200;

const zFeature = (value, unit) => (Number.isFinite(value) ? { value, unit, lookbackMs: 7 * 86_400_000, availability: 'KNOWN' } : { value: null, unit, lookbackMs: 7 * 86_400_000, availability: 'UNAVAILABLE' });

export function startLearning({
  dataDir, env = process.env, populationSource = null, archiveSource = null,
  // Optional research-only runner, constructed and owned by the composition.
  // No production caller supplies this port. It does not construct providers,
  // promote results, or change Judge. The current runner is synchronous and
  // byte/work bounded, NOT CPU-isolated or a hard wall-time guarantee.
  shadowRunner = null,
  // Optional prospective opportunity-audit outcome owner. Sampling and its
  // durable pre-selection frame live outside this service; this callsite only
  // advances already-due follow-up work. The composition retains ownership.
  opportunityAuditFollowup = null,
  // PUBLISH-FIX-38: the Judge decision bridge (learning/judge-decision-bridge.js) — every PAPER decision becomes an
  // episode in this store, in the Judge's own setup vocabulary. Injected by the composition; absent = no bridge.
  decisionBridge = null,
  // PUBLISH-FIX-39: the promoter (learning/promoter.js) — proposes a one-clause "when" per cell, freezes it, records
  // the forward captures/outcomes and settles the one terminal look. Injected (port or factory over this store).
  promoter = null,
  clock = Date.now, timers = { setInterval, clearInterval }, tickMs = DEFAULT_TICK_MS,
  dailyTarget = DEFAULT_DAILY_TARGET, log = () => {},
  // CPU LANES (Ticket 6): measure how long each learning step occupies the main lane, so a heavy maintenance pass that
  // could delay a bite is visible in status. Injected in tests; a fresh internal meter otherwise. Measurement only.
  meter = createMainLaneMeter({ budgetMs: 50, now: clock }),
} = {}) {
  if (env.LEARNING_ENABLED !== 'true') return { state: () => 'DISABLED', stop: () => {}, tick: () => null };
  if (shadowRunner !== null && (!shadowRunner || typeof shadowRunner !== 'object' || Array.isArray(shadowRunner)
      || typeof shadowRunner.step !== 'function' || typeof shadowRunner.status !== 'function')) throw new Error('SHADOW_RUNNER_PORT_INVALID');
  if (opportunityAuditFollowup !== null && (!opportunityAuditFollowup || typeof opportunityAuditFollowup !== 'object'
      || Array.isArray(opportunityAuditFollowup) || typeof opportunityAuditFollowup.step !== 'function'
      || typeof opportunityAuditFollowup.status !== 'function')) throw new Error('OPPORTUNITY_AUDIT_FOLLOWUP_PORT_INVALID');
  const store = createLearningStore({ dataDir, log });
  if (typeof decisionBridge === 'function') decisionBridge = decisionBridge(store); // a factory receives THIS store (one writer, one journal)
  if (decisionBridge !== null && (!decisionBridge || typeof decisionBridge !== 'object' || typeof decisionBridge.step !== 'function' || typeof decisionBridge.status !== 'function')) throw new Error('DECISION_BRIDGE_PORT_INVALID');
  if (typeof promoter === 'function') promoter = promoter(store);
  if (promoter !== null && (!promoter || typeof promoter !== 'object' || typeof promoter.step !== 'function' || typeof promoter.status !== 'function')) throw new Error('PROMOTER_PORT_INVALID');
  let counters = rollCounters(null, clock());
  let lastTick = null; let ticking = false; let stopped = false;
  const lastCapturedBySymbol = new Map();
  const errors = { capture: 0, maturation: 0, learning: 0, shadow: 0, opportunityAudit: 0, decisionBridge: 0, promoter: 0 };

  let lastRecordedSweepId = null; let summaryJob = null;
  function captureTick(nowTs) {
    const pop = populationSource ? populationSource() : null;
    if (!pop || !Array.isArray(pop.rows) || pop.rows.length === 0) return { captured: 0, coverage: 0, reason: 'NO_POPULATION_SNAPSHOT' };
    const sweepId = `sweep-${pop.sweepId ?? pop.tsMs ?? nowTs}`;
    if (sweepId === lastRecordedSweepId) return { captured: 0, coverage: 0, reason: 'SWEEP_ALREADY_RECORDED' }; // one completed sweep = one recording; replaying it is not new daily evidence
    lastRecordedSweepId = sweepId;
    const sweepTs = Number.isSafeInteger(pop.tsMs) ? pop.tsMs : nowTs;
    if (utcDateOf(sweepTs) !== counters.utcDate) counters = rollCounters(counters, sweepTs);
    let coverage = 0;
    const eligible = [];
    for (const row of pop.rows.slice(0, 5_000)) {
      const symbol = String(row.coin ?? row.symbol ?? '');
      if (!/^[A-Z0-9][A-Z0-9.]{0,14}$/.test(symbol)) continue;
      const evaluated = row.evaluated !== false;
      const attention = evaluated ? 'EVALUATED' : (row.exclusionReason === 'INSUFFICIENT_SERIES' ? 'UNAVAILABLE' : 'MISSED_EVALUATION');
      try {
        store.appendCoverage(buildCoverageRow({ sweepId, sweepTs, canonicalCoin: symbol, attention, reasonCode: row.exclusionReason ?? null, lastEvaluatedTs: lastCapturedBySymbol.get(symbol) ?? null, nextEligibleTs: null, selectionReason: 'SCHEDULED_SWEEP' }));
        coverage += 1;
      } catch (err) { errors.capture += 1; log(`learning capture: coverage row refused (${err.message})`); }
      if (evaluated) eligible.push({ symbol, lastCapturedTs: lastCapturedBySymbol.get(symbol) ?? null, changed: row.verdict === 'RIPPLE' || row.verdict === 'MISSED' || row.cooldownSuppressed === true });
    }
    const capturedTodayBySymbol = new Map(Object.entries(counters.perAsset));
    const plan = planCaptureTick({ eligible, nowTs: sweepTs, capacity: MAX_EPISODES_PER_TICK, capturedTodayBySymbol, dailyTarget, capturedToday: counters.captured });
    counters.shedExtras += plan.shed.extras; counters.shedFloor += plan.shed.floor;
    let captured = 0;
    const rowsBySymbol = new Map(pop.rows.map((r) => [String(r.coin ?? r.symbol ?? ''), r]));
    for (const pick of plan.selected) {
      const row = rowsBySymbol.get(pick.symbol); if (!row) continue;
      const verdict = row.verdict ?? null;
      const decision = verdict === 'RIPPLE' ? 'SELECTED_FOR_SHADOW' : verdict === 'MISSED' ? 'SKIPPED' : row.evaluated === false ? 'UNEVALUABLE' : 'NO_SETUP';
      try {
        const episode = buildEpisode({
          canonicalCoin: pick.symbol, decisionTs: sweepTs, usableAtTs: nowTs, datasetId: 'live-wideeye-sweep',
          mode: 'PROSPECTIVE_SHADOW', evidenceBasis: 'PROSPECTIVE', fidelity: 'PROSPECTIVE_SHADOW',
          featureSet: { features: { zVol: zFeature(row.zVol, 'z_score'), zRet5m: zFeature(row.zRet, 'z_score'), extensionPct: zFeature(row.extension, 'simple_percent'), usdVol24h: zFeature(row.usdVol24h, 'usd') } },
          gates: [{ id: 'WIDEEYE_SWEEP_CLASSIFIER', ok: verdict === 'RIPPLE', observed: verdict, threshold: 'RIPPLE', class: 'SOFT' }],
          decision, baselineScore: Number.isFinite(row.zVol) && Number.isFinite(row.zRet) ? Math.abs(row.zVol) + Math.abs(row.zRet) : null,
          rejection: decision === 'SKIPPED' ? { reasonCode: 'ALREADY_EXTENDED_WAKE_NOT_RIPPLE', observedValue: Number.isFinite(row.extension) ? row.extension : null, threshold: null, class: 'SOFT' } : null,
          setupType: 'WIDEEYE_SWEEP', regime: 'LIVE_UNCLASSIFIED', baselineRuleVersion: BASELINE_RULE_VERSION,
          membershipAtDecision: 'CURRENT_CATALOG_MEMBER',
        });
        const r = store.appendEpisode(episode);
        if (r.appended) { captured += 1; countCapture(counters, pick.symbol); lastCapturedBySymbol.set(pick.symbol, sweepTs); }
      } catch (err) { errors.capture += 1; log(`learning capture: episode refused (${err.message})`); }
    }
    counters.simulated += 0; // replay work counts through the campaign runner, never through fresh capture
    return { captured, coverage, plan: { selected: plan.selected.length, shed: plan.shed } };
  }

  function maturationTick(nowTs) {
    const archive = archiveSource ? archiveSource() : null;
    if (!archive) return { matured: 0, pending: null, reason: 'ARCHIVE_UNAVAILABLE' };
    const episodes = store.readEpisodes();
    const latest = store.latestOutcomes();
    const sweep = maturationSweep({ episodes, latestOutcomes: latest, archive, asOfTs: nowTs, attachedTs: nowTs, maxPerSweep: MAX_MATURATION_PER_TICK });
    for (const attach of sweep.attachments) { try { store.appendOutcome(attach); if (attach.outcomeRow.availability.state !== 'UNAVAILABLE') counters.newlyMatured += 1; } catch (err) { errors.maturation += 1; log(`learning maturation: ${err.message}`); } }
    return { matured: sweep.matured, pending: sweep.pending, unavailable: sweep.unavailable };
  }

  function learnTick(nowTs) {
    const episodes = store.readEpisodes();
    const outcomes = store.latestOutcomes();
    const items = [];
    for (const e of episodes) {
      const o = outcomes.get(e.opportunityId); if (!o) continue;
      const cls = classifyOutcome(o.outcomeRow.horizons[horizonKeyForScope(e)]); // PUBLISH-FIX-56: the cell is graded on the horizon its setup lives on
      if (cls === 'NOT_YET_KNOWN' || cls === 'UNAVAILABLE') continue;
      items.push({ opportunityId: e.opportunityId, canonicalCoin: e.canonicalCoin, decisionTs: e.decisionTs, evidenceBasis: e.evidenceBasis, outcomeClass: cls, setupType: e.setupType, regime: e.regime, decision: e.decision });
    }
    if (items.length === 0) return { updated: 0, matured: 0 };
    const informative = items.filter((i) => i.outcomeClass === 'FAVORABLE' || i.outcomeClass === 'ADVERSE');
    const pooledMean = informative.length ? informative.filter((i) => i.outcomeClass === 'FAVORABLE').length / informative.length : 0.5;
    const heads = store.patternHeads();
    let updated = 0;
    const cells = new Map();
    // PUBLISH-FIX-41 (owner doctrine: "learn what to avoid as much as what to take"): a cell is every GRADED decision of a
    // setup x regime — picks, refusals, expiries and no-trades alike — not only the selections. Production proved the old
    // membership empty: 1,040 scored paper decisions and zero entries meant zero cells for as long as the Judge never bit.
    // The cell stays descriptive (P(favorable | evaluated)); the promoter already trains its stump over the whole cell.
    for (const i of items) {
      const key = `${i.setupType}|${i.regime}`;
      if (!cells.has(key)) cells.set(key, []);
      cells.get(key).push(i);
    }
    for (const [key, cellItems] of cells.entries()) {
      const [setupType, regime] = key.split('|');
      const predicate = { clauses: [], descriptor: `EVALUATED_${setupType}` }; // descriptive cell memory over every graded decision; candidate predicates are richer and sealed separately
      const scope = { setupType, regime };
      const patternId = `lpat-${canonicalDigest({ predicateDigest: canonicalDigest(predicate), scopeDigest: canonicalDigest(scope) }).slice(0, 40)}`;
      const head = heads.get(patternId) ?? null;
      const step = nextPatternStep({ head, evidenceItems: cellItems, pooledMean, priorStrength: 8, nowTs });
      if (step === null) continue; // frozen/active patterns never mutate from the evidence side
      if (head && head.evidence.rawCount === step.evidence.rawCount) continue; // nothing new matured for this cell
      try {
        store.appendPattern(buildPatternRecord({
          predicate, scope, origin: 'LIVE_DESCRIPTIVE_CELL', createdTs: head ? head.createdTs : nowTs, ts: nowTs,
          seq: step.seq, state: step.state, previousState: step.previousState, transitionReason: step.transitionReason,
          evidence: step.evidence, estimate: step.estimate, contradictions: step.contradictions,
        }));
        updated += 1; counters.learnedUpdates += 1;
      } catch (err) { errors.learning += 1; log(`learning update: ${err.message}`); }
    }
    return { updated, matured: items.length };
  }

  function writeStatus(nowTs, tickReport) {
    const kill = store.readKill();
    store.writeStatus({
      serviceVersion: SERVICE_VERSION, learningVersion: LEARNING_VERSION, state: stopped ? 'STOPPED' : 'RUNNING',
      lastTickTs: lastTick, nowTs, counters: { ...counters, perAsset: undefined, perAssetCount: Object.keys(counters.perAsset).length },
      coverageAges: coverageAges({ lastCapturedBySymbol, nowTs }),
      lastTickReport: tickReport, errors: { ...errors }, storeCounters: store.countersOf(),
      shadowLane: shadowRunner ? (() => { try { return shadowRunner.status(nowTs); } catch { return { failed: 'STATUS_UNAVAILABLE' }; } })() : null,
      opportunityAuditLane: opportunityAuditFollowup ? (() => { try { return opportunityAuditFollowup.status(); } catch { return { failed: 'STATUS_UNAVAILABLE' }; } })() : null,
      decisionBridge: decisionBridge ? (() => { try { return decisionBridge.status(); } catch { return { failed: 'STATUS_UNAVAILABLE' }; } })() : null,
      promoter: promoter ? (() => { try { return promoter.status(); } catch { return { failed: 'STATUS_UNAVAILABLE' }; } })() : null,
      memory: (() => { try { const heads = [...store.patternHeads().values()]; const byState = {}; for (const h of heads) byState[h.state] = (byState[h.state] ?? 0) + 1; return { patterns: heads.length, byState, cells: heads.map((h) => ({ setupType: h.scope?.setupType ?? null, regime: h.scope?.regime ?? null, state: h.state, rawCount: h.evidence?.rawCount ?? null, groups: h.evidence?.groupCount ?? null, dates: h.evidence?.distinctUtcDates ?? null, assets: h.evidence?.distinctAssets ?? null })).slice(0, 64), activations: [...store.activationHeads().values()].filter((a) => a.state === 'ACTIVE_PAPER').length }; } catch { return null; } })(),
      killSwitch: kill, sourceDelayEvidence: PROVIDER_DELAY_EVIDENCE,
      mainLane: (() => { try { return meter.snapshot(); } catch { return null; } })(), // per-step main-lane occupancy (Ticket 6)
      authority: AUTHORITY, purpose: PURPOSE,
      law: 'COLLECTOR_RUNNING_IS_NOT_LEARNER_RUNNING_IS_NOT_VALIDATED_ADAPTIVE_BEHAVIOR',
    });
  }

  function tick() {
    if (ticking || stopped) return null;
    ticking = true;
    const nowTs = clock();
    counters = rollCounters(counters, nowTs);
    const report = {};
    try { report.capture = meter.time('capture', () => captureTick(nowTs)); } catch (err) { errors.capture += 1; report.capture = { failed: err.message }; }
    if (decisionBridge) { try { report.decisionBridge = meter.time('decisionBridge', () => decisionBridge.step({ nowTs })); } catch (err) { errors.decisionBridge += 1; report.decisionBridge = { failed: String(err?.message ?? err).slice(0, 200) }; } }
    try { report.maturation = meter.time('maturation', () => maturationTick(nowTs)); } catch (err) { errors.maturation += 1; report.maturation = { failed: err.message }; }
    try { report.learning = meter.time('learning', () => learnTick(nowTs)); } catch (err) { errors.learning += 1; report.learning = { failed: err.message }; }
    if (promoter) { try { report.promoter = meter.time('promoter', () => promoter.step({ nowTs })); } catch (err) { errors.promoter += 1; report.promoter = { failed: String(err?.message ?? err).slice(0, 200) }; } }
    // One optional step; failure is reported without suppressing other lanes.
    // Absent port performs no shadow work. The owner must keep any heavy
    // learning workload isolated from the trading/Watch event loop.
    if (shadowRunner) { try { report.shadow = meter.time('shadow', () => shadowRunner.step({ nowTs })); } catch (err) { errors.shadow += 1; report.shadow = { failed: String(err?.message ?? err).slice(0, 200) }; } }
    if (opportunityAuditFollowup) {
      try {
        const task = opportunityAuditFollowup.step({ nowTs });
        if (!task || typeof task.then !== 'function') throw new Error('FOLLOWUP_STEP_MUST_RETURN_PROMISE');
        task.catch((err) => { errors.opportunityAudit += 1; log(`opportunity audit follow-up: ${String(err?.message ?? err).slice(0, 200)}`); });
        report.opportunityAudit = { state: 'STARTED', authority: 'NONE' };
      } catch (err) {
        errors.opportunityAudit += 1; report.opportunityAudit = { failed: String(err?.message ?? err).slice(0, 200) };
      }
    }
    try {
      const yesterday = utcDateOf(nowTs - 86_400_000);
      if (!summaryJob && !store.readSummary(yesterday) && store.coverageDates().includes(yesterday)) {
        // PUBLISH-FIX-35: yesterday's coverage journal (~150 MB) is COUNTED BY STREAMING off the main lane; the summary is
        // written when the count lands (one job at a time; a failure is logged and retried at a later tick)
        const dailyCounters = counters.utcDate === yesterday ? counters : emptyDailyCounters(yesterday);
        summaryJob = store.coverageCountsStreamed(yesterday)
          .then((coverage) => { if (!store.readSummary(yesterday)) store.writeSummary(buildDailySummary({ store, utcDate: yesterday, nowTs: clock(), dailyCounters, workloadTarget: dailyTarget, coverage })); })
          .catch((err) => log(`learning summary: ${String(err?.message ?? err).slice(0, 200)}`))
          .finally(() => { summaryJob = null; });
        report.summary = { state: 'COUNTING', utcDate: yesterday };
      }
    } catch (err) { log(`learning summary: ${err.message}`); }
    lastTick = nowTs;
    try { writeStatus(nowTs, report); } catch (err) { log(`learning status: ${err.message}`); }
    ticking = false;
    return report;
  }

  const timer = timers.setInterval(tick, tickMs);
  if (timer && typeof timer.unref === 'function') timer.unref(); // learning may never keep the process alive
  log(`learning service started (tick ${tickMs}ms, data ${store.dir}) — data-only, authority NONE`);
  return {
    state: () => (stopped ? 'STOPPED' : 'RUNNING'),
    tick, store,
    stop: () => { stopped = true; timers.clearInterval(timer); try { store.flush?.(); } catch { /* group fsync is best effort on stop */ } try { writeStatus(clock(), { stopped: true }); } catch { /* status write is best effort on stop */ } },
  };
}
